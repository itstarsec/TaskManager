ALTER TABLE `auth_sessions` ADD `login_origin` text;--> statement-breakpoint
ALTER TABLE `auth_sessions` ADD `session_mode` text DEFAULT 'cookie' NOT NULL;