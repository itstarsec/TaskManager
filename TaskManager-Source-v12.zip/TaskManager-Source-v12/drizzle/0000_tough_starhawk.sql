CREATE TABLE `announcement_reads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`announcement_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`read_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_announcement_reads_announcement_id_user_id` ON `announcement_reads` (`announcement_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `announcement_teams` (
	`announcement_id` integer NOT NULL,
	`team_id` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_announcement_teams_announcement_id_team_id` ON `announcement_teams` (`announcement_id`,`team_id`);--> statement-breakpoint
CREATE TABLE `announcements` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`content` text NOT NULL,
	`target_type` text NOT NULL,
	`team_id` integer,
	`creator_id` integer NOT NULL,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text
);
--> statement-breakpoint
CREATE TABLE `department_members` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`department_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_department_members_department_id_user_id` ON `department_members` (`department_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `departments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`code` text NOT NULL,
	`parent_id` integer,
	`manager_id` integer,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_departments_code` ON `departments` (`code`);--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` integer NOT NULL,
	`task_id` integer,
	`type` text NOT NULL,
	`title` text NOT NULL,
	`message` text NOT NULL,
	`is_read` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `roles` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`code` text NOT NULL,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_roles_code` ON `roles` (`code`);--> statement-breakpoint
CREATE UNIQUE INDEX `uq_roles_name` ON `roles` (`name`);--> statement-breakpoint
CREATE TABLE `site_state` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `subtasks` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`task_id` integer NOT NULL,
	`title` text NOT NULL,
	`completed` integer NOT NULL,
	`created_at` text NOT NULL,
	`completed_at` text
);
--> statement-breakpoint
CREATE TABLE `support_routing_rules` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`team_id` integer NOT NULL,
	`keyword` text NOT NULL,
	`weight` integer NOT NULL,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `support_team_members` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`team_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_support_team_members_team_id_user_id` ON `support_team_members` (`team_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `support_teams` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`department_id` integer NOT NULL,
	`name` text NOT NULL,
	`code` text NOT NULL,
	`lead_id` integer,
	`is_active` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_support_teams_department_id_code` ON `support_teams` (`department_id`,`code`);--> statement-breakpoint
CREATE TABLE `support_ticket_activities` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`ticket_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`action` text NOT NULL,
	`old_value` text,
	`new_value` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `support_ticket_comments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`ticket_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`content` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `support_tickets` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`ticket_code` text NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`creator_id` integer NOT NULL,
	`assignee_id` integer,
	`category` text NOT NULL,
	`priority` text NOT NULL,
	`status` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`resolved_at` text,
	`closed_at` text,
	`department_id` integer,
	`team_id` integer,
	`routing_score` integer DEFAULT 0 NOT NULL,
	`routing_method` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_support_tickets_ticket_code` ON `support_tickets` (`ticket_code`);--> statement-breakpoint
CREATE TABLE `task_activities` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`task_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`subtask_id` integer,
	`action` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `task_comments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`task_id` integer NOT NULL,
	`user_id` integer NOT NULL,
	`content` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `task_supporters` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`task_id` integer NOT NULL,
	`user_id` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_task_supporters_task_id_user_id` ON `task_supporters` (`task_id`,`user_id`);--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`creator_id` integer NOT NULL,
	`assignee_id` integer,
	`status` text NOT NULL,
	`priority` text NOT NULL,
	`progress` integer NOT NULL,
	`deadline` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`username` text NOT NULL,
	`full_name` text NOT NULL,
	`role_id` integer,
	`telegram_chat_id` text,
	`is_active` integer NOT NULL,
	`must_change_password` integer NOT NULL,
	`created_at` text NOT NULL,
	`position` text,
	`deleted_at` text,
	`avatar_url` text,
	`chatgpt_user_id` text,
	`email` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_chatgpt_user_id_unique` ON `users` (`chatgpt_user_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `uq_users_username` ON `users` (`username`);