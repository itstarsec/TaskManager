'use client';
import {useCallback,useEffect,useState} from 'react';
import {usePathname} from 'next/navigation';
import api from './legacy/services/api';
import {AuthContext} from './legacy/services/auth-context';
import PasswordForm from './legacy/components/PasswordForm';

export default function WorkspaceClient({children,initialUser}) {
  const path=usePathname();
  const [user,setUser]=useState(initialUser||null),[ready,setReady]=useState(!!initialUser),[error,setError]=useState('');
  const load=useCallback(async()=>{
    setReady(false);setError('');
    try{const {data}=await api.get('/auth/me');setUser(data);}
    catch(e){setUser(null);setError(e.message);}
    finally{setReady(true);}
  },[]);
  useEffect(()=>{if(!initialUser)load();},[load,initialUser]);
  useEffect(()=>{document.querySelector('.sidebar')?.classList.remove('mobile-open');},[path]);
  useEffect(()=>{
    if(!user||user.must_change_password)return;
    let stopped=false,revision=null;
    const check=async()=>{
      if(stopped||document.hidden)return;
      try{
        const {data}=await api.get('/system/revision');
        if(stopped)return;
        if(revision!==null&&revision!==data.revision){
          for(const entity of ['task','support_ticket','other'])window.dispatchEvent(new CustomEvent('taskmanager:realtime',{detail:{type:'data_changed',entity}}));
        }
        revision=data.revision;
      }catch{/* The request layer handles an expired session. */}
    };
    check();const timer=setInterval(check,12000);
    document.addEventListener('visibilitychange',check);
    return()=>{stopped=true;clearInterval(timer);document.removeEventListener('visibilitychange',check);};
  },[user]);
  if(!ready)return <div className="boot-screen" role="status"><span className="boot-mark">M</span><strong>Task Manager</strong><span>Đang mở không gian làm việc…</span></div>;
  if(!user)return <div className="boot-screen"><h1>Chưa thể mở không gian làm việc</h1><p role="alert">{error}</p><button className="create-task-button" onClick={load}>Thử lại</button><a href="/login">Đăng nhập lại</a></div>;
  if(user.must_change_password)return <div className="password-gate"><PasswordForm forced/></div>;
  return <AuthContext.Provider value={user}>{children}</AuthContext.Provider>;
}
