'use client';
import TaskWorkspace from '../components/TaskWorkspace';
export default function MyTasks(){return <TaskWorkspace mine/>;}
