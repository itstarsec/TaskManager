'use client';
import {useEffect,useState} from 'react';
import {Users,ShieldCheck,Send,Plus,Pencil,Trash2,X,KeyRound,Check,Search,LockKeyhole} from 'lucide-react';
import Sidebar from '../components/Sidebar';
import Topbar from '../components/Topbar';
import PasswordForm from '../components/PasswordForm';
import api from '../services/api';
import {useAuth} from '../services/auth-context';

const roleGuide=[
 ['Admin','Toàn bộ công việc, tài khoản, vai trò, tổ chức và sao lưu.'],
 ['Supervisor','Quản lý toàn bộ công việc, hỗ trợ, nhóm và thông báo; không quản trị tài khoản.'],
 ['Leader','Theo dõi công việc của nhóm được giao quản lý; điều phối hỗ trợ và thông báo trong nhóm.'],
 ['User','Cập nhật công việc được giao, checklist và trao đổi; tạo và theo dõi yêu cầu hỗ trợ của mình.'],
 ['Viewer','Chỉ xem công việc được giao, yêu cầu liên quan và thông báo; không chỉnh sửa dữ liệu nghiệp vụ.']
];
const fixedCodes=['admin','supervisor','leader','user','viewer'];
export default function Settings(){
 const me=useAuth(),isAdmin=me?.role_code==='admin';
 const [users,setUsers]=useState([]),[roles,setRoles]=useState([]),[tab,setTab]=useState(isAdmin?'users':'security');
 const [error,setError]=useState(''),[message,setMessage]=useState(''),[editing,setEditing]=useState(null),[form,setForm]=useState({}),[saving,setSaving]=useState(false),[loading,setLoading]=useState(true),[search,setSearch]=useState('');
 const [telegram,setTelegram]=useState(null),[chatId,setChatId]=useState('');
 const load=async()=>{
  try {
   const requests=[api.get('/telegram/status'),...(isAdmin?[api.get('/users?include_inactive=true'),api.get('/roles')]:[])];
   const results=await Promise.allSettled(requests);
   if(results[0].status==='fulfilled'){setTelegram(results[0].value.data);setChatId(results[0].value.data.telegram_chat_id||'');}
   if(isAdmin){if(results[1].status==='fulfilled')setUsers(results[1].value.data);else throw results[1].reason;if(results[2].status==='fulfilled')setRoles(results[2].value.data);else throw results[2].reason;}
   if(results[0].status==='rejected')setError('Chưa tải được kết nối Telegram. Các mục tài khoản vẫn có thể sử dụng.');
  }catch(e){setError(e.message);}finally{setLoading(false);}
 };
 useEffect(()=>{load();},[isAdmin]);
 useEffect(()=>{if(!editing)return;const esc=e=>{if(e.key==='Escape'&&!saving)setEditing(null);};document.addEventListener('keydown',esc);return()=>document.removeEventListener('keydown',esc);},[editing,saving]);
 const action=async(fn,ok)=>{setSaving(true);setError('');setMessage('');try{await fn();setMessage(ok||'Đã lưu.');await load();return true;}catch(e){setError(e.message);return false;}finally{setSaving(false);}};
 const lowerRoles=roles.filter(r=>r.is_active&&r.code.toLowerCase()!=='admin');
 const open=(type,item={})=>{
  setEditing({type,id:item.id,name:item.full_name});setError('');setMessage('');
  setForm(type==='user'?{username:item.username||'',full_name:item.full_name||'',position:item.position||'',email:item.email||'',role_id:item.role_id||lowerRoles.find(r=>r.code==='user')?.id||lowerRoles[0]?.id,password:'',must_change_password:true}:type==='reset'?{new_password:'',must_change_password:true}:{name:item.name||'',code:item.code||''});
 };
 const save=async e=>{
  e.preventDefault();
  const fn=()=>editing.type==='reset'?api.post('/users/'+editing.id+'/reset-password',form):editing.type==='user'?(editing.id?api.put('/users/'+editing.id+'/profile',form):api.post('/users',{...form,role_id:Number(form.role_id)})):(editing.id?api.put('/roles/'+editing.id,form):api.post('/roles',form));
  if(await action(fn,editing.type==='reset'?'Đã đặt lại mật khẩu và thu hồi các phiên đăng nhập.':'Đã lưu thay đổi.')){setEditing(null);setForm({});}
 };
 const filtered=users.filter(u=>(u.full_name+' '+u.username+' '+(u.email||'')).toLocaleLowerCase('vi').includes(search.toLocaleLowerCase('vi')));
 const tabs=[...(isAdmin?[['users','Tài khoản',Users],['roles','Vai trò & quyền',ShieldCheck]]:[]),['security','Bảo mật',KeyRound],['telegram','Telegram',Send]];
 const title=editing?.type==='reset'?'Đặt mật khẩu · '+editing.name:editing?.type==='role'?(editing.id?'Sửa vai trò':'Thêm vai trò'):(editing?.id?'Sửa hồ sơ':'Tạo tài khoản');
 return <div className="dashboard-layout"><Sidebar/><main className="dashboard-main"><Topbar user={me} title="Cài đặt" description={isAdmin?'Workspace / Tài khoản & quyền truy cập':'Workspace / Tài khoản cá nhân'}/>
  <div className="dashboard-content settings-modern"><div className="overview-heading"><div><div className="eyebrow">THIẾT LẬP KHÔNG GIAN</div><h1>{isAdmin?'Mỗi người, đúng vai trò.':'Tài khoản của bạn.'}</h1><p>{isAdmin?'Cấp tài khoản và phân quyền để đội ngũ cùng làm việc.':'Quản lý mật khẩu và kết nối thông báo của riêng bạn.'}</p></div></div>
   <div className="settings-tabs" role="tablist" aria-label="Cài đặt">{tabs.map(([id,label,Icon])=><button key={id} role="tab" aria-selected={tab===id} className={tab===id?'active':''} onClick={()=>{setTab(id);setError('');setMessage('');}}><Icon size={17}/>{label}</button>)}</div>
   {error&&!editing&&<div className="dashboard-error" role="alert">{error}</div>}{message&&<div className="success-note" role="status"><Check size={16}/>{message}</div>}
   {tab==='users'&&isAdmin&&<>
    <div className="account-summary"><div><strong>{users.filter(u=>u.is_active).length}</strong><span>Tài khoản hoạt động</span></div><div><strong>{users.filter(u=>!u.has_password&&!u.is_super_admin).length}</strong><span>Hồ sơ chờ cấp mật khẩu</span></div><div><ShieldCheck size={23}/><span>Admin là quản trị cao nhất</span></div></div>
    <section className="work-panel"><div className="panel-heading"><div><h2>Tài khoản <span className="count-badge">{users.length}</span></h2><p>Tài khoản mới có thể đăng nhập ngay bằng thông tin bạn cấp.</p></div><button className="create-task-button" disabled={loading||saving} onClick={()=>open('user')}><Plus size={16}/> Tạo tài khoản</button></div>
     <div className="account-search"><Search size={17}/><input type="search" aria-label="Tìm tài khoản" placeholder="Tìm theo tên, tài khoản hoặc email…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
     <div className="table-scroll"><table className="recent-table settings-table"><thead><tr><th>THÀNH VIÊN</th><th>VAI TRÒ</th><th>TRUY CẬP</th><th>THAO TÁC</th></tr></thead><tbody>{filtered.map(u=><tr key={u.id}>
      <td><div className="person-cell"><span className="mini-avatar">{u.full_name?.[0]||'U'}</span><div><strong>{u.full_name}</strong><small>@{u.username}{u.id===me.id?' · Bạn':''}</small>{u.position&&<small>{u.position}</small>}</div></div></td>
      <td>{u.is_super_admin?<span className="super-admin-badge"><ShieldCheck size={14}/> Quản trị cao nhất</span>:<select aria-label={'Vai trò của '+u.full_name} value={u.role_id} disabled={saving} onChange={e=>action(()=>api.put('/users/'+u.id+'/role',{role_id:Number(e.target.value)}),'Đã đổi vai trò và thu hồi phiên đăng nhập cũ.')}>
       {roles.filter(r=>r.id===u.role_id||lowerRoles.some(a=>a.id===r.id)).map(r=><option key={r.id} value={r.id} disabled={!r.is_active||r.code==='admin'}>{r.name}</option>)}
      </select>}</td>
      <td><span className={'status-pill '+(!u.is_active?'todo':u.has_password?'completed':'in_progress')}>{!u.is_active?'Đã khóa':u.has_password?'Được truy cập':'Chưa có mật khẩu'}</span>{u.must_change_password&&u.has_password&&<small className="account-hint">Đổi mật khẩu khi đăng nhập</small>}</td>
      <td><div className="button-row"><button className="icon-action" title="Sửa hồ sơ" aria-label={'Sửa hồ sơ '+u.full_name} disabled={saving} onClick={()=>open('user',u)}><Pencil size={15}/></button>{!u.is_super_admin&&<><button className="tiny-button" disabled={saving} onClick={()=>open('reset',u)}><KeyRound size={14}/>{u.has_password?'Đặt lại mật khẩu':'Cấp mật khẩu'}</button><button className="tiny-button" disabled={saving} onClick={()=>action(()=>api.post('/users/'+u.id+'/'+(u.is_active?'deactivate':'activate')),u.is_active?'Đã khóa tài khoản và thu hồi phiên đăng nhập.':'Đã mở tài khoản.')}>{u.is_active?'Khóa':'Mở'}</button><button className="icon-action danger" title="Lưu trữ tài khoản" aria-label={'Lưu trữ '+u.full_name} disabled={saving} onClick={()=>{if(window.confirm('Lưu trữ '+u.full_name+'? Người này sẽ không thể đăng nhập; lịch sử được giữ nguyên.'))action(()=>api.delete('/users/'+u.id),'Đã lưu trữ tài khoản.');}}><Trash2 size={15}/></button></>}</div></td>
     </tr>)}</tbody></table>{loading&&<div className="clean-empty">Đang tải tài khoản…</div>}{!loading&&!filtered.length&&<div className="clean-empty">Không tìm thấy tài khoản phù hợp.</div>}</div>
    </section><p className="small-note">Hồ sơ chuyển từ hệ thống cũ cần được cấp mật khẩu trước khi đăng nhập. Có thể quản lý nhóm và phân công tại “Phòng ban & nhóm”.</p>
   </>}
   {tab==='roles'&&isAdmin&&<><div className="role-guide">{roleGuide.map(([name,desc])=><article className="work-panel" key={name}><ShieldCheck size={20}/><h3>{name}</h3><p>{desc}</p></article>)}</div>
    <section className="work-panel"><div className="panel-heading"><div><h2>Danh mục vai trò</h2><p>Quyền được kiểm tra trên máy chủ cho từng thao tác và bản ghi.</p></div><button className="secondary-action" onClick={()=>open('role')}><Plus size={16}/> Thêm vai trò</button></div><div className="table-scroll"><table className="recent-table"><thead><tr><th>VAI TRÒ</th><th>MÃ</th><th>TRẠNG THÁI</th><th>THAO TÁC</th></tr></thead><tbody>{roles.map(r=><tr key={r.id}><td><strong>{r.name}</strong></td><td><code>{r.code}</code></td><td>{r.is_active?'Hoạt động':'Tạm dừng'}</td><td><div className="button-row"><button className="icon-action" aria-label={'Sửa vai trò '+r.name} onClick={()=>open('role',r)}><Pencil size={15}/></button>{!fixedCodes.includes(r.code)&&<button className="icon-action danger" aria-label={'Xóa vai trò '+r.name} onClick={()=>{if(window.confirm('Xóa vai trò '+r.name+'?'))action(()=>api.delete('/roles/'+r.id),'Đã xóa vai trò.');}}><Trash2 size={15}/></button>}</div></td></tr>)}</tbody></table></div><p className="small-note padded">Vai trò tùy chỉnh có quyền tương đương User. Vai trò cũ Management / Project Manager tương đương Supervisor.</p></section>
   </>}
   {tab==='security'&&<div className="settings-two-col"><PasswordForm/><section className="work-panel padded"><ShieldCheck size={27}/><h2>Quyền truy cập của bạn</h2><p><strong>{me?.is_super_admin?'Quản trị cao nhất':me?.role}</strong> · @{me?.username}</p><p className="muted">{roleGuide.find(([name])=>name.toLowerCase()===me?.role_code)?.[1]||roleGuide[3][1]}</p><p className="muted">Phiên đăng nhập có thời hạn 12 giờ. Thay đổi mật khẩu, vai trò hoặc khóa tài khoản sẽ thu hồi các phiên đăng nhập hiện có.</p></section></div>}
   {tab==='telegram'&&<section className="work-panel padded telegram-account"><div className="connection-icon"><Send size={27}/></div><h2>Thông báo Telegram</h2><p className="muted">Liên kết Chat ID cá nhân để nhận tin qua bot đã được cấu hình.</p><div className={'connection-status '+(telegram?.configured?'connected':'')}>{telegram?.configured?'Bot đã được cấu hình':'Bot chưa được cấu hình'}</div>{!telegram?.configured&&<div className="identity-note"><LockKeyhole size={20}/><p>Quản trị viên cần cấu hình bot trước khi gửi tin. Thông báo trong ứng dụng vẫn hoạt động.</p></div>}<form onSubmit={e=>{e.preventDefault();action(()=>api.put('/telegram/me/chat-id',{telegram_chat_id:chatId}),'Đã lưu Chat ID.');}}><label className="field-label">Chat ID cá nhân<input value={chatId} onChange={e=>setChatId(e.target.value)} placeholder="Ví dụ: 123456789" inputMode="numeric" required/></label><div className="button-row"><button className="create-task-button" disabled={saving}>Lưu liên kết</button><button type="button" className="secondary-action" disabled={!telegram?.configured||!telegram?.telegram_chat_id||saving} onClick={()=>action(()=>api.post('/telegram/me/test'),'Đã gửi tin kiểm tra.')}>Gửi thử</button>{telegram?.telegram_chat_id&&<button type="button" className="tiny-button" disabled={saving} onClick={()=>action(()=>api.delete('/telegram/me/chat-id'),'Đã hủy liên kết.')}>Hủy liên kết</button>}</div></form></section>}
  </div></main>
  {editing&&<div className="modal-overlay" onClick={e=>{if(e.target===e.currentTarget&&!saving)setEditing(null);}}><section className="modern-modal account-modal" role="dialog" aria-modal="true" aria-labelledby="settings-dialog-title"><div className="panel-heading"><h2 id="settings-dialog-title">{title}</h2><button className="icon-action" aria-label="Đóng" disabled={saving} onClick={()=>setEditing(null)}><X size={20}/></button></div><form onSubmit={save}>
   {editing.type!=='reset'&&(editing.type==='user'?[['full_name','Họ và tên',true],['username','Tên đăng nhập',true],['position','Chức vụ',false],['email','Email liên hệ',false]]:[['name','Tên vai trò',true],['code','Mã vai trò',true]]).map(([key,label,required])=><label key={key} className="field-label">{label}<input autoFocus={key===(editing.type==='user'?'full_name':'name')} type={key==='email'?'email':'text'} autoComplete="off" value={form[key]||''} maxLength={key==='username'?50:150} required={required} disabled={(key==='username'&&!!editing.id)||(key==='code'&&fixedCodes.includes(form.code)&&!!editing.id)} onChange={e=>setForm({...form,[key]:e.target.value})}/></label>)}
   {editing.type==='user'&&!editing.id&&<label className="field-label">Vai trò<select required value={form.role_id||''} onChange={e=>setForm({...form,role_id:e.target.value})}>{lowerRoles.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></label>}
   {(editing.type==='reset'||editing.type==='user'&&!editing.id)&&<><label className="field-label">{editing.type==='reset'?'Mật khẩu mới':'Mật khẩu ban đầu'}<input autoFocus={editing.type==='reset'} type="password" autoComplete="new-password" required minLength={12} maxLength={128} value={form[editing.type==='reset'?'new_password':'password']||''} onChange={e=>setForm({...form,[editing.type==='reset'?'new_password':'password']:e.target.value})}/></label><p className="small-note">Từ 12 đến 128 ký tự. Gửi thông tin đăng nhập trực tiếp cho người được cấp.</p><label className="checkbox-field"><input type="checkbox" checked={form.must_change_password} onChange={e=>setForm({...form,must_change_password:e.target.checked})}/> Yêu cầu đổi mật khẩu khi đăng nhập lần đầu</label></>}
   {editing.type==='role'&&!editing.id&&<p className="small-note">Vai trò mới kế thừa quyền User. Dùng các vai trò hệ thống khi cần quyền quản lý.</p>}
   {error&&<div className="dashboard-error" role="alert">{error}</div>}<div className="modal-actions"><button type="button" className="secondary-action" disabled={saving} onClick={()=>setEditing(null)}>Hủy</button><button className="create-task-button" disabled={saving}>{saving?'Đang lưu…':editing.type==='reset'?'Đặt mật khẩu':'Lưu thay đổi'}</button></div>
  </form></section></div>}
 </div>;
}
