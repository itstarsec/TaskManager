import BasketballTaskCreator from './basketball/BasketballTaskCreator';
// Shared entry point retained for Dashboard and TaskWorkspace.
export default function TaskModal(props){return <BasketballTaskCreator {...props}/>;}
