import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {ListTodo,Clock3,CheckCheck,TriangleAlert,Plus,Search,List,Columns3,RefreshCw,FilterX,UserRound} from 'lucide-react';
import api from '../services/api';
import {useAuth,can} from '../services/auth-context';
import {useSearchParams} from '../services/router';
import {filterTasks,taskMatchesQueue,taskStates} from '../services/task-views';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import TaskCard from './TaskCard';
import TaskModal from './TaskModal';
import TaskDetail from './TaskDetail';

export default function TaskWorkspace({mine=false}){
 const user=useAuth(),canCreate=!mine&&can(user,'task.create');
 const [params,setParams]=useSearchParams();
 const [tasks,setTasks]=useState([]),[users,setUsers]=useState([]),[loading,setLoading]=useState(true),[refreshing,setRefreshing]=useState(false),[error,setError]=useState('');
 const [search,setSearch]=useState(()=>params.get('search')||''),[status,setStatus]=useState(()=>['todo','in_progress','completed'].includes(params.get('status'))?params.get('status'):'all'),[priority,setPriority]=useState('all'),[assignee,setAssignee]=useState('all'),[queue,setQueue]=useState(()=>['today','overdue','unassigned','completed','assigned','supporting'].includes(params.get('queue'))?params.get('queue'):'all'),[view,setView]=useState(()=>params.get('view')==='board'?'board':'list');
 const [creating,setCreating]=useState(false);
 const [now,setNow]=useState(()=>new Date());
 const requestId=useRef(0);
 const load=useCallback(async()=>{
   const id=++requestId.current;setRefreshing(true);setError('');
   try{const [t,u]=await Promise.all([api.get(mine?'/tasks?mine=true':'/tasks'),api.get('/users')]);if(id!==requestId.current)return;setTasks(t.data);setUsers(u.data);}
   catch(e){if(id===requestId.current)setError(e.message);}
   finally{if(id===requestId.current){setLoading(false);setRefreshing(false);}}
 },[mine]);
 useEffect(()=>{load();const update=e=>{if(e.detail?.entity==='task')load();};window.addEventListener('taskmanager:realtime',update);const timer=setInterval(()=>setNow(new Date()),60000);return()=>{requestId.current++;window.removeEventListener('taskmanager:realtime',update);clearInterval(timer);};},[load]);
 const selectedId=params.has('task')?Number(params.get('task')):null,selected=tasks.find(t=>t.id===selectedId);
 const openTask=task=>{const next=new URLSearchParams(params);next.set('task',String(task.id));setParams(next);};
 const closeTask=()=>{const next=new URLSearchParams(params);next.delete('task');setParams(next,{replace:true});};
 const filtered=useMemo(()=>filterTasks(tasks,{search,status,priority,assignee,queue,userId:user.id,now}),[tasks,search,status,priority,assignee,queue,user.id,now]);
 const title=mine?'Việc của tôi':'Tất cả công việc';
 const queues=mine?[['all','Tất cả'],['assigned','Tôi phụ trách'],['supporting','Tôi hỗ trợ'],['today','Đến hạn hôm nay'],['overdue','Quá hạn']]:[['all','Tất cả'],['today','Đến hạn hôm nay'],['overdue','Quá hạn'],['unassigned','Chưa phân công'],['completed','Hoàn thành']];
 const clear=()=>{setSearch('');setStatus('all');setPriority('all');setAssignee('all');setQueue('all');};
 const hasFilters=search||status!=='all'||priority!=='all'||assignee!=='all'||queue!=='all';
 const metrics=[
  {label:mine?'Việc liên quan đến tôi':'Tổng công việc',count:tasks.length,Icon:ListTodo,tone:'neutral',click:clear},
  {label:'Đang thực hiện',count:tasks.filter(t=>t.status==='in_progress').length,Icon:Clock3,tone:'blue',click:()=>{clear();setStatus('in_progress');}},
  {label:'Đã hoàn thành',count:tasks.filter(t=>t.status==='completed').length,Icon:CheckCheck,tone:'green',click:()=>{clear();setStatus('completed');}},
  {label:'Đã quá hạn',count:tasks.filter(t=>taskMatchesQueue(t,'overdue',user.id,now)).length,Icon:TriangleAlert,tone:'amber',click:()=>{clear();setQueue('overdue');}}
 ];
 return <div className="dashboard-layout"><Sidebar/><main className="dashboard-main"><Topbar user={user} title={title} description={mine?'Công việc / Thực hiện & phối hợp':'Công việc / Phân công & theo dõi'}/>
  <div className="dashboard-content task-workspace">
   <div className="overview-heading"><div><div className="eyebrow">{mine?'ƯU TIÊN CÔNG VIỆC HÔM NAY':'ĐIỀU PHỐI CÔNG VIỆC'}</div><h1>{title}</h1><p>{mine?'Công việc bạn phụ trách hoặc tham gia hỗ trợ. Mở từng việc để cập nhật tiến độ, checklist và trao đổi.':'Tạo công việc, phân công người phụ trách và theo dõi tiến độ trong phạm vi được cấp quyền.'}</p></div>{canCreate&&<button className="create-task-button" onClick={()=>setCreating(true)}><Plus size={17}/>Tạo công việc</button>}</div>
   <section className="metric-grid" aria-label="Tình hình công việc">{metrics.map(({label,count,Icon,tone,click})=><button className={'metric-card metric-button '+tone} key={label} onClick={click}><div className="metric-top"><span>{label}</span><Icon size={18}/></div><div className="metric-number">{loading?'—':count}</div><div className="metric-caption">Xem danh sách</div></button>)}</section>
   <section className="work-panel task-work-panel">
    <div className="queue-tabs" role="group" aria-label="Nhóm công việc">{queues.map(([id,label])=><button key={id} aria-pressed={queue===id} className={queue===id?'active':''} onClick={()=>{setQueue(id);setStatus('all');}}>{label}<span>{tasks.filter(t=>taskMatchesQueue(t,id,user.id,now)).length}</span></button>)}</div>
    <div className="task-toolbar"><label className="task-search"><Search size={17}/><input aria-label="Tìm công việc" type="search" placeholder="Tìm tên hoặc mô tả công việc…" value={search} onChange={e=>setSearch(e.target.value)}/></label>
     <select aria-label="Lọc trạng thái" value={status} onChange={e=>setStatus(e.target.value)}><option value="all">Mọi trạng thái</option>{taskStates.map(([id,label])=><option key={id} value={id}>{label}</option>)}</select>
     <select aria-label="Lọc ưu tiên" value={priority} onChange={e=>setPriority(e.target.value)}><option value="all">Mọi mức ưu tiên</option><option value="urgent">Khẩn cấp</option><option value="high">Cao</option><option value="medium">Trung bình</option><option value="low">Thấp</option></select>
     {!mine&&<select aria-label="Lọc người phụ trách" value={assignee} onChange={e=>setAssignee(e.target.value)}><option value="all">Mọi người phụ trách</option>{users.map(u=><option key={u.id} value={u.id}>{u.full_name}</option>)}</select>}
    </div>
    <div className="task-results-bar"><span>{loading?'Đang tải…':`${filtered.length} / ${tasks.length} công việc`}</span><div className="button-row">{hasFilters&&<button className="tiny-button" onClick={clear}><FilterX size={14}/>Xóa bộ lọc</button>}<button className="icon-action" aria-label="Tải lại công việc" disabled={refreshing} onClick={load}><RefreshCw size={16} className={refreshing?'spin':''}/></button><div className="view-toggle" role="group" aria-label="Cách xem công việc"><button aria-label="Xem danh sách" aria-pressed={view==='list'} onClick={()=>setView('list')}><List size={16}/><span>Danh sách</span></button><button aria-label="Xem bảng tiến độ" aria-pressed={view==='board'} onClick={()=>setView('board')}><Columns3 size={16}/><span>Bảng tiến độ</span></button></div></div></div>
    {error&&<div className="dashboard-error" role="alert">{error}<button onClick={load}>Thử lại</button></div>}
    {!loading&&!error&&selectedId&&!selected&&<div className="dashboard-error" role="alert">Công việc này không còn nằm trong danh sách bạn được truy cập.<button onClick={closeTask}>Đóng</button></div>}
    {loading?<div className="clean-empty" role="status"><span className="loading-spinner"/><p>Đang tải công việc…</p></div>:!filtered.length?<div className="clean-empty"><UserRound size={30}/><h2>{hasFilters?'Không có công việc phù hợp':mine?'Bạn chưa có công việc được giao':'Chưa có công việc'}</h2><p>{hasFilters?'Thử đổi điều kiện hoặc xóa bộ lọc.':mine?'Công việc sẽ xuất hiện khi bạn được phân công hoặc thêm vào nhóm hỗ trợ.':'Tạo công việc đầu tiên và chọn người phụ trách.'}</p>{hasFilters?<button className="secondary-action" onClick={clear}>Xóa bộ lọc</button>:canCreate&&<button className="create-task-button" onClick={()=>setCreating(true)}>Tạo công việc</button>}</div>:view==='list'?<div className="task-results-list">{filtered.map(t=><TaskCard key={t.id} task={t} users={users} onClick={openTask}/>)}</div>:<div className="task-board">{taskStates.map(([id,label])=>{const items=filtered.filter(t=>t.status===id);return <section key={id} className={'task-board-column '+id} aria-label={label}><div className="board-column-heading"><h2>{label}</h2><span>{items.length}</span></div>{items.map(t=><TaskCard key={t.id} task={t} users={users} onClick={openTask}/>)}{!items.length&&<p className="board-empty">Chưa có công việc</p>}</section>;})}</div>}
   </section>
   <p className="small-note">{mine?'Mở công việc để cập nhật trạng thái, hoàn thành checklist và trao đổi với người phụ trách.':'Mở công việc để sửa nội dung, đổi người phụ trách, bổ sung người hỗ trợ, checklist, bình luận và xem lịch sử theo quyền được cấp.'}</p>
  </div></main>
  {creating&&<TaskModal initialUsers={users} onClose={()=>setCreating(false)} onCreated={()=>{load();}}/>}
  {selected&&<TaskDetail task={selected} users={users} onClose={closeTask} onUpdated={updated=>setTasks(items=>items.map(t=>t.id===updated.id?updated:t))} onDeleted={id=>{setTasks(items=>items.filter(t=>t.id!==id));closeTask();}}/>}
 </div>;
}
