import {forwardRef,useEffect,useImperativeHandle,useRef,useState} from 'react';
import {ArrowUpRight,RotateCcw,Target,Square,ClipboardList,Check,LoaderCircle,MousePointer2} from 'lucide-react';
import {createCourtController} from './court-controller';
import BasketballHoop from './BasketballHoop';
import CourtStage from './CourtStage';
const priorityLabel={low:'Thấp',medium:'Vừa',high:'Cao',urgent:'Khẩn'};
export default forwardRef(function BasketballCourt({payload,users,intentKey,locked,businessPhase,onStart,onOutcome,onMotion},ref){
 const host=useRef(null),card=useRef(null),trajectory=useRef(null),radar=useRef(null),radarDot=useRef(null),powerText=useRef(null),powerBar=useRef(null),angleText=useRef(null),aimText=useRef(null),hit=useRef(null),engine=useRef(null),latest=useRef(null);
 latest.current={payload,locked,onStart,onOutcome,onMotion};const [geometry,setGeometry]=useState(null),[motion,setMotion]=useState('ready'),[reduced,setReduced]=useState(false);
 useImperativeHandle(ref,()=>({cancel:()=>engine.current?.cancel(),reset:()=>engine.current?.reset(),shoot:()=>engine.current?.shoot()}),[]);
 useEffect(()=>{const media=matchMedia('(prefers-reduced-motion: reduce)'),sync=()=>setReduced(media.matches);sync();media.addEventListener('change',sync);return()=>media.removeEventListener('change',sync);},[]);
 useEffect(()=>{
  const controller=createCourtController({nodes:{host:host.current,card:card.current,trajectory:trajectory.current,radar:radar.current,radarDot:radarDot.current,powerText:powerText.current,powerBar:powerBar.current,angleText:angleText.current,aimText:aimText.current,hit:hit.current},getCurrent:()=>latest.current,setGeometry,onPhase:p=>{setMotion(p);latest.current.onMotion?.(p);}});
  engine.current=controller;return()=>{controller.dispose();engine.current=null;};
 },[]);
 useEffect(()=>{engine.current?.reset();if(!intentKey||!latest.current.payload||latest.current.locked)return;const frame=requestAnimationFrame(()=>{card.current?.focus({preventScroll:true});if(matchMedia('(max-width: 760px)').matches){const modal=host.current?.closest('.btc-modal');if(modal)modal.scrollTo({top:modal.scrollTop+host.current.getBoundingClientRect().top-modal.getBoundingClientRect().top-(modal.querySelector('.btc-modal-heading')?.offsetHeight||0)-12,behavior:'instant'});}});return()=>cancelAnimationFrame(frame);},[intentKey]);
 const g=geometry,assignee=users.find(u=>u.id===payload?.assignee_id);
 const canShoot=!!payload&&!locked&&motion==='ready'&&!!g;
 const stagePhase=['creating','created','error'].includes(businessPhase)?businessPhase:!payload?'empty':motion;
 const stageLabels={empty:'Chờ thẻ',ready:'Sẵn sàng',aiming:'Đang ngắm',flying:'Đang bay',scored:'Đã vào rổ',missed:'Ném lại',creating:'Đang lưu',created:'Đã tạo',error:'Cần thử lại'};
 return <section className={'btc-court-panel btc-motion-'+motion+(reduced?' btc-reduced':'')} data-state={stagePhase} aria-label="Sân ném Task Card">
 <header className="btc-stage-heading"><div><span className="btc-kicker">BASKETBALL / 01</span><h3>Sân ném công việc</h3></div><span className={'btc-stage-status btc-stage-status-'+stagePhase}><i/>{stageLabels[stagePhase]}</span></header>
 <div className="btc-court" ref={host}>
 <svg className="btc-court-svg" width="100%" height="100%" viewBox={g?`0 0 ${g.width} ${g.height}`:'0 0 500 540'} aria-hidden="true">
 {g&&<><CourtStage geometry={g}/><BasketballHoop geometry={g} phase={stagePhase}/></>}
 <path ref={trajectory} className="btc-trajectory" fill="none" strokeWidth="2" strokeDasharray="1 10" strokeLinecap="round"/>
 <g ref={radar} opacity="0" fill="none"><circle r="15" opacity=".25"/><circle r="8" opacity=".5"/><circle ref={radarDot} r="3" stroke="none"/></g><circle ref={hit} r="12" fill="none" stroke="var(--btc-accent)" strokeWidth="2" style={{opacity:0}}/>
 </svg>
 {!payload&&g&&<div className="btc-court-empty" style={{left:g.home.x-g.cardW/2,top:g.home.y-g.cardH/2,width:g.cardW,height:g.cardH}}><ClipboardList size={18}/><span>Thẻ của bạn</span></div>}
 <div ref={card} className={'btc-task-card'+(!payload?' btc-hidden':'')+(g?.cardW<80?' btc-card-compact':'')} role="button" tabIndex={payload&&!locked?0:-1} aria-disabled={!canShoot} aria-label={payload?`Thẻ công việc: ${payload.title}. Kéo để ngắm hoặc nhấn Enter để ném hỗ trợ.`:'Chưa có thẻ công việc'} aria-describedby="btc-drag-instructions" draggable={false}>
 <span className="btc-card-label"><ClipboardList size={11}/><span>TASK</span><span>{assignee?.full_name?.charAt(0)||'↗'}</span></span><strong>{payload?.title||'Công việc'}</strong>{payload?.description&&geometry?.cardW>=95&&<p>{payload.description}</p>}<span className="btc-card-footer"><span>{priorityLabel[payload?.priority]||'Vừa'}</span>{payload?.deadline&&<span>{payload.deadline.slice(8,10)}/{payload.deadline.slice(5,7)}</span>}</span>
 </div>
 <span className="btc-launch-label">KÉO THẺ ĐỂ LẤY ĐÀ <span>↗</span></span>
 </div>
 <div className="btc-shot-console">
 <div className="btc-telemetry"><div><span>LỰC KÉO</span><strong ref={powerText}>0%</strong><div className="btc-power-track"><i ref={powerBar}/></div></div><div><span>GÓC NÉM</span><strong ref={angleText}>—</strong></div><div className="btc-aim-status"><Target size={14}/><span ref={aimText}>ĐÓNG GÓI THẺ ĐỂ BẮT ĐẦU</span></div></div>
 <div className="btc-court-actions">{motion==='missed'?<button className="btc-primary" disabled={locked} onClick={()=>engine.current?.reset()}><RotateCcw size={16}/>Ném lại</button>:<button className="btc-primary" disabled={!canShoot} onClick={()=>engine.current?.shoot()}>{businessPhase==='created'?<Check size={16}/>:businessPhase==='creating'?<LoaderCircle className="btc-spin" size={16}/>:<ArrowUpRight size={16}/>} {businessPhase==='created'?'Đã tạo công việc':businessPhase==='creating'?'Đang lưu…':businessPhase==='error'?'Đã vào rổ':'Ném vào rổ'}</button>}{['aiming','flying'].includes(motion)&&<button className="btc-secondary" onClick={()=>engine.current?.cancel()}><Square size={14}/>Hủy cú ném</button>}</div>
 </div>
 <p className="btc-court-help" id="btc-drag-instructions"><MousePointer2 size={14}/><span>Giữ thẻ · kéo xuống lấy lực · thả để ném.<span className="btc-key-hint"><kbd>Enter</kbd> ném hỗ trợ <span>·</span> <kbd>Esc</kbd> hủy</span></span></p>
 {businessPhase==='creating'&&<span className="btc-sr-only">Đã vào rổ. Đang chờ backend xác nhận.</span>}
 </section>;
});
