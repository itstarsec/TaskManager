import {useCallback,useEffect,useRef,useState} from 'react';
import api from '../../services/api';

const EMPTY = [];
export default function useTaskMembers(initialUsers = EMPTY, currentUser) {
  const [users,setUsers] = useState(() => initialUsers.length ? initialUsers : currentUser?.id ? [currentUser] : []);
  const [loadingUsers,setLoadingUsers] = useState(!initialUsers.length);
  const [usersError,setUsersError] = useState('');
  const request = useRef(null);
  const loadUsers = useCallback(async () => {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setLoadingUsers(true);
    setUsersError('');
    try {
      const response = await api.get('/users',undefined,{signal:controller.signal,timeoutMs:8000,dedupe:false});
      if (!Array.isArray(response.data)) throw new Error('Danh sách thành viên không hợp lệ. Vui lòng tải lại.');
      if (request.current === controller && !controller.signal.aborted) setUsers(response.data);
    } catch (error) {
      if (request.current === controller && !controller.signal.aborted) setUsersError(error.message);
    } finally {
      if (request.current === controller) {
        request.current = null;
        setLoadingUsers(false);
      }
    }
  },[]);
  useEffect(() => {
    if (initialUsers.length) {
      request.current?.abort();
      request.current = null;
      setUsers(initialUsers);
      setLoadingUsers(false);
      setUsersError('');
    } else loadUsers();
    return () => { request.current?.abort(); request.current = null; };
  },[initialUsers,loadUsers]);
  return {users,loadingUsers,usersError,loadUsers};
}
