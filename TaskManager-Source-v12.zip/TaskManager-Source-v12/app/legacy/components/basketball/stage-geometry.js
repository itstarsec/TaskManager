// Shared physical drawing coordinates: the stand foot sits on this exact deck.
export function stageGeometry(g) {
  const s=g.scale||1;
  const back={x:18*s,y:g.height-102*s};
  const u={x:g.width*.66-back.x,y:-70*s};
  const v={x:g.width*.34-back.x,y:92*s};
  const point=(a,b)=>({x:back.x+u.x*a+v.x*b,y:back.y+u.y*a+v.y*b});
  return {scale:s,depth:12*s,point,corners:[point(0,0),point(1,0),point(1,1),point(0,1)],foot:point(.92,.78)};
}
export const polygon=points=>points.map(p=>`${p.x},${p.y}`).join(' ');
