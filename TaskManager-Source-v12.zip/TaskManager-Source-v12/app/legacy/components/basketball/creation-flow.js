// Business state is independent of motion. The synchronous lock is set before
// invoking the async adapter, including when a score callback fires twice.
export class CreationFlow {
 constructor({payload,key,create,verify,onState=()=>{},onCreated=()=>{},persist=()=>{},clear=()=>{}}){Object.assign(this,{payload:structuredClone(payload),key,create,verify,onState,onCreated,persist,clear});this.phase='ready';this.activeShot=null;this.disposed=false;this.pending=null;this.controller=null;this.notified=false;}
 emit(phase,details={}){this.phase=phase;if(!this.disposed)this.onState({phase,...details});}
 startShot(id){if(!['ready','missed'].includes(this.phase)||this.pending)return false;this.activeShot=id;this.emit('flying');return true;}
 cancelShot(){if(this.phase!=='flying')return false;this.activeShot=null;this.emit('ready');return true;}
 settleShot(id,result){if(this.phase!=='flying'||id!==this.activeShot)return this.pending;if(result.outcome!=='scored'||!result.rimPassed){this.emit('missed');return null;}this.persist({key:this.key,payload:this.payload});return this.send(false);}
 async finish(task){if(!Number.isInteger(task?.id)||task.id<=0)throw new Error('Phản hồi chưa xác nhận mã công việc.');this.clear();this.emit('created',{task});if(!this.notified&&!this.disposed){this.notified=true;try{this.onCreated(task);}catch{}}return task;}
 send(verifyFirst){if(this.pending||this.phase==='created'||this.disposed)return this.pending;
 this.emit('creating',{verifying:verifyFirst});this.controller=new AbortController();const signal=this.controller.signal;
 const attempt=Promise.resolve().then(async()=>{try{if(verifyFirst){const result=await this.verify(this.key,signal);if(result.state==='created')return await this.finish(result.task);if(result.state!=='absent')throw new Error('Chưa xác minh được kết quả lượt tạo.');this.emit('creating',{verifying:false});}return await this.finish(await this.create(this.payload,{key:this.key,signal}));}catch(error){this.emit('error',{message:error.message||'Chưa xác nhận được kết quả. Thử lại cùng lượt để tránh tạo trùng.',uncertain:!error.response?.status||error.response.status>=500});return null;}finally{this.pending=null;}});this.pending=attempt;return attempt;
 }
 retry(){if(this.phase!=='error')return this.pending;return this.send(true);}
 // A persisted, previously scored intent is reconciled; no new throw is invented.
 recover(){if(this.phase!=='ready')return;this.emit('creating',{verifying:true});this.controller=new AbortController();this.pending=(async()=>{try{const result=await this.verify(this.key,this.controller.signal);if(result.state==='created')return await this.finish(result.task);this.emit('error',{message:'Lượt trước chưa có kết quả đã lưu. Chọn Thử lại để tiếp tục bằng cùng mã lượt.',uncertain:true});}catch(error){this.emit('error',{message:error.message,uncertain:true});}finally{this.pending=null;}})();return this.pending;}
 dispose(){this.disposed=true;this.controller?.abort();this.activeShot=null;}
}
