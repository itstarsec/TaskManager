// CSS pixels, seconds, radians. Prediction and flight call the exact same step().
export const PHYSICS=Object.freeze({dt:1/240,gravity:760,restitution:.6,maxSeconds:6,maxFloorBounces:2,dragThreshold:5,maxPull:130,pullGain:3});
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export function courtGeometry(width,height){
 const scale=Math.min(1,height/540),cardW=Math.min(100*scale,width*.27),cardH=cardW*.72,radius=5*scale;
 const compact=width/scale<450,gap=cardW*(compact?1.65:2);
 return {width,height,scale,cardW,cardH,radius,rimY:height*.36,rimX:width*(compact?.69:.68),gap,netDepth:cardH+10*scale,netTaper:10*scale,floorY:height-12*scale,home:{x:Math.max(cardW/2+10*scale,width*.17),y:height-cardH/2-32*scale}};
}
export function bounds(s,g){const c=Math.abs(Math.cos(s.angle)),n=Math.abs(Math.sin(s.angle));return {hx:c*g.cardW/2+n*g.cardH/2,hy:n*g.cardW/2+c*g.cardH/2};}
export function shotState(start,velocity,angle=0){return {x:start.x,y:start.y,vx:velocity.vx,vy:velocity.vy,angle,omega:velocity.omega||0,time:0,bounces:0,hits:0,rimPassed:false,outcome:'flying',lastHit:null,crossing:null};}
function collide(s,g,cx,cy){
 const c=Math.cos(s.angle),n=Math.sin(s.angle),dx=cx-s.x,dy=cy-s.y,lx=dx*c+dy*n,ly=-dx*n+dy*c,hw=g.cardW/2,hh=g.cardH/2;
 const qx=clamp(lx,-hw,hw),qy=clamp(ly,-hh,hh);let nx=qx-lx,ny=qy-ly,d=Math.hypot(nx,ny),penetration;
 if(d>=g.radius)return;
 if(d<1e-8){if(hw-Math.abs(lx)<hh-Math.abs(ly)){nx=lx>0?-1:1;ny=0;penetration=g.radius+hw-Math.abs(lx);}else{nx=0;ny=ly>0?-1:1;penetration=g.radius+hh-Math.abs(ly);}}else{nx/=d;ny/=d;penetration=g.radius-d;}
 const wx=nx*c-ny*n,wy=nx*n+ny*c;
 s.x+=wx*(penetration+.015);s.y+=wy*(penetration+.015);
 const rx=qx*c-qy*n,ry=qx*n+qy*c,contactVx=s.vx-s.omega*ry,contactVy=s.vy+s.omega*rx,normalSpeed=contactVx*wx+contactVy*wy;
 if(normalSpeed>=0)return;
 const inertia=(g.cardW*g.cardW+g.cardH*g.cardH)/12,cross=rx*wy-ry*wx,j=-(1+PHYSICS.restitution)*normalSpeed/(1+cross*cross/inertia);
 s.vx+=j*wx;s.vy+=j*wy;s.omega=clamp((s.omega+cross*j/inertia)*.97,-9,9);s.hits++;s.lastHit={x:cx,y:cy,time:s.time};
}
export function step(s,g,dt=PHYSICS.dt){
 if(s.outcome!=='flying')return s;
 const substeps=Math.max(1,Math.ceil(Math.hypot(s.vx,s.vy)*dt/(g.radius*.7))),h=dt/substeps;
 for(let i=0;i<substeps&&s.outcome==='flying';i++){
  const previousX=s.x,previousY=s.y;
  s.vy+=PHYSICS.gravity*(g.scale||1)*h;s.x+=s.vx*h;s.y+=s.vy*h;s.angle+=s.omega*h;s.time+=h;
  collide(s,g,g.rimX-g.gap/2,g.rimY);collide(s,g,g.rimX+g.gap/2,g.rimY);
  const b=bounds(s,g),bottom=s.y+b.hy,left=g.rimX-g.gap/2+g.radius,right=g.rimX+g.gap/2-g.radius;
  // Friendly basket rule: the card centre must actually cross the open mouth
  // downwards. Do not require its corners or subsequent path to fit the net.
  // Swept interpolation prevents a fast outside-to-outside step skipping the rim.
  if(s.vy>0&&previousY<g.rimY&&s.y>=g.rimY){
   const t=(g.rimY-previousY)/(s.y-previousY),x=previousX+(s.x-previousX)*t;
   s.crossing={x,y:g.rimY};
   if(x>left&&x<right){s.rimPassed=true;s.outcome='scored';break;}
  }
  if(bottom>=g.floorY&&s.vy>0){s.y=g.floorY-b.hy;s.bounces++;s.vy=-Math.abs(s.vy)*.38;s.vx*=.72;s.omega*=.65;if(s.bounces>=PHYSICS.maxFloorBounces||Math.abs(s.vy)<35)s.outcome='missed';}
  if(s.time>=PHYSICS.maxSeconds||s.x< -g.cardW||s.x>g.width+g.cardW||s.y< -g.height*2)s.outcome='missed';
 }
 return s;
}
export function predict(initial,g){const s={...initial,lastHit:initial.lastHit?{...initial.lastHit}:null};const points=[{x:s.x,y:s.y}],every=10;let index=0;while(s.outcome==='flying'){step(s,g);if(++index%every===0||s.outcome!=='flying')points.push({x:s.x,y:s.y});}return {state:s,points,radar:s.crossing||{x:clamp(s.x,10,g.width-10),y:g.rimY}};}
export function assistedVelocity(g,start=g.home){
 // Deterministic calibration. A button never grants a basket: its candidate must
 // pass the same collision + downward-rim-crossing test as the live simulation.
 const gravity=PHYSICS.gravity*(g.scale||1);
 for(let t=1;t<=2.225;t+=.025)for(const offset of [-.18,-.15,-.12,-.09,-.06,-.03,0]){
  const velocity={vx:(g.rimX+g.gap*offset-start.x)/t,vy:(g.rimY-start.y-.5*gravity*t*t)/t,omega:0};
  if(start.y-velocity.vy*velocity.vy/(2*gravity)<g.cardH/2+3*(g.scale||1))continue;
  if(predict(shotState(start,velocity),g).state.outcome==='scored')return velocity;
 }
 return null;
}
export function pullShot(g,dx,dy,base){return shotState({x:g.home.x+dx,y:g.home.y+dy},{vx:clamp(base.vx-dx*PHYSICS.pullGain,-1800,1800),vy:clamp(base.vy+35-dy*PHYSICS.pullGain,-1800,1800),omega:clamp(-dx*.009+dy*.0015,-2.4,2.4)},clamp(dx*.003,-.25,.25));}
export const releaseInside=(s,g)=>{const b=bounds(s,g);return s.x-b.hx>=0&&s.x+b.hx<=g.width&&s.y-b.hy>=0&&s.y+b.hy<=g.height;};
export function advanceFrame(runtime,delta,g){runtime.accumulator+=clamp(delta,0,.05);while(runtime.accumulator+1e-12>=PHYSICS.dt&&runtime.state.outcome==='flying'){step(runtime.state,g);runtime.accumulator-=PHYSICS.dt;}return runtime.state;}
