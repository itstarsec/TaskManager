// getRandomValues also works in HTTP preview contexts where randomUUID is absent.
export function newAttemptId(source = globalThis.crypto) {
  if (typeof source?.randomUUID === 'function') return source.randomUUID();
  if (typeof source?.getRandomValues !== 'function') throw new Error('Trình duyệt chưa hỗ trợ mã lượt an toàn. Vui lòng dùng HTTPS hoặc cập nhật trình duyệt.');
  const bytes = source.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
}
