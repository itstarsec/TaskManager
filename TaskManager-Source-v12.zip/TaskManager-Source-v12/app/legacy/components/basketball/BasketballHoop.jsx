import {useId} from 'react';
import {stageGeometry,polygon} from './stage-geometry.js';

export default function BasketballHoop({geometry:g,phase='empty'}) {
  const id='hoop-'+useId().replace(/[^a-zA-Z0-9_-]/g,'');
  const {rimX:x,rimY:y,gap,radius,netDepth}=g;
  const {scale:s,point,foot}=stageGeometry(g);
  const half=gap/2,inner=half-radius,taper=g.netTaper??10,ry=8*s;
  const boardHalf=Math.min(half+28*s,g.width-x-18*s,x-18*s);
  const boardHeight=Math.min(102*s,boardHalf*.78),bottom=y-22*s,top=bottom-boardHeight;
  const targetW=Math.min(76*s,gap*.58),targetH=targetW*.65;
  const postX=Math.min(g.width-12*s,Math.max(foot.x,x+half+32*s));
  const postTop=bottom-18*s,bolt=point(.92,.78);
  const netX=(u,t)=>x+(u-.5)*(inner*2-2*taper*t);
  const light=phase==='created'?'var(--btc-success,#99C5AC)':phase==='error'||phase==='missed'?'var(--btc-error,#DA967E)':'var(--btc-accent,#FFB45B)';
  const lit=!['empty','missed'].includes(phase),mesh=[];
  for(const direction of [-1,1])for(let column=-4;column<=12;column++){
    const points=[];
    for(let row=0;row<=8;row++){
      const t=row/8,u=column/8+direction*t*.5;
      points.push(`${row?'L':'M'}${netX(u,t)},${y+netDepth*t+ry*Math.sqrt(Math.max(0,1-(u*2-1)**2))*(1-t)}`);
    }
    mesh.push(<path key={direction+':'+column} d={points.join(' ')}/>);
  }
  const outline=`M ${x-inner} ${y} Q ${x} ${y+ry*2} ${x+inner} ${y} L ${x+inner-taper} ${y+netDepth} H ${x-inner+taper} Z`;
  const frontArc=`M ${x-half} ${y} A ${half} ${ry} 0 0 0 ${x+half} ${y}`;
  return <g className="btc-hoop" data-lit={lit} data-phase={phase} fill="none" pointerEvents="none" style={{'--hoop-light':light}}>
    <defs>
      <linearGradient id={id+'-face'} x1="0" y1="0" x2=".6" y2="1"><stop stopColor="#363736"/><stop offset="1" stopColor="#242524"/></linearGradient>
      <linearGradient id={id+'-post'}><stop stopColor="#404140"/><stop offset=".5" stopColor="#2C2D2C"/><stop offset="1" stopColor="#1C1D1C"/></linearGradient>
      <filter id={id+'-glow'} x="-50%" y="-250%" width="200%" height="600%"><feGaussianBlur stdDeviation={3*s}/></filter>
      <clipPath id={id+'-net'}><path d={outline}/></clipPath>
    </defs>

    <ellipse cx={foot.x} cy={foot.y+5*s} rx={32*s} ry={8*s} fill="#070A08" opacity=".7"/>
    <polygon points={polygon([point(.865,.68),point(.975,.68),point(.975,.88),point(.865,.88)])} fill="#212221" stroke="#606160" strokeWidth=".8"/>
    <polygon points={polygon([{x:foot.x-5*s,y:foot.y},{x:postX-5*s,y:postTop},{x:postX+5*s,y:postTop},{x:foot.x+5*s,y:foot.y}])}
      fill={'url(#'+id+'-post)'} stroke="#5F605F" strokeWidth=".8"/>
    <path d={`M ${postX+5*s} ${postTop} l ${3*s} ${-3*s} L ${foot.x+8*s} ${foot.y-3*s} l ${-3*s} ${3*s}`} stroke="#414241" strokeWidth=".8"/>
    <path d={`M ${x+boardHalf-13*s} ${postTop} H ${postX}`} stroke="#1F201F" strokeWidth={9*s}/>
    <path d={`M ${x+boardHalf-13*s} ${postTop-4*s} H ${postX}`} stroke="#656665" strokeWidth=".9"/>
    <ellipse cx={bolt.x} cy={bolt.y} rx={2*s} ry={1.2*s} fill="#7C7D7C"/>

    <polygon points={polygon([{x:x-boardHalf,y:top},{x:x-boardHalf+8*s,y:top-7*s},{x:x+boardHalf+8*s,y:top-7*s},{x:x+boardHalf,y:top}])}
      fill="#414241" stroke="#6F706F" strokeWidth=".8"/>
    <polygon points={polygon([{x:x+boardHalf,y:top},{x:x+boardHalf+8*s,y:top-7*s},{x:x+boardHalf+8*s,y:bottom-7*s},{x:x+boardHalf,y:bottom}])}
      fill="#1D1E1D" stroke="#606160" strokeWidth=".8"/>
    <rect x={x-boardHalf} y={top} width={boardHalf*2} height={boardHeight} rx={4*s}
      fill={'url(#'+id+'-face)'} stroke="#7C7D7C" strokeWidth=".85"/>
    <rect x={x-boardHalf+6*s} y={top+6*s} width={boardHalf*2-12*s} height={boardHeight-12*s} rx={2*s} stroke="#4D4E4D" strokeWidth=".6"/>
    <path d={`M ${x-targetW/2} ${bottom-13*s} v ${-targetH} h ${targetW} v ${targetH}`} stroke="var(--hoop-light)" strokeWidth={1.2*s} opacity={lit?.85:.3}/>
    <path d={`M ${x-6*s} ${bottom} V ${y-ry} H ${x+6*s} V ${bottom}`} fill="#2B2C2B" stroke="#7D7E7D" strokeWidth=".7"/>
    {[-1,1].map(side=><g key={side}><circle cx={x+side*(boardHalf-12*s)} cy={top+12*s} r={1.7*s} fill="#2E2F2E" stroke="#828382" strokeWidth=".6"/><path d={`M ${x+side*(boardHalf-12*s)-s} ${top+12*s} h ${2*s}`} stroke="#828382" strokeWidth=".5"/></g>)}
    <circle className="btc-hoop-indicator" cx={x-boardHalf+13*s} cy={bottom-13*s} r={2*s} fill="var(--hoop-light)" opacity={lit?1:.25}/>
    {g.width>430&&<text x={x+boardHalf-12*s} y={bottom-12*s} textAnchor="end" fill="#9D9E9D" fontSize={7*s} fontFamily="monospace" letterSpacing={s}>TM / 01</text>}

    <path d={`M ${x-half} ${y} A ${half} ${ry} 0 0 1 ${x+half} ${y}`} stroke="var(--hoop-light)" strokeWidth={radius*1.1} opacity=".65"/>
    <g className="btc-net" strokeLinecap="round" strokeLinejoin="round">
      <g clipPath={'url(#'+id+'-net)'} stroke="#AAABAA" strokeWidth={.7*s} opacity=".57">{mesh}</g>
      <path d={`M ${x-inner} ${y} L ${x-inner+taper} ${y+netDepth} M ${x+inner} ${y} L ${x+inner-taper} ${y+netDepth}`} stroke="#9E9F9E" strokeWidth={.9*s} opacity=".8"/>
      <path d={`M ${netX(0,1)} ${y+netDepth} Q ${x} ${y+netDepth+3*s} ${netX(1,1)} ${y+netDepth}`} stroke="#969796" strokeWidth={.7*s} opacity=".65"/>
    </g>
    <path className="btc-hoop-glow" d={frontArc} stroke="var(--hoop-light)" strokeWidth={radius*2.3} opacity={lit?.25:0} filter={'url(#'+id+'-glow)'}/>
    <path d={frontArc} stroke="#7F542A" strokeWidth={radius*1.9}/>
    <path d={frontArc} stroke="var(--hoop-light)" strokeWidth={radius*1.4} opacity={lit?1:.55}/>
    <path d={`M ${x-half+4*s} ${y+1*s} Q ${x} ${y+ry*1.85} ${x+half-4*s} ${y+1*s}`} stroke="#FFE5A6" strokeWidth={.7*s} opacity={lit?.85:.25}/>
    {[-1,1].map(side=><circle key={side} cx={x+side*half} cy={y} r={radius} fill="var(--hoop-light)" opacity={lit?1:.55}/>)}
  </g>;
}
