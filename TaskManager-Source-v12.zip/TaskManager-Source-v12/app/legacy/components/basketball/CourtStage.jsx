import {useId} from 'react';
import {stageGeometry,polygon} from './stage-geometry';

export default function CourtStage({geometry:g}) {
  const id='deck-'+useId().replace(/[^a-zA-Z0-9_-]/g,'');
  const {scale:s,depth,point,corners:[a,b,c,d]}=stageGeometry(g);
  const lower=p=>({x:p.x,y:p.y+depth});
  const circle=Array.from({length:49},(_,i)=>point(.5+Math.cos(i*Math.PI/24)*.17,.5+Math.sin(i*Math.PI/24)*.3));
  return <g className="btc-stage-deck" fill="none" pointerEvents="none">
    <defs><linearGradient id={id} x1="0" y1="0" x2=".7" y2="1"><stop stopColor="#2B2C2B"/><stop offset="1" stopColor="#1C2222"/></linearGradient></defs>
    <ellipse cx={g.width*.54} cy={g.height-29*s} rx={g.width*.38} ry={27*s} fill="#070A09" opacity=".35"/>
    <polygon points={polygon([d,c,lower(c),lower(d)])} fill="#181918" stroke="#424342" strokeWidth=".9"/>
    <polygon points={polygon([b,c,lower(c),lower(b)])} fill="#1C1D1C" stroke="#424342" strokeWidth=".9"/>
    <polygon points={polygon([a,b,c,d])} fill={'url(#'+id+')'} stroke="#525352" strokeWidth="1"/>
    <polygon points={polygon([point(.04,.07),point(.96,.07),point(.96,.93),point(.04,.93)])} stroke="#515251" strokeWidth=".7" opacity=".7"/>
    <polyline points={polygon(circle)} stroke="#545554" strokeWidth=".7" opacity=".7"/>
    <path d={`M ${point(.5,.07).x} ${point(.5,.07).y} L ${point(.5,.93).x} ${point(.5,.93).y}`} stroke="#545554" strokeWidth=".7" opacity=".7"/>
    {[.1,.2,.3,.4,.5,.6,.7,.8,.9].map(t=>{const p=point(t,1);return <path key={t} d={`M ${p.x} ${p.y+3*s} v ${6*s}`} stroke="#434443" strokeWidth=".65"/>;})}
    <path className="btc-deck-led" d={`M ${point(.12,1).x} ${point(.12,1).y+depth*.5} L ${point(.32,1).x} ${point(.32,1).y+depth*.5}`} stroke="var(--btc-accent,#FFB45B)" strokeWidth={2*s} opacity=".7"/>
    {[point(.06,.1),point(.94,.1),point(.94,.9),point(.06,.9)].map((p,i)=><ellipse key={i} cx={p.x} cy={p.y} rx={2*s} ry={1.1*s} stroke="#737473" strokeWidth=".65"/>)}
  </g>;
}
