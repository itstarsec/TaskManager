import {useEffect,useRef} from 'react';
export default function useDialog(onClose) {
 const root=useRef(null),close=useRef(onClose),previous=useRef(typeof document==='undefined'?null:document.activeElement);close.current=onClose;
 useEffect(()=>{const element=root.current;if(!element)return;const focusable=()=>Array.from(element.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]')).filter(el=>el.getClientRects().length);
 if(!element.contains(document.activeElement))(focusable()[0]||element).focus();
 const key=e=>{if(e.key==='Escape'){e.preventDefault();close.current();}if(e.key==='Tab'){const items=focusable(),first=items[0],last=items.at(-1);if(!first){e.preventDefault();element.focus();}else if(e.shiftKey&&(document.activeElement===first||document.activeElement===element)){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};element.addEventListener('keydown',key);return()=>{element.removeEventListener('keydown',key);if(previous.current?.isConnected)previous.current.focus();};},[]);return root;
}
