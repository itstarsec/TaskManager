import * as THREE from 'three';
const laneIds=['todo','in_progress','completed'];
export function createDeskScene(host,initial,actions,rendererFactory=options=>new THREE.WebGLRenderer(options)) {
 let state=initial,disposed=false,frame=0,last=0,visible=true,drag=null,hovered=null,press=null,autoAngle=0;
 let azimuth=Math.PI/4,targetAzimuth=azimuth,elevation=.66,targetElevation=elevation;
 const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-7,7,5,-5,.1,100);
 const renderer=rendererFactory({antialias:true,alpha:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,matchMedia('(max-width:760px)').matches?1:1.5));
 renderer.setClearColor(0x191c1e,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;host.appendChild(renderer.domElement);
 const geometry=new THREE.BoxGeometry(1,1,1),edges=new THREE.EdgesGeometry(geometry),materials=new Map(),resources=new Set([geometry,edges]);
 const material=(color,emissive=0)=>{const key=color+':'+emissive;if(!materials.has(key))materials.set(key,new THREE.MeshStandardMaterial({color,roughness:.85,metalness:.22,emissive,emissiveIntensity:.65}));return materials.get(key);};
 const lineMaterial=new THREE.LineBasicMaterial({color:0x555957,transparent:true,opacity:.65});resources.add(lineMaterial);
 const addBox=(parent,x,y,z,w,h,d,color=0x252829,outline=true)=>{const m=new THREE.Mesh(geometry,material(color));m.position.set(x+w/2,y+h/2,z+d/2);m.scale.set(w,h,d);m.castShadow=true;m.receiveShadow=true;parent.add(m);if(outline)m.add(new THREE.LineSegments(edges,lineMaterial));return m;};
 scene.add(new THREE.HemisphereLight(0xe0e1dc,0x181a1b,2));
 const light=new THREE.DirectionalLight(0xffe7ce,3.1);light.position.set(-4,9,6);light.castShadow=true;light.shadow.mapSize.set(1024,1024);light.shadow.camera.left=-9;light.shadow.camera.right=9;light.shadow.camera.top=9;light.shadow.camera.bottom=-9;light.shadow.normalBias=.035;light.shadow.radius=4;scene.add(light);
 const groundGeometry=new THREE.PlaneGeometry(200,200);resources.add(groundGeometry);const shadowMaterial=new THREE.ShadowMaterial({opacity:.28});resources.add(shadowMaterial);const ground=new THREE.Mesh(groundGeometry,shadowMaterial);ground.rotation.x=-Math.PI/2;ground.position.y=-.33;ground.receiveShadow=true;scene.add(ground);
 const desk=new THREE.Group();scene.add(desk);addBox(desk,-5,-.3,-2.7,10,.4,5.4);
 // Every wall shares its tray's local coordinates and moves with the entire tray.
 const trays=laneIds.map((id,i)=>{const group=new THREE.Group();group.position.set(-4.5+i*3.1,.16,0);desk.add(group);const floor=addBox(group,0,0,-2,2.8,.15,3.5);addBox(group,0,.15,-2,2.8,.48,.12);addBox(group,0,.15,-1.88,.12,.48,3.38);addBox(group,2.68,.15,-1.88,.12,.48,3.38);const cards=Array.from({length:5},(_,j)=>addBox(group,.31,.16+j*.11,-1.6+j*.11,2.18,.085,2.5,0x303536));group.traverse(obj=>{if(obj.isMesh)obj.userData.lane=id;});const led=addBox(desk,-4.17+i*3.1,.12,1.8,.18,.06,.16,0x555957,false);return {id,group,cards,led,floor};});
 const create=addBox(desk,3.9,.12,1.7,.55,.12,.5,0xff9d3c);create.userData.action='create';
 // The button's cross is one assembly with the button, so it remains aligned when pressed.
 const crossMaterial=new THREE.MeshBasicMaterial({color:0x191c1e});resources.add(crossMaterial);
 for(const scale of [[.45,.08,.12],[.12,.08,.45]]){const cross=new THREE.Mesh(geometry,crossMaterial);cross.scale.set(...scale);cross.position.set(0,.53,0);create.add(cross);cross.userData.action='create';}
 const warning=addBox(desk,-4.4,.12,2.15,.16,.06,.12,0x555957,false);
 const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2(),target=new THREE.Vector3(0,0,0);
 const isMobile=()=>matchMedia('(max-width:760px)').matches;
 function canOrbit(){return !isMobile()||state.interactive;}
 function pick(event){const rect=host.getBoundingClientRect();pointer.set((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1);raycaster.setFromCamera(pointer,camera);return raycaster.intersectObjects(desk.children,true).find(hit=>hit.object.userData.lane||hit.object.userData.action)?.object.userData||null;}
 function down(e){if(e.button!==0)return;const hit=pick(e);drag={x:e.clientX,y:e.clientY,a:targetAzimuth,e:targetElevation,moved:false,id:e.pointerId};press=hit?.lane||hit?.action||null;if(canOrbit()){host.setPointerCapture(e.pointerId);e.preventDefault();}invalidate();}
 function move(e){const hit=pick(e);hovered=hit?.lane||null;host.style.cursor=state.busy?'wait':hit?(hit.action&&!state.canCreate?'default':'pointer'):canOrbit()?'grab':'auto';if(drag){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.hypot(dx,dy)>6){drag.moved=true;press=null;}if(drag.moved&&canOrbit()){targetAzimuth=THREE.MathUtils.clamp(drag.a-dx*.005,Math.PI/4-.65,Math.PI/4+.65);targetElevation=THREE.MathUtils.clamp(drag.e+dy*.004,.45,1.05);e.preventDefault();}}invalidate();}
 function up(e){if(!drag)return;const hit=pick(e);if(!drag.moved&&!state.busy){if(hit?.lane)actions.onSelect(hit.lane);if(hit?.action==='create'&&state.canCreate)actions.onCreate();}if(host.hasPointerCapture(e.pointerId))host.releasePointerCapture(e.pointerId);drag=null;press=null;invalidate();}
 function cancel(){drag=null;press=null;hovered=null;invalidate();}
 function leave(){hovered=null;if(!drag)press=null;invalidate();}
 function sync(){trays.forEach((t,i)=>{t.cards.forEach((card,j)=>{card.visible=j<Math.min(state.counts[i],5);card.material=material(state.selected===t.id?0x45413a:0x303536);});const active=state.selected===t.id;t.led.material=material(active?0xff9d3c:i===2?0x8fb79f:0x555957,active?0xff9d3c:0);t.floor.material=material(active?0x302d28:0x252829);});create.material=material(state.canCreate&&!state.busy?0xff9d3c:0x303536);warning.material=material(state.overdue?0xe7936d:0x555957,state.overdue?0x8f3720:0);host.style.touchAction=state.interactive?'none':'pan-y';}
 function render(time){frame=0;if(disposed||!visible||document.hidden)return;const dt=Math.min((time-last)/1000||.016,.05);last=time;let moving=false;
 const ease=state.reduced?1:Math.min(1,dt*14);
 if(state.auto&&!state.reduced&&!drag){autoAngle+=dt*.17;targetAzimuth=Math.PI/4+Math.sin(autoAngle)*.5;moving=true;}
 azimuth+=(targetAzimuth-azimuth)*ease;elevation+=(targetElevation-elevation)*ease;
 if(Math.abs(targetAzimuth-azimuth)>.0002||Math.abs(targetElevation-elevation)>.0002)moving=true;
 camera.position.set(Math.sin(azimuth)*13*Math.cos(elevation),Math.sin(elevation)*13,Math.cos(azimuth)*13*Math.cos(elevation));camera.lookAt(target);camera.updateMatrixWorld();
 trays.forEach(t=>{const y=.16+(state.selected===t.id?.1:0)+((hovered===t.id||state.hover===t.id)?.04:0)-(press===t.id?.06:0);t.group.position.y+=(y-t.group.position.y)*ease;if(Math.abs(y-t.group.position.y)>.001)moving=true;});
 const by=press==='create'?.13:.18;create.position.y+=(by-create.position.y)*ease;if(Math.abs(by-create.position.y)>.001)moving=true;
 renderer.render(scene,camera);if(moving)invalidate();}
 function invalidate(){if(!frame&&!disposed&&visible&&!document.hidden)frame=requestAnimationFrame(render);}
 function resize(){const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);const aspect=w/h,vertical=Math.max(4.25,6.6/aspect);camera.left=-vertical*aspect;camera.right=vertical*aspect;camera.top=vertical;camera.bottom=-vertical;camera.updateProjectionMatrix();invalidate();}
 function visibility(){if(document.hidden){cancelAnimationFrame(frame);frame=0;}else{last=0;invalidate();}}
 function lost(e){e.preventDefault();actions.onUnavailable();}
 const resizeObserver=new ResizeObserver(resize);resizeObserver.observe(host);
 const intersection=new IntersectionObserver(es=>{visible=es[0].isIntersecting;if(!visible){cancelAnimationFrame(frame);frame=0;}else{last=0;invalidate();}});intersection.observe(host);
 host.addEventListener('pointerdown',down);host.addEventListener('pointermove',move);host.addEventListener('pointerup',up);host.addEventListener('pointercancel',cancel);host.addEventListener('pointerleave',leave);renderer.domElement.addEventListener('webglcontextlost',lost);document.addEventListener('visibilitychange',visibility);
 sync();resize();
 return {update(next){if(next.reset!==state.reset){azimuth=targetAzimuth=Math.PI/4;elevation=targetElevation=.66;autoAngle=0;}state=next;sync();invalidate();},dispose(){disposed=true;cancelAnimationFrame(frame);resizeObserver.disconnect();intersection.disconnect();document.removeEventListener('visibilitychange',visibility);host.removeEventListener('pointerdown',down);host.removeEventListener('pointermove',move);host.removeEventListener('pointerup',up);host.removeEventListener('pointercancel',cancel);host.removeEventListener('pointerleave',leave);renderer.domElement.removeEventListener('webglcontextlost',lost);materials.forEach(m=>m.dispose());resources.forEach(r=>r.dispose());light.shadow.dispose();renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();}};
}
