import {lanes} from './dispatch-state';
// Orthographic projection of the same three contiguous trays used by the WebGL scene.
const project=(x,y,z)=>[320+(x-z)*29,210+(x+z)*14-y*37];
const points=ps=>ps.map(p=>project(...p).join(',')).join(' ');
function Block({x,y,z,w,h,d,fill='#252829',stroke='#555957',onClick,selected=false}) {
 const a=[x,y,z],b=[x+w,y,z],c=[x+w,y,z+d],e=[x,y,z+d],A=[x,y+h,z],B=[x+w,y+h,z],C=[x+w,y+h,z+d],E=[x,y+h,z+d];
 return <g onClick={onClick} style={onClick?{cursor:'pointer'}:undefined} className={selected?'desk-svg-selected':''} stroke={stroke} strokeWidth=".7" strokeLinejoin="round"><polygon points={points([e,c,C,E])} fill="#191C1E"/><polygon points={points([b,c,C,B])} fill="#202425"/><polygon points={points([A,B,C,E])} fill={fill}/></g>;
}
export default function DeskFallback({counts,selected,onSelect,onCreate,canCreate,overdue,busy}) {
 return <svg viewBox="60 55 520 300" className="desk-fallback" aria-hidden="true">
 <defs><radialGradient id="desk-shadow"><stop stopColor="#000" stopOpacity=".5"/><stop offset="1" stopColor="#000" stopOpacity="0"/></radialGradient><filter id="desk-glow"><feGaussianBlur stdDeviation="3"/></filter></defs>
 <ellipse cx="320" cy="305" rx="260" ry="72" fill="url(#desk-shadow)"/>
 <Block x={-5} y={-.3} z={-2.7} w={10} h={.4} d={5.4}/>
 {lanes.map((lane,i)=>{const x=-4.5+i*3.1,y=selected===lane.id?.26:.16;return <g className="desk-svg-tray" key={lane.id} onClick={()=>!busy&&onSelect(lane.id)} style={{cursor:busy?'wait':'pointer'}}>
 <Block x={x} y={y} z={-2} w={2.8} h={.15} d={3.5} stroke={selected===lane.id?'#FF9D3C':'#555957'}/>
 <Block x={x} y={y+.15} z={-2} w={2.8} h={.48} d={.12}/><Block x={x} y={y+.15} z={-1.88} w={.12} h={.48} d={3.38}/><Block x={x+2.68} y={y+.15} z={-1.88} w={.12} h={.48} d={3.38}/>
 {Array.from({length:Math.min(counts[i],5)},(_,j)=><Block key={j} x={x+.31} y={y+.16+j*.11} z={-1.6+j*.11} w={2.18} h={.085} d={2.5} fill={selected===lane.id?'#45413A':'#303536'} stroke={selected===lane.id?'#8B7051':'#555957'}/>)}
 <Block x={x+.33} y={.12} z={1.8} w={.18} h={.06} d={.16} fill={selected===lane.id?'#FF9D3C':lane.color} stroke={lane.color}/>
 {selected===lane.id&&<ellipse cx={project(x+.42,.19,1.87)[0]} cy={project(x+.42,.19,1.87)[1]} rx="7" ry="3" fill="#FF9D3C" opacity=".4" filter="url(#desk-glow)"/>}
 </g>;})}
 <Block x={3.9} y={.12} z={1.7} w={.55} h={.12} d={.5} fill={canCreate?'#FF9D3C':'#303536'} onClick={()=>canCreate&&!busy&&onCreate()}/>
 <g stroke="#211A13" strokeWidth="1.8" strokeLinecap="round"><polyline points={points([[4.01,.25,1.95],[4.34,.25,1.95]])}/><polyline points={points([[4.175,.25,1.79],[4.175,.25,2.11]])}/></g>
 <Block x={-4.4} y={.12} z={2.15} w={.16} h={.06} d={.12} fill={overdue?'#E7936D':'#555957'}/>
 </svg>;
}
