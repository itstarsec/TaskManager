import {parseApiDate} from '../../services/realtime.js';
export const lanes = [
  { id: 'todo', label: 'Chưa bắt đầu', short: 'Chờ xử lý', code: '01', color: '#8B918D' },
  { id: 'in_progress', label: 'Đang thực hiện', short: 'Đang làm', code: '02', color: '#FF9D3C' },
  { id: 'completed', label: 'Hoàn thành', short: 'Hoàn thành', code: '03', color: '#8FB79F' },
];
export function dispatchState(tasks, now = new Date()) {
  return { counts: lanes.map(l => tasks.filter(t => t.status === l.id).length), overdue: tasks.filter(t => t.status !== 'completed' && t.deadline && parseApiDate(t.deadline) < now).length };
}
export function laneTasks(tasks, lane) {
  return tasks.filter(t => t.status === lane).slice().sort((a,b) => (a.deadline ? parseApiDate(a.deadline).getTime() : Infinity) - (b.deadline ? parseApiDate(b.deadline).getTime() : Infinity));
}
