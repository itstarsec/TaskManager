import {useEffect,useRef} from 'react';
export default function DeskScene({state,onSelect,onCreate,onUnavailable,onReady}) {
 const host=useRef(null),engine=useRef(null),latest=useRef(state),actions=useRef({onSelect,onCreate,onUnavailable,onReady});
 latest.current=state;actions.current={onSelect,onCreate,onUnavailable,onReady};
 useEffect(()=>{let disposed=false;
 import('./scene-engine').then(({createDeskScene})=>{if(disposed)return;engine.current=createDeskScene(host.current,latest.current,{onSelect:id=>actions.current.onSelect(id),onCreate:()=>actions.current.onCreate(),onUnavailable:()=>actions.current.onUnavailable()});actions.current.onReady();}).catch(()=>!disposed&&actions.current.onUnavailable());
 return()=>{disposed=true;engine.current?.dispose();engine.current=null;};},[]);
 useEffect(()=>{engine.current?.update(state);},[state]);
 return <div ref={host} className={'desk-webgl'+(state.interactive?' interactive':'')} aria-hidden="true"/>;
}
