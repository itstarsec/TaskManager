import {useCallback,useEffect,useState} from 'react';
import {Bell,CheckCheck,ArrowUpRight,RefreshCw} from 'lucide-react';
import Link from 'next/link';
import api from '../services/api';
import {parseApiDate} from '../services/realtime';
export default function PersonalNotifications(){
 const [items,setItems]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(''),[unreadOnly,setUnreadOnly]=useState(false),[busy,setBusy]=useState(false);
 const load=useCallback(async()=>{try{setError('');const {data}=await api.get('/notifications');setItems(data);}catch(e){setError(e.message);}finally{setLoading(false);}},[]);
 useEffect(()=>{load();const timer=setInterval(()=>{if(!document.hidden)load();},30000);return()=>clearInterval(timer);},[load]);
 const mark=async id=>{setBusy(true);setError('');try{await api.patch(id?`/notifications/${id}/read`:'/notifications/read-all');setItems(current=>current.map(n=>!id||n.id===id?{...n,is_read:true}:n));}catch(e){setError(e.message);}finally{setBusy(false);}};
 const unread=items.filter(n=>!n.is_read).length,shown=unreadOnly?items.filter(n=>!n.is_read):items;
 return <section className="work-panel personal-notifications" aria-label="Nhắc việc cá nhân"><div className="panel-heading"><div><h2>Nhắc việc & cập nhật <span className="count-badge">{unread} chưa đọc</span></h2><p>Việc được giao, thay đổi công việc và nhắc hạn dành cho bạn.</p></div><div className="button-row"><button className="icon-action" aria-label="Tải lại nhắc việc" onClick={load}><RefreshCw size={16}/></button><button className="secondary-action" disabled={!unread||busy} onClick={()=>mark()}><CheckCheck size={16}/>Đọc tất cả</button></div></div>
 <div className="queue-tabs" role="group" aria-label="Lọc nhắc việc"><button aria-pressed={!unreadOnly} className={!unreadOnly?'active':''} onClick={()=>setUnreadOnly(false)}>Tất cả <span>{items.length}</span></button><button aria-pressed={unreadOnly} className={unreadOnly?'active':''} onClick={()=>setUnreadOnly(true)}>Chưa đọc <span>{unread}</span></button></div>
 {error&&<div className="dashboard-error" role="alert">{error}</div>}
 {loading?<div className="clean-empty" role="status">Đang tải nhắc việc…</div>:!shown.length?<div className="clean-empty"><Bell size={28}/><h3>{unreadOnly?'Bạn đã đọc hết thông báo':'Chưa có nhắc việc'}</h3><p>Các cập nhật và nhắc hạn liên quan đến bạn sẽ hiển thị tại đây.</p></div>:<div className="personal-notification-list">{shown.map(n=><article key={n.id} className={'personal-notification '+(!n.is_read?'unread':'')}><span className="personal-notification-icon"><Bell size={18}/></span><div><h3>{n.title}</h3><p>{n.message}</p><time>{parseApiDate(n.created_at)?.toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})}</time><div className="button-row">{n.task_id&&<Link href={'/tasks?task='+n.task_id} className="text-link">Mở công việc<ArrowUpRight size={14}/></Link>}{!n.is_read&&<button className="tiny-button" disabled={busy} onClick={()=>mark(n.id)}>Đánh dấu đã đọc</button>}</div></div></article>)}</div>}
 </section>;
}
