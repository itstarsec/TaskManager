import {NavLink} from '../services/router';
import {LayoutDashboard,ListTodo,CheckCheck,Inbox,Bell,ChartNoAxesCombined,Settings2,Network,LockKeyhole,ArrowUpRight,X} from 'lucide-react';
import {useAuth} from '../services/auth-context';
import {workspaceSections,workspaceVisible} from '../services/workspaces';
const icons={'/dashboard':LayoutDashboard,'/tasks':ListTodo,'/my-tasks':CheckCheck,'/support':Inbox,'/notifications':Bell,'/reports':ChartNoAxesCombined,'/support/settings':Network,'/settings':Settings2};
export default function Sidebar(){const user=useAuth();return <>
 <button className="sidebar-scrim" aria-label="Đóng menu" onClick={()=>document.querySelector('.sidebar')?.classList.remove('mobile-open')}/>
 <aside className="sidebar"><div className="sidebar-logo"><img src="/miraway-logo.png" className="sidebar-logo-image" alt="Miraway"/><div><div className="logo-title">Task Manager<span className="brand-dot">.</span></div><div className="logo-subtitle">MIRAWAY WORKSPACE</div></div><button className="mobile-close" aria-label="Đóng menu" onClick={()=>document.querySelector('.sidebar')?.classList.remove('mobile-open')}><X size={20}/></button></div>
 <div className="workspace-label"><span className="workspace-avatar">M</span><div><strong>Không gian làm việc</strong><span>Công việc có tổ chức.</span></div></div>
 <nav className="sidebar-nav" aria-label="Các phân hệ nghiệp vụ">{workspaceSections.map(({label,items})=><div className="nav-section" key={label}><div className="nav-section-title">{label}</div>{items.filter(item=>workspaceVisible(item,user)).map(item=>{const Icon=icons[item.href];return <NavLink end key={item.href} to={item.href} title={item.description} className={({isActive})=>'nav-item'+(isActive?' active':'')}><Icon size={18}/><span>{item.label}</span></NavLink>;})}</div>)}</nav>
 <div className="sidebar-bottom"><div className="private-space"><LockKeyhole size={16}/><div><strong>Truy cập có phân quyền</strong><span>{user?.is_super_admin?'Quản trị cao nhất':user?.role||'Tài khoản được cấp'}</span></div></div><div className="sidebar-footnote"><span>Miraway · Task Manager</span><ArrowUpRight size={13}/></div></div></aside></>}
