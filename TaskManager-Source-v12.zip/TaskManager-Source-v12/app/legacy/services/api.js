const inflight = new Map();
const connectionError = () => {
  const error = new Error('Kết nối bị gián đoạn hoặc phản hồi quá lâu. Vui lòng thử lại.');
  error.response = {status:0,data:{detail:error.message}};
  return error;
};
async function perform(method, path, data, options) {
  const controller = new AbortController();
  const timeoutMs = Number.isFinite(options.timeoutMs) && options.timeoutMs > 0 ? options.timeoutMs : 20000;
  let timer, stop;
  const deadline = new Promise((_, reject) => {
    stop = () => { controller.abort(); reject(connectionError()); };
    if (options.signal?.aborted) stop();
    else {
      options.signal?.addEventListener('abort', stop, {once:true});
      timer = setTimeout(stop, timeoutMs);
    }
  });
  const work = (async () => {
    try {
      if (controller.signal.aborted) throw connectionError();
      const response = await fetch('/api' + path, {
        method, cache:'no-store', credentials:'include', signal:controller.signal,
        headers:{'Content-Type':'application/json',...options.headers},
        body:data === undefined ? undefined : JSON.stringify(data)
      });
      // Bound both connection setup and body reading, even if fetch ignores abort.
      const payload = await response.json().catch(() => null);
      if (controller.signal.aborted) throw connectionError();
      if (response.status === 401 && path !== '/auth/login') window.location.replace('/login');
      if (!response.ok || payload === null) {
        const error = new Error(payload?.detail || 'Không tải được dữ liệu. Vui lòng tải lại trang.');
        error.response = {status:response.status,data:payload || {detail:error.message}};
        throw error;
      }
      if (method !== 'GET') {
        const entity = path.startsWith('/tasks') ? 'task' : path.startsWith('/support') ? 'support_ticket' : 'other';
        window.dispatchEvent(new CustomEvent('taskmanager:realtime',{detail:{type:'data_changed',entity}}));
      }
      return {data:payload,status:response.status};
    } catch (error) { throw error.response ? error : connectionError(); }
  })();
  try { return await Promise.race([work, deadline]); }
  finally { clearTimeout(timer); options.signal?.removeEventListener('abort', stop); }
}
async function request(method, path, data, options = {}) {
  const key = method + path;
  // Cancellable/retried reads must not inherit another caller's pending request.
  const shared = method === 'GET' && options.dedupe !== false && !options.signal;
  if (shared && inflight.has(key)) return inflight.get(key);
  const run = perform(method,path,data,options);
  if (shared) inflight.set(key,run);
  try { return await run; }
  finally { if (shared && inflight.get(key) === run) inflight.delete(key); }
}
const api = {defaults:{baseURL:'/api'}};
for(const method of ['get','post','put','patch','delete']) api[method]=(path,data,options)=>request(method.toUpperCase(),path,data,options);
export default api;
