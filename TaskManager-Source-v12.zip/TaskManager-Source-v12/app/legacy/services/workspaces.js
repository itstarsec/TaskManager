export const workspaceSections=[
 {label:'CÔNG VIỆC',items:[
  {href:'/dashboard',label:'Tổng quan',description:'Thống kê tiến độ và truy cập nhanh các nghiệp vụ.'},
  {href:'/tasks',label:'Tất cả công việc',description:'Tạo, phân công, tìm kiếm và lọc công việc; xem danh sách hoặc bảng tiến độ.'},
  {href:'/my-tasks',label:'Việc của tôi',description:'Việc bạn phụ trách hoặc hỗ trợ; cập nhật tiến độ, checklist và bình luận.'}
 ]},
 {label:'PHỐI HỢP',items:[
  {href:'/support',label:'Yêu cầu hỗ trợ',description:'Tạo yêu cầu, phân công xử lý, theo dõi trạng thái và trao đổi.'},
  {href:'/notifications',label:'Bảng thông báo',description:'Thông báo chung, thông báo nhóm và nhắc việc cá nhân; đánh dấu đã đọc.'}
 ]},
 {label:'QUẢN LÝ',items:[
  {href:'/reports',label:'Báo cáo',description:'Thống kê hoàn thành, quá hạn, phân bổ công việc; xuất CSV và sao lưu theo quyền.'},
  {href:'/support/settings',label:'Phòng ban & nhóm',description:'Quản lý phòng ban, nhóm hỗ trợ, thành viên và quy tắc phân tuyến.',roles:['admin','supervisor','leader']},
  {href:'/settings',label:'Cài đặt',description:'Quản lý tài khoản, vai trò và bảo mật theo quyền được cấp.'}
 ]}
];
export const workspaces=workspaceSections.flatMap(section=>section.items);
export const workspaceVisible=(item,user)=>!item.roles||item.roles.includes(user?.role_code);
