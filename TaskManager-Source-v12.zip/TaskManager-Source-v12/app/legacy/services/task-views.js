import {parseApiDate} from './realtime.js';
export const taskStates=[['todo','Chưa bắt đầu'],['in_progress','Đang thực hiện'],['completed','Hoàn thành']];
const vnDay=date=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
export function taskMatchesQueue(task,queue,userId,now=new Date()){
 const open=task.status!=='completed',deadline=parseApiDate(task.deadline);
 if(queue==='overdue')return !!(open&&deadline&&deadline<now);
 if(queue==='today')return !!(open&&deadline&&vnDay(deadline)===vnDay(now));
 if(queue==='unassigned')return open&&!task.assignee_id;
 if(queue==='assigned')return task.assignee_id===userId;
 if(queue==='supporting')return task.assignee_id!==userId&&(task.supporters||[]).some(s=>s.user_id===userId);
 if(queue==='completed')return !open;
 return true;
}
export function filterTasks(tasks,{search='',status='all',priority='all',assignee='all',queue='all',userId,now=new Date()}={}){
 const text=search.toLocaleLowerCase('vi').trim();
 return tasks.filter(t=>(!text||(t.title+' '+(t.description||'')).toLocaleLowerCase('vi').includes(text))
  &&(status==='all'||t.status===status)&&(priority==='all'||t.priority===priority)
  &&(assignee==='all'||String(t.assignee_id)===assignee)
  &&taskMatchesQueue(t,queue,userId,now))
 .sort((a,b)=>Number(a.status==='completed')-Number(b.status==='completed')
  ||(parseApiDate(a.deadline)?.getTime()||Infinity)-(parseApiDate(b.deadline)?.getTime()||Infinity)
  ||b.id-a.id);
}
