import api from './api.js';
export const emptyTaskDraft=()=>({title:'',description:'',priority:'medium',deadline:'',assigneeId:'',supporterIds:[],subtasks:[{title:''}]});
export function prepareTask(draft){
 const title=draft.title.trim();if(!title||title.length>200)throw new Error('Tên công việc cần từ 1 đến 200 ký tự.');
 if(!['low','medium','high','urgent'].includes(draft.priority))throw new Error('Mức ưu tiên không hợp lệ.');
 if(draft.deadline&&(!/^\d{4}-\d{2}-\d{2}$/.test(draft.deadline)||!Number.isFinite(Date.parse(draft.deadline+'T00:00:00Z'))||new Date(draft.deadline+'T00:00:00Z').toISOString().slice(0,10)!==draft.deadline))throw new Error('Hạn chót không hợp lệ.');
 const subtasks=draft.subtasks.filter(s=>s.title.trim()).map(s=>({title:s.title.trim()}));
 if(subtasks.length>100||subtasks.some(s=>s.title.length>200))throw new Error('Tối đa 100 việc con, mỗi việc tối đa 200 ký tự.');
 return {title,description:draft.description.trim()||null,assignee_id:draft.assigneeId?Number(draft.assigneeId):null,priority:draft.priority,deadline:draft.deadline?`${draft.deadline}T23:59:59+07:00`:null,subtasks,supporter_ids:[...new Set(draft.supporterIds)].filter(id=>id!==Number(draft.assigneeId)).sort((a,b)=>a-b)};
}
export const createTask=async(payload,{key,signal}={})=>(await api.post('/tasks',payload,{headers:{'Idempotency-Key':key},signal})).data;
export const verifyTaskCreation=async(key,signal)=>(await api.get('/tasks/creation-status?key='+encodeURIComponent(key),undefined,{signal})).data;
