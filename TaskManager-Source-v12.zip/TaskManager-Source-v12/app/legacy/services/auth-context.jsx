import {createContext,useContext} from 'react';
export const AuthContext=createContext(null);
export const useAuth=()=>useContext(AuthContext);
export const can=(user,permission)=>!!user?.permissions?.some(p=>p==='*'||p===permission);
