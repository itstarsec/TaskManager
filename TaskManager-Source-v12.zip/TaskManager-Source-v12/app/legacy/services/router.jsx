import { useCallback, useMemo } from 'react';
import { usePathname, useRouter, useSearchParams as useNextParams } from 'next/navigation';
export function NavLink({to,end,className,children,...props}) {
 const pathname=usePathname();const isActive=end?pathname===to:pathname===to||pathname.startsWith(to+'/');
 // Business tabs load their full document, including the authenticated layout.
 // This also works through proxies that do not preserve RSC navigation payloads.
 return <a href={to} className={typeof className==='function'?className({isActive}):className} aria-current={isActive?'page':undefined} {...props}>{children}</a>;
}
export function useNavigate(){const router=useRouter();return useCallback((to,opts)=>opts?.replace?router.replace(to):router.push(to),[router]);}
export function useSearchParams(){const params=useNextParams();const router=useRouter();const path=usePathname();const str=params.toString();const value=useMemo(()=>new URLSearchParams(str),[str]);const set=useCallback((v,opts)=>{const q=new URLSearchParams(v).toString();router[opts?.replace?'replace':'push'](path+(q?'?'+q:''),{scroll:false});},[path,router]);return [value,set];}
