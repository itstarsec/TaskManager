import type { Metadata } from 'next';
import './legacy/Dashboard.css';
import './legacy/Support.css';
import './legacy/SupportOrganization.css';
import './legacy/Notifications.css';
import './globals.css';
import './workspace.css';
import './design-tokens.css';
import './isometric.css';
import './basketball.css';
export const metadata:Metadata={title:'Task Manager · Miraway',description:'Không gian quản lý công việc, hỗ trợ và đội nhóm của bạn.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="vi"><body>{children}</body></html>;}
