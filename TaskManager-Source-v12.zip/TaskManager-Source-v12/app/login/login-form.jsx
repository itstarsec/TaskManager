'use client';
import { useState } from 'react';
import { ArrowRight, Eye, EyeOff, LockKeyhole, CheckCheck } from 'lucide-react';
export default function LoginForm() {
  const [username,setUsername]=useState(''),[password,setPassword]=useState(''),[visible,setVisible]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const submit=async e=>{
    e.preventDefault();setBusy(true);setError('');
    try {
      const response=await fetch('/api/auth/login',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
      const data=await response.json();
      if(!response.ok)throw new Error(data.detail||'Không thể đăng nhập.');
      const session=await fetch('/api/auth/me',{credentials:'include',cache:'no-store'});
      if(session.status===401)throw new Error('Thông tin đăng nhập đúng nhưng phiên chưa được lưu trên domain này. Vui lòng cho phép cookie và thử lại.');
      if(!session.ok)throw new Error('Chưa thể xác nhận phiên đăng nhập. Vui lòng thử lại.');
      window.location.replace('/dashboard');
    } catch(e){setError(e.message||'Mất kết nối. Vui lòng thử lại.');setBusy(false);}
  };
  return <main className="login-layout"><section className="login-story"><a className="login-brand" href="/login"><img src="/miraway-logo.png" alt="Miraway"/><span>Task Manager<span className="brand-dot">.</span></span></a><div className="login-story-body"><span className="eyebrow">MIRAWAY WORKSPACE</span><h1>Mọi việc,<br/>trong tầm tay.</h1><p>Một nơi để giữ nhịp công việc, kết nối đội ngũ và theo dõi những điều quan trọng.</p><div className="login-task"><CheckCheck size={24}/><div><strong>Cùng nhau tiến về phía trước</strong><span>Rõ trách nhiệm. Đúng tiến độ.</span></div></div></div><small>Miraway · Không gian quản lý công việc</small></section><section className="login-main"><div className="login-card"><div className="login-symbol"><LockKeyhole size={24}/></div><h2>Chào mừng trở lại.</h2><p>Đăng nhập để mở không gian làm việc của bạn.</p>{error&&<div className="dashboard-error" role="alert">{error}</div>}<form onSubmit={submit}><label className="field-label">Tên đăng nhập<input autoComplete="username" name="username" autoFocus required maxLength={50} value={username} onChange={e=>setUsername(e.target.value)} placeholder="Nhập tên đăng nhập"/></label><label className="field-label">Mật khẩu<div className="password-field"><input type={visible?'text':'password'} autoComplete="current-password" name="password" required maxLength={128} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Nhập mật khẩu"/><button type="button" aria-label={visible?'Ẩn mật khẩu':'Hiện mật khẩu'} onClick={()=>setVisible(!visible)}>{visible?<EyeOff size={18}/>:<Eye size={18}/>}</button></div></label><button className="create-task-button login-submit" disabled={busy}>{busy?'Đang đăng nhập…':'Đăng nhập'}<ArrowRight size={17}/></button></form><p className="login-help">Chưa có tài khoản hoặc quên mật khẩu?<br/>Liên hệ quản trị viên để được cấp quyền truy cập.</p></div><small className="login-footer"><LockKeyhole size={12}/> Quyền truy cập theo tài khoản được cấp</small></section></main>;
}
