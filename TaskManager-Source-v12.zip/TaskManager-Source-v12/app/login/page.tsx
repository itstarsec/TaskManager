import { redirect } from 'next/navigation';
import { currentUser } from '../local-auth';
import LoginForm from './login-form';
export const dynamic = 'force-dynamic';
export default async function LoginPage() {
  if (await currentUser()) redirect('/dashboard');
  return <LoginForm/>;
}
