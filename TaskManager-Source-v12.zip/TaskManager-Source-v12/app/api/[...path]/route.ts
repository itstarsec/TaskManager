import { env } from 'cloudflare:workers';
import { handleApi } from '../../../lib/api-engine';
import { corsPreflight,withCors } from '../../../lib/cors';
export const dynamic='force-dynamic';
async function handler(request:Request){
 const preflight=corsPreflight(request);if(preflight)return preflight;
 if(!env.DB)return withCors(request,Response.json({detail:'Cơ sở dữ liệu chưa sẵn sàng.'},{status:503}));
 return handleApi(request,{db:env.DB,bucket:env.BUCKET,config:env as unknown as Record<string,string>});
}
export {handler as GET,handler as HEAD,handler as POST,handler as PUT,handler as PATCH,handler as DELETE,handler as OPTIONS};
