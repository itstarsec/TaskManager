import View from '../../legacy/pages/Support';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
