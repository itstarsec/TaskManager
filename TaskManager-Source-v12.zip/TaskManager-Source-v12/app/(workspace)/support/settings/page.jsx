import View from '../../../legacy/pages/SupportOrganization';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
