import View from '../../legacy/pages/Tasks';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
