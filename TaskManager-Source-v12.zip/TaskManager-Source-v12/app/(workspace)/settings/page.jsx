import View from '../../legacy/pages/Settings';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
