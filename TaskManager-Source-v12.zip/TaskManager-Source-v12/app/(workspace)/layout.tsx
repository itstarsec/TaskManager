import { requireLocalUser } from '../local-auth';
import WorkspaceClient from '../workspace-client';
import { env } from 'cloudflare:workers';
import { publicUserProfile } from '../../lib/api-engine';

export const dynamic = 'force-dynamic';
export default async function WorkspaceLayout({children}:{children:React.ReactNode}) {
  const user=await requireLocalUser();
  const database=env.DB;
  if(!database) throw new Error('Không thể kết nối dữ liệu. Vui lòng thử lại.');
  const role=await database.prepare('SELECT * FROM roles WHERE id=?').bind(user.role_id).first();
  return <WorkspaceClient initialUser={publicUserProfile(user,role)}>{children}</WorkspaceClient>;
}
