import View from '../../legacy/pages/Dashboard';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
