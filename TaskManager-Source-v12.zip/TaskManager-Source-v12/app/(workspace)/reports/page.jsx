import View from '../../legacy/pages/Reports';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
