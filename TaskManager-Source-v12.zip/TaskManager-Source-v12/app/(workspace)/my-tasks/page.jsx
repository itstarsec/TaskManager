import View from '../../legacy/pages/MyTasks';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
