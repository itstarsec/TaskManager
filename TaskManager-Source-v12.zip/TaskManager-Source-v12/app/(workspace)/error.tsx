'use client';
export default function WorkspaceError({reset}:{reset:()=>void}) {
  return <main className="boot-screen"><h1>Không thể mở trang này</h1><p>Nội dung chưa tải được. Bạn có thể thử lại hoặc quay về Tổng quan.</p><button className="create-task-button" onClick={reset}>Thử lại</button><a href="/dashboard">Về Tổng quan</a><a href="/login">Đăng nhập lại</a></main>;
}
