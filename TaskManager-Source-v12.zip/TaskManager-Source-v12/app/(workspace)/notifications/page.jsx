import View from '../../legacy/pages/Notifications';
export const dynamic='force-dynamic';
export default function Page(){return <View/>;}
