import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { env } from 'cloudflare:workers';
import { getSessionUser } from '../lib/auth';

export async function currentUser() {
  if (!env.DB) return null;
  const h = await headers();
  return getSessionUser(new Request('https://local.invalid', {headers: {cookie: h.get('cookie') || ''}}), env.DB);
}
export async function requireLocalUser() {
  const user = await currentUser();
  if (!user) redirect('/login');
  return user;
}
