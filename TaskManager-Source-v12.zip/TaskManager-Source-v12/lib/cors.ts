// Any HTTP(S) origin may authenticate. Credentialed CORS requires an exact
// reflected origin, not the literal wildcard. Authorization remains in auth.ts.
const methods=['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'];
const defaultHeaders='Content-Type, Authorization, X-Maintenance-Token';
// Owner-approved browser entry points. These two origins may use the same
// authenticated session when navigating through the Pages reverse proxy.
const trustedBrowserOrigins=new Set([
 'https://taskmanager-1610.exactlamp6.chatgpt.site',
 'https://hoptacxa.pages.dev'
]);
export const isTrustedBrowserOrigin=(origin:string|null)=>!!origin&&trustedBrowserOrigins.has(origin);
export const compatibleSessionOrigins=(loginOrigin:string,origin:string)=>loginOrigin===origin||(isTrustedBrowserOrigin(loginOrigin)&&isTrustedBrowserOrigin(origin));
export function requestOrigin(request:Request):string|null {
 const raw=request.headers.get('origin');
 if(raw===null)return null;
 try {
  const url=new URL(raw);
  if(['https:','http:'].includes(url.protocol)&&url.origin===raw)return raw;
 }catch{}
 throw new Error('Origin cần là một địa chỉ HTTP hoặc HTTPS hợp lệ.');
}
export function withCors(request:Request,response:Response):Response {
 const headers=new Headers(response.headers);
 const vary=new Set((headers.get('Vary')||'').split(',').map(x=>x.trim()).filter(Boolean));
 vary.add('Origin');headers.set('Vary',[...vary].join(', '));
 headers.set('Cache-Control','no-store');
 headers.set('X-Content-Type-Options','nosniff');
 try {
  const origin=requestOrigin(request);
  if(origin){headers.set('Access-Control-Allow-Origin',origin);headers.set('Access-Control-Allow-Credentials','true');}
 }catch{}
 return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}
export function corsPreflight(request:Request):Response|null {
 try {requestOrigin(request);}catch(e){return withCors(request,Response.json({detail:(e as Error).message},{status:400}));}
 if(request.method!=='OPTIONS')return null;
 const requested=request.headers.get('access-control-request-method');
 const requestedHeaders=request.headers.get('access-control-request-headers')||defaultHeaders;
 if(requested&&!methods.includes(requested.toUpperCase()))return withCors(request,Response.json({detail:'Phương thức không được hỗ trợ.'},{status:405}));
 if(requestedHeaders.length>4096||requestedHeaders.split(',').some(h=>!/^[-!#$%&'*+.^_`|~0-9a-z]+$/i.test(h.trim())))return withCors(request,Response.json({detail:'Header yêu cầu không hợp lệ.'},{status:400}));
 return withCors(request,new Response(null,{status:204,headers:{
  'Allow':methods.join(', '),
  'Access-Control-Allow-Methods':methods.join(', '),
  'Access-Control-Allow-Headers':requestedHeaders,
  'Access-Control-Max-Age':'600',
  'Vary':'Origin, Access-Control-Request-Method, Access-Control-Request-Headers'
 }}));
}
