import columns from './legacy-columns.json';
import { getSessionUser, sha256, handleLogin, hashPassword, verifyPassword, validPassword, revokeSessions, clearedSessionHeaders, sessionToken, serviceAuthorized } from './auth';
import { corsPreflight, withCors } from './cors';
type Row = Record<string, any>;
type Context = {db:D1Database; bucket?:R2Bucket; config?:Record<string,string>};
class HttpError extends Error { constructor(public status:number,message:string){super(message);} }
function fail(status:number,message:string):never {throw new HttpError(status,message);}
const now=()=>new Date().toISOString();
const boolFields=['is_active','must_change_password','is_super_admin','completed','is_read'];
const clean=(r:Row):Row=>{const out={...r};for(const k of boolFields)if(k in out)out[k]=!!out[k];for(const k of Object.keys(out))if((k.endsWith('_at')||k==='deadline')&&typeof out[k]==='string'&&!/(Z|[+-]\d\d:\d\d)$/i.test(out[k]))out[k]=out[k].replace(' ','T')+'Z';return out;};
const roleMap:Row={management:'supervisor',project_manager:'supervisor',support:'user',sale:'user',pre_sale:'user',developer:'user'};
const effectiveRole=(u:Row,r:Row|null)=>u.is_super_admin?'admin':r?.code==='admin'?'supervisor':roleMap[r?.code]||r?.code||'user';
const roleNames:Row={admin:'Admin',supervisor:'Supervisor',leader:'Leader',user:'User',viewer:'Viewer'};
const permissions:Row={viewer:['task.view_assigned','support.view_own'],admin:['*'],supervisor:['task.view_all','task.create','task.edit','task.delete','task.assign','task.supporter','task.status','task.subtask','support.view_all','support.create','support.comment','support.claim','support.assign','support.status','support.team.manage','support.team.delete','support.member.manage','support.member.remove','support.routing.manage','announcement.company','announcement.team','announcement.view_all','user.view'],leader:['support.create','task.view_team','task.status','task.subtask','support.view_team','support.comment','support.claim','support.assign','support.status','support.routing.edit','announcement.team'],user:['task.view_assigned','task.status','task.subtask','support.create','support.view_own','support.comment']};
const pick=(obj:Row,keys:string[])=>Object.fromEntries(keys.filter(k=>k in obj&&obj[k]!==undefined).map(k=>[k,obj[k]]));
const required=(v:any,label='Nội dung',max=10000)=>{if(typeof v!=='string'||!v.trim()||v.trim().length>max)fail(400,`${label} không được trống và tối đa ${max} ký tự.`);return v.trim();};
const enumValue=(v:any,valid:string[],label:string)=>{if(!valid.includes(v))fail(400,`${label} không hợp lệ.`);return v;};
const normalize=(s:string)=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d');
export function publicUserProfile(u:Row,r:Row|null):Row {
 const code=effectiveRole(u,r);
 return {...pick(u,['id','username','full_name','position','avatar_url','is_active','email','role_id']),must_change_password:!!u.must_change_password,is_super_admin:!!u.is_super_admin,has_password:!!u.password_hash,role:roleNames[code]||r?.name||'User',role_code:code,permissions:permissions[code]||permissions.user};
}
export async function handleApi(request:Request, ctx:Context):Promise<Response>{
 const preflight=corsPreflight(request);if(preflight)return preflight;
 const response=await routeApi(request.method==='HEAD'?new Request(request,{method:'GET'}):request,ctx);
 return withCors(request,request.method==='HEAD'?new Response(null,response):response);
}
async function routeApi(request:Request, ctx:Context):Promise<Response>{
 const db=ctx.db, url=new URL(request.url), path=url.pathname.replace(/^\/api\/?/,'').replace(/\/$/,''), parts=path.split('/'), method=request.method;
 const stmt=(sql:string,...args:any[])=>db.prepare(sql).bind(...args.map(x=>typeof x==='boolean'?Number(x):x===undefined?null:x));
 const all=async(sql:string,...args:any[])=>((await stmt(sql,...args).all<Row>()).results||[]).map(clean);
 const one=async(sql:string,...args:any[])=>{const row=await stmt(sql,...args).first<Row>();return row?clean(row):null;};
 const get=async(table:string,id:any)=>one(`SELECT * FROM ${table} WHERE id=?`,Number(id));
 const must=async(table:string,id:any)=>await get(table,id)||fail(404,'Không tìm thấy dữ liệu.');
 const insertStmt=(table:string,data:Row)=>{const ks=Object.keys(data);return stmt(`INSERT INTO ${table} (${ks.join(',')}) VALUES (${ks.map(()=>'?').join(',')})`,...ks.map(k=>data[k]));};
 const insert=async(table:string,data:Row)=>{const r=await insertStmt(table,data).run();return Number(r.meta.last_row_id);};
 const updateStmt=(table:string,id:number,data:Row)=>{const ks=Object.keys(data);return stmt(`UPDATE ${table} SET ${ks.map(k=>k+'=?').join(',')} WHERE id=?`,...ks.map(k=>data[k]),id);};
 const update=async(table:string,id:number,data:Row)=>{if(Object.keys(data).length)await updateStmt(table,id,data).run();return must(table,id);};
 const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 try {
  if(!['GET','HEAD'].includes(method)&&request.body!==null&&!request.headers.get('content-type')?.toLowerCase().startsWith('application/json'))fail(415,'Dữ liệu cần ở định dạng JSON.');
  if(path==='auth/login'){
   if(method!=='POST')fail(405,'Phương thức không hợp lệ.');
   return await handleLogin(request,db,ctx.config||{});
  }
  if(path==='_migration')fail(404,'Chức năng đã được đóng sau chuyển đổi.');
  const rawUser=await getSessionUser(request,db);
  if(path==='auth/logout'&&method==='POST'){
   if(sessionToken(request)&&!rawUser)fail(401,'Vui lòng đăng nhập tại domain này.');
   if(rawUser)await stmt('DELETE FROM auth_sessions WHERE token_hash=?',rawUser.session_hash).run();
   return Response.json({success:true},{headers:clearedSessionHeaders(request)});
  }
  const deadlineCheck=async()=>{
   const tasks=await all("SELECT * FROM tasks WHERE deadline IS NOT NULL AND status != 'completed'");let made=0;
   for(const t of tasks){const due=new Date(clean(t).deadline).getTime();if(!Number.isFinite(due)||due>Date.now()+86400000)continue;const type=due<Date.now()?'task_overdue':'task_deadline_soon';const title=type==='task_overdue'?'Công việc đã quá hạn':'Công việc sắp đến hạn';const supporters=await all('SELECT user_id FROM task_supporters WHERE task_id=?',t.id);const recipients=[...new Set([t.creator_id,t.assignee_id,...supporters.map(s=>s.user_id)].filter(Boolean))];
    for(const uid of recipients){const key=`deadline:${t.id}:${uid}:${type}:${t.deadline}`;const mark=await stmt('INSERT OR IGNORE INTO site_state (key,value) VALUES (?,?)',key,now()).run();if(mark.meta.changes){await insert('notifications',{user_id:uid,task_id:t.id,type,title,message:`${t.title} · ${new Date(clean(t).deadline).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})}`,is_read:0,created_at:now()});made++;}}
   }return made;
  };
  if(path==='system/reminders'){
   const role=rawUser?await get('roles',rawUser.role_id):null;
   if(!(rawUser?.is_super_admin&&!rawUser.must_change_password)&&!await serviceAuthorized(request,ctx.config||{}))fail(401,'Cần quyền dịch vụ hoặc quản trị.');
   if(method==='POST'){const created=await deadlineCheck();const checked_at=now();await stmt("INSERT INTO site_state(key,value) VALUES ('deadline_last_check',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",checked_at).run();return json({created,checked_at});}
   if(method==='GET')return json({checked_at:(await one("SELECT value FROM site_state WHERE key='deadline_last_check'"))?.value||null});
   fail(405,'Phương thức không hợp lệ.');
  }
  if(!rawUser)fail(401,'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
  const user=rawUser!;const roleRow=await get('roles',user.role_id);const role=effectiveRole(user,roleRow);
  const admin=role==='admin', manager=['admin','supervisor'].includes(role);
  const has=(p:string)=>admin||(permissions[role]||permissions.user).includes(p);
  const requireManager=()=>{if(!manager)fail(403,'Cần quyền quản lý.');};
  const requireAdmin=()=>{if(!admin)fail(403,'Cần quyền quản trị viên.');};
  const teamsOf=async(uid:number)=>all('SELECT team_id FROM support_team_members WHERE user_id=? AND is_active=1',uid);
  const leadTeams=async()=>{
   const teams=await all('SELECT * FROM support_teams WHERE is_active=1');const ds=await all('SELECT id FROM departments WHERE manager_id=? AND is_active=1',user.id);const deptIds=new Set(ds.map(d=>d.id));
   return teams.filter(t=>t.lead_id===user.id||deptIds.has(t.department_id)).map(t=>t.id);
  };
  const publicUser=async(u:Row)=>publicUserProfile(u,await get('roles',u.role_id));
  const validUser=async(id:any)=>{if(id==null)return null;const u=await get('users',id);if(!u||!u.is_active||u.deleted_at)fail(400,'Thành viên không tồn tại hoặc đã bị khóa.');return Number(id);};
  const bump=async()=>{await stmt("INSERT INTO site_state(key,value) VALUES ('revision','1') ON CONFLICT(key) DO UPDATE SET value=CAST(value AS INTEGER)+1").run();};
  const telegramSend=async(chatId:any,text:string)=>{if(!ctx.config?.TELEGRAM_BOT_TOKEN||!chatId)return;try{const result=await fetch(`https://api.telegram.org/bot${ctx.config.TELEGRAM_BOT_TOKEN}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:chatId,text:text.slice(0,4000)})});if(!result.ok)console.warn('Telegram notification delivery failed:',result.status);}catch{console.warn('Telegram notification delivery unavailable');}};
  const notify=async(uid:any,task:any,type:string,title:string,message:string)=>{if(uid&&uid!==user.id){await insert('notifications',{user_id:uid,task_id:task||null,type,title,message,is_read:0,created_at:now()});const recipient=await get('users',uid);await telegramSend(recipient?.telegram_chat_id,title+'\n'+message);}};
  const activity=async(taskId:number,action:string,subtaskId:number|null=null)=>insert('task_activities',{task_id:taskId,user_id:user.id,subtask_id:subtaskId,action,created_at:now()});
  const taskRecipients=async(t:Row)=>[...new Set([t.creator_id,t.assignee_id,...(await all('SELECT user_id FROM task_supporters WHERE task_id=?',t.id)).map(s=>s.user_id)].filter(Boolean))];
  const taskView=async(t:Row)=>{if(manager||t.creator_id===user.id||t.assignee_id===user.id)return true;if(await one('SELECT id FROM task_supporters WHERE task_id=? AND user_id=?',t.id,user.id))return true;if(role==='leader'){const tids=await leadTeams();const members=await all('SELECT team_id,user_id FROM support_team_members WHERE is_active=1');return members.some(m=>tids.includes(m.team_id)&&[t.creator_id,t.assignee_id].includes(m.user_id));}return false;};
  const taskManage=(_t:Row)=>manager&&has('task.edit');
  const taskResult=async(t:Row)=>({...t,subtasks:await all('SELECT * FROM subtasks WHERE task_id=? ORDER BY id',t.id),supporters:await all('SELECT * FROM task_supporters WHERE task_id=? ORDER BY id',t.id),activities:await all('SELECT * FROM task_activities WHERE task_id=? ORDER BY id',t.id)});
  const taskData=async(b:Row,creation=false)=>{const d=pick(b,['title','description','assignee_id','status','priority','progress','deadline']);if('title'in d)d.title=required(d.title,'Tiêu đề',200);else if(creation)fail(400,'Cần tiêu đề.');if(d.description!=null&&typeof d.description!=='string')fail(400,'Mô tả không hợp lệ.');if('assignee_id'in d)d.assignee_id=await validUser(d.assignee_id);if('status'in d)enumValue(d.status,['todo','in_progress','completed'],'Trạng thái');if('priority'in d)enumValue(d.priority,['low','medium','high','urgent'],'Mức ưu tiên');if('progress'in d&&(!Number.isInteger(d.progress)||d.progress<0||d.progress>100))fail(400,'Tiến độ từ 0 đến 100.');if(d.deadline){const date=new Date(/(Z|[+-]\d\d:\d\d)$/i.test(d.deadline)?d.deadline:d.deadline+'+07:00');if(!Number.isFinite(date.getTime()))fail(400,'Hạn chót không hợp lệ.');d.deadline=date.toISOString();}return d;};
  let body:Row={};if(['POST','PUT','PATCH'].includes(method)){try{body=await request.json() as Row;}catch{}if(!body||Array.isArray(body)||typeof body!=='object')fail(400,'Dữ liệu không hợp lệ.');}
  if(path==='auth/me'&&method==='GET')return json(await publicUser(user));
  if(path==='auth/change-password'&&method==='POST'){
   if(!await verifyPassword(body.current_password,user.password_hash))fail(400,'Mật khẩu hiện tại không đúng.');
   if(!validPassword(body.new_password))fail(400,'Mật khẩu mới cần từ 12 đến 128 ký tự.');
   if(body.new_password!==body.confirm_password)fail(400,'Xác nhận mật khẩu không khớp.');
   if(body.new_password===body.current_password)fail(400,'Mật khẩu mới phải khác mật khẩu hiện tại.');
   await db.batch([updateStmt('users',user.id,{password_hash:await hashPassword(body.new_password),must_change_password:0}),stmt('DELETE FROM auth_sessions WHERE user_id=?',user.id)]);
   return Response.json({success:true,message:'Đã đổi mật khẩu. Vui lòng đăng nhập lại.'},{headers:clearedSessionHeaders(request)});
  }
  if(user.must_change_password)fail(403,'Bạn cần đổi mật khẩu trước khi sử dụng.');
  const selfMutation=(path==='users/me/avatar'||path.startsWith('telegram/me/')||(parts[0]==='notifications'&&method==='PATCH')||(parts[0]==='announcements'&&parts[2]==='read'&&method==='PATCH'));
  if(role==='viewer'&&!['GET','HEAD'].includes(method)&&!selfMutation)fail(403,'Vai trò Viewer chỉ được xem thông tin được cấp.');
  if(path==='system/revision'&&method==='GET')return json({revision:(await one("SELECT value FROM site_state WHERE key='revision'"))?.value||'0'});
  if(path==='system/export'&&method==='GET'){
   requireAdmin();const data:Row={format:'taskmanager-sites-v1',exported_at:now()};for(const t of Object.keys(columns)){data[t]=await all(`SELECT * FROM ${t}`);if(t==='users')data[t]=data[t].map((u:Row)=>{const {chatgpt_user_id,telegram_chat_id,password_hash,session_hash,...rest}=u;return rest;});}return json(data);
  }
  if(path==='tasks'&&method==='GET'){
   const mine=url.searchParams.get('mine')==='true';const list=await all('SELECT * FROM tasks ORDER BY created_at DESC');const result=[];
   const [subtasks,supporters,activities]=await Promise.all([all('SELECT * FROM subtasks ORDER BY id'),all('SELECT * FROM task_supporters ORDER BY id'),all('SELECT * FROM task_activities ORDER BY id')]);
   for(const t of list){if(!(await taskView(t)))continue;if(mine&&t.assignee_id!==user.id&&!supporters.some(s=>s.task_id===t.id&&s.user_id===user.id))continue;result.push({...t,subtasks:subtasks.filter(s=>s.task_id===t.id),supporters:supporters.filter(s=>s.task_id===t.id),activities:activities.filter(a=>a.task_id===t.id)});}return json(result);
  }
  // Durable per-user creation receipts live in the existing site_state table.
  // Receipt + task + checklist + supporters + in-app notifications commit atomically.
  const creationKey=(key:string)=>{if(!/^[A-Za-z0-9_-]{16,100}$/.test(key))fail(400,'Mã lượt tạo không hợp lệ.');return `task-create:${user.id}:${key}`;};
  const creationReceipt=async(key:string,hash?:string)=>{const row=await one('SELECT value FROM site_state WHERE key=?',creationKey(key));if(!row)return null;const receipt=JSON.parse(row.value);if(hash&&receipt.hash!==hash)fail(409,'Mã lượt tạo đã được dùng với nội dung khác.');const task=await get('tasks',receipt.task_id);if(!task)fail(410,'Công việc của lượt này đã bị xóa. Không tự động tạo lại.');return task;};
  if(path==='tasks/creation-status'&&method==='GET'){
   if(!has('task.create'))fail(403,'Bạn chưa có quyền tạo công việc.');const task=await creationReceipt(url.searchParams.get('key')||'');return json(task?{state:'created',task:await taskResult(task)}:{state:'absent'});
  }
  if(path==='tasks'&&method==='POST'){
   if(!has('task.create'))fail(403,'Bạn chưa có quyền tạo công việc.');
   const key=request.headers.get('Idempotency-Key')||crypto.randomUUID(),receiptKey=creationKey(key),hash=sha256(JSON.stringify(body));
   const previous=await creationReceipt(key,hash);if(previous)return json(await taskResult(previous));
   const d=await taskData(body,true),subs=body.subtasks||[],supporterIds=body.supporter_ids||[];
   if(!Array.isArray(subs)||subs.length>100)fail(400,'Tối đa 100 công việc con.');for(const sub of subs)required(sub?.title,'Công việc con',200);
   if(!Array.isArray(supporterIds)||supporterIds.length>100||supporterIds.some((id:any)=>!Number.isInteger(id)||id<=0))fail(400,'Danh sách người hỗ trợ không hợp lệ.');
   const supporters=[...new Set<number>(supporterIds)];for(const uid of supporters){await validUser(uid);if(uid===d.assignee_id)fail(400,'Người phụ trách không đồng thời là người hỗ trợ.');}
   const stamp=now();
   const child=(table:string,data:Row)=>{const keys=Object.keys(data);return stmt(`INSERT INTO ${table}(task_id,${keys.join(',')}) SELECT CAST(json_extract(value,'$.task_id') AS INTEGER),${keys.map(()=>'?').join(',')} FROM site_state WHERE key=?`,...keys.map(k=>data[k]),receiptKey);};
   const tx=[insertStmt('site_state',{key:receiptKey,value:JSON.stringify({hash,task_id:null})}),insertStmt('tasks',{description:null,assignee_id:null,status:'todo',priority:'medium',progress:0,deadline:null,...d,creator_id:user.id,created_at:stamp,updated_at:stamp}),stmt("UPDATE site_state SET value=json_set(value,'$.task_id',last_insert_rowid()) WHERE key=?",receiptKey),...subs.map((sub:Row)=>child('subtasks',{title:sub.title.trim(),completed:0,created_at:stamp,completed_at:null})),...supporters.map(uid=>child('task_supporters',{user_id:uid})),child('task_activities',{user_id:user.id,subtask_id:null,action:'task_created',created_at:stamp})];
   const recipients=[...new Set([d.assignee_id,...supporters].filter(uid=>uid&&uid!==user.id))];
   for(const uid of recipients)tx.push(child('notifications',{user_id:uid,type:uid===d.assignee_id?'task_assigned':'task_supporter_added',title:uid===d.assignee_id?'Công việc mới được giao':'Bạn được thêm vào công việc',message:d.title,is_read:0,created_at:stamp}));
   tx.push(stmt("INSERT INTO site_state(key,value) VALUES ('revision','1') ON CONFLICT(key) DO UPDATE SET value=CAST(value AS INTEGER)+1"));
   try{await db.batch(tx);}catch(error){const winner=await creationReceipt(key,hash);if(winner)return json(await taskResult(winner));throw error;}
   const task=await creationReceipt(key,hash);if(!task)fail(500,'Chưa xác nhận được lượt tạo.');
   for(const uid of recipients){const recipient=await get('users',uid);await telegramSend(recipient?.telegram_chat_id,'Công việc mới: '+d.title);}await telegramSend(ctx.config?.TELEGRAM_GROUP_CHAT_ID,'Công việc mới: '+d.title);
   return json(await taskResult(task!),201);
  }
  if(parts[0]==='tasks'&&/^\d+$/.test(parts[1]||'')){
   const t=await must('tasks',parts[1]);if(!await taskView(t))fail(403,'Không có quyền truy cập công việc.');
   if(parts.length===2){
    if(method==='GET')return json(await taskResult(t));
    if(method==='PUT'){
     if(!has('task.status'))fail(403,'Không có quyền cập nhật công việc.');
     if(!taskManage(t)&&Object.keys(body).some(k=>!['status','progress'].includes(k)))fail(403,'Bạn chỉ được cập nhật trạng thái và tiến độ.');const d=await taskData(body);if(d.status==='completed')d.progress=100;
     const q=[updateStmt('tasks',t.id,{...d,updated_at:now()})];
     if(d.status==='completed')q.push(stmt('UPDATE subtasks SET completed=1,completed_at=? WHERE task_id=?',now(),t.id));await db.batch(q);
     for(const k of Object.keys(d))if(t[k]!==d[k])await activity(t.id,(k==='assignee_id'?'reassigned':`${k}_changed`));
     for(const uid of await taskRecipients(t))await notify(uid,t.id,'task_updated','Công việc được cập nhật',d.title||t.title);await bump();return json(await taskResult(await must('tasks',t.id)));
    }
    if(method==='DELETE'){
     if(!taskManage(t))fail(403,'Không có quyền xóa.');await db.batch(['task_comments','task_activities','task_supporters','subtasks','notifications'].map(table=>stmt(`DELETE FROM ${table} WHERE task_id=?`,t.id)).concat(stmt('DELETE FROM tasks WHERE id=?',t.id)));await bump();return json({message:'Đã xóa công việc.'});
    }
   }
   if(parts[2]==='supporters'&&parts[3]){
    if(!taskManage(t))fail(403,'Không có quyền phân công.');const uid=await validUser(Number(parts[3]));
    if(method==='POST'){await stmt('INSERT OR IGNORE INTO task_supporters(task_id,user_id) VALUES (?,?)',t.id,uid).run();await activity(t.id,'supporter_added');await notify(uid,t.id,'task_supporter_added','Bạn được thêm vào công việc',t.title);}
    else if(method==='DELETE'){await stmt('DELETE FROM task_supporters WHERE task_id=? AND user_id=?',t.id,uid).run();await activity(t.id,'supporter_removed');}else fail(405,'Phương thức không hợp lệ.');await bump();return json(await taskResult(t));
   }
   if(parts[2]==='subtasks'){
    if(method==='POST'&&parts.length===3){if(!taskManage(t)&&!has('task.subtask'))fail(403,'Không có quyền.');const sid=await insert('subtasks',{task_id:t.id,title:required(body.title,'Công việc con',200),completed:0,created_at:now(),completed_at:null});await activity(t.id,'subtask_added',sid);const totals=await one('SELECT count(*) n,sum(completed) done FROM subtasks WHERE task_id=?',t.id);const p=Math.round(100*Number(totals?.done)/Number(totals?.n));await update('tasks',t.id,{progress:p,status:p===100?'completed':p>0?'in_progress':'todo',updated_at:now()});await bump();return json(await must('subtasks',sid),201);}
    if(method==='PATCH'&&parts[3]){if(!has('task.subtask'))fail(403,'Không có quyền cập nhật checklist.');const sub=await must('subtasks',parts[3]);if(sub.task_id!==t.id)fail(404,'Không tìm thấy công việc con.');if(typeof body.completed!=='boolean')fail(400,'Trạng thái không hợp lệ.');await update('subtasks',sub.id,{completed:body.completed,completed_at:body.completed?now():null});await activity(t.id,body.completed?'completed':'uncompleted',sub.id);const counts=await one('SELECT count(*) n,sum(completed) done FROM subtasks WHERE task_id=?',t.id);const progress=Math.round(100*Number(counts?.done)/Number(counts?.n));await update('tasks',t.id,{progress,status:progress===100?'completed':progress>0?'in_progress':'todo',updated_at:now()});await bump();return json(await taskResult(await must('tasks',t.id)));}
   }
   if(parts[2]==='comments'){
    if(method==='POST'){const cid=await insert('task_comments',{task_id:t.id,user_id:user.id,content:required(body.content),created_at:now(),updated_at:now()});await activity(t.id,'comment_added');for(const uid of await taskRecipients(t))await notify(uid,t.id,'task_comment','Bình luận mới',`${user.full_name}: ${body.content.slice(0,300)}`);await bump();const c=await must('task_comments',cid);return json({...c,user:await publicUser(user)},201);}
    if(method==='GET'){const comments=await all('SELECT * FROM task_comments WHERE task_id=? ORDER BY id',t.id);return json(await Promise.all(comments.map(async c=>({...c,user:await get('users',c.user_id).then(u=>u?pick(u,['id','username','full_name','avatar_url']):null)}))));}
   }
  }
  if(path==='notifications'&&method==='GET'){await deadlineCheck();return json(await all('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 500',user.id));}
  if(parts[0]==='notifications'&&method==='PATCH'){
   if(parts[1]==='read-all')await stmt('UPDATE notifications SET is_read=1 WHERE user_id=?',user.id).run();
   else if(parts[2]==='read'){const n=await must('notifications',parts[1]);if(n.user_id!==user.id)fail(403,'Không có quyền.');await update('notifications',n.id,{is_read:1});}
   else fail(404,'Không tìm thấy.');return json({message:'Đã đánh dấu đã đọc.'});
  }
  const ticketView=async(t:Row)=>manager||[t.creator_id,t.assignee_id].includes(user.id)||(role==='leader'&&(await leadTeams()).includes(t.team_id));
  const supportActivity=async(tid:number,action:string,oldValue:any=null,newValue:any=null)=>insert('support_ticket_activities',{ticket_id:tid,user_id:user.id,action,old_value:oldValue==null?null:String(oldValue),new_value:newValue==null?null:String(newValue),created_at:now()});
  const enrich=async(rows:Row[])=>Promise.all(rows.map(async r=>({...r,user:await get('users',r.user_id).then(u=>u?pick(u,['id','full_name','username','avatar_url']):null)})));
  const ticketResult=async(t:Row,detail=true)=>({...t,creator:await get('users',t.creator_id).then(u=>u?pick(u,['id','full_name','username']):null),assignee:t.assignee_id?await get('users',t.assignee_id).then(u=>u?pick(u,['id','full_name','username']):null):null,department:t.department_id?await get('departments',t.department_id):null,team:t.team_id?await get('support_teams',t.team_id):null,...(detail?{comments:await enrich(await all('SELECT * FROM support_ticket_comments WHERE ticket_id=? ORDER BY id',t.id)),activities:await enrich(await all('SELECT * FROM support_ticket_activities WHERE ticket_id=? ORDER BY id',t.id))}:{})});
  const routeTicket=async(title:string,description:string)=>{
   const rules=await all('SELECT r.*,t.department_id FROM support_routing_rules r JOIN support_teams t ON t.id=r.team_id JOIN departments d ON d.id=t.department_id WHERE r.is_active=1 AND t.is_active=1 AND d.is_active=1 ORDER BY r.id');const scores:Row={};const n=normalize(title+' '+description);for(const r of rules)if(n.includes(normalize(r.keyword))){scores[r.team_id]=(scores[r.team_id]||0)+r.weight;}const best=Object.entries(scores).sort((a,b)=>Number(b[1])-Number(a[1])||Number(a[0])-Number(b[0]))[0];return best?{department_id:rules.find(r=>r.team_id===Number(best[0]))?.department_id,team_id:Number(best[0]),routing_score:best[1],routing_method:'keyword'}:{department_id:null,team_id:null,routing_score:0,routing_method:'unmatched'};
  };
  if(path==='support/tickets'){
   if(method==='GET'){const list=await all('SELECT * FROM support_tickets ORDER BY created_at DESC');const out=[];for(const t of list)if(await ticketView(t))out.push(await ticketResult(t,false));return json(out);}
   if(method==='POST'){if(!has('support.create'))fail(403,'Không có quyền tạo yêu cầu.');const title=required(body.title,'Tiêu đề',200),description=required(body.description);const category=enumValue(body.category||'other',['technical','software','hardware','network','account','other'],'Danh mục'),priority=enumValue(body.priority||'medium',['low','medium','high','urgent'],'Mức ưu tiên');const id=await insert('support_tickets',{title,description,category,priority,creator_id:user.id,assignee_id:null,ticket_code:'NEW-'+crypto.randomUUID(),status:'open',created_at:now(),updated_at:now(),resolved_at:null,closed_at:null,...await routeTicket(title,description)});await update('support_tickets',id,{ticket_code:`TCK-${String(id).padStart(5,'0')}`});await supportActivity(id,'ticket_created');const t=await must('support_tickets',id);if(t.team_id)await supportActivity(id,'auto_routed',null,`team:${t.team_id};score:${t.routing_score}`);await bump();return json(await ticketResult(t),201);}
  }
  if(parts[0]==='support'&&parts[1]==='tickets'&&/^\d+$/.test(parts[2]||'')){
   const t=await must('support_tickets',parts[2]);if(!await ticketView(t))fail(403,'Không có quyền truy cập yêu cầu.');
   if(parts.length===3){
    if(method==='GET')return json(await ticketResult(t));
    if(method==='PUT'){if(!manager&&t.creator_id!==user.id&&t.assignee_id!==user.id&&!(role==='leader'&&(await leadTeams()).includes(t.team_id)))fail(403,'Không có quyền chỉnh sửa.');const d=pick(body,['title','description','category','priority']);if('title'in d)d.title=required(d.title,'Tiêu đề',200);if('description'in d)d.description=required(d.description);if(d.priority)enumValue(d.priority,['low','medium','high','urgent'],'Ưu tiên');if(d.category)enumValue(d.category,['technical','software','hardware','network','account','other'],'Danh mục');for(const k of Object.keys(d))if(d[k]!==t[k])await supportActivity(t.id,`${k}_changed`,t[k],d[k]);if(!t.assignee_id&&['title','description','category'].some(k=>k in d))Object.assign(d,await routeTicket(d.title??t.title,d.description??t.description));await update('support_tickets',t.id,{...d,updated_at:now()});await bump();return json(await ticketResult(await must('support_tickets',t.id)));}
   }
   if(['assign','claim'].includes(parts[3])&&method==='PUT'){
    if(!has('support.assign')&&parts[3]==='assign')fail(403,'Không có quyền phân công.');if(parts[3]==='claim'&&!has('support.claim'))fail(403,'Không có quyền nhận xử lý.');if(!manager&&!(await leadTeams()).includes(t.team_id))fail(403,'Bạn không quản lý nhóm của yêu cầu này.');if(parts[3]==='claim'&&t.assignee_id)fail(409,'Yêu cầu đã có người xử lý.');const uid=await validUser(parts[3]==='claim'?user.id:body.assignee_id);
    if(uid&&t.team_id&&!await one('SELECT id FROM support_team_members WHERE user_id=? AND team_id=? AND is_active=1',uid,t.team_id))fail(400,'Người xử lý chưa thuộc nhóm của yêu cầu.');
    await update('support_tickets',t.id,{assignee_id:uid,status:uid&&t.status==='open'?'assigned':!uid&&t.status==='assigned'?'open':t.status,updated_at:now()});await supportActivity(t.id,'assignee_changed',t.assignee_id,uid);await notify(uid,null,'support_ticket_assigned','Yêu cầu hỗ trợ mới',`${t.ticket_code} · ${t.title}`);await bump();return json(await ticketResult(await must('support_tickets',t.id)));
   }
   if(parts[3]==='status'&&method==='PUT'){
    if(!manager&&t.assignee_id!==user.id&&!(role==='leader'&&(await leadTeams()).includes(t.team_id)))fail(403,'Chỉ người xử lý hoặc quản lý nhóm được đổi trạng thái.');
    enumValue(body.status,['open','assigned','in_progress','waiting','resolved','closed'],'Trạng thái');const d:Row={status:body.status,updated_at:now(),resolved_at:['resolved','closed'].includes(body.status)?t.resolved_at||now():null,closed_at:body.status==='closed'?now():null};await update('support_tickets',t.id,d);await supportActivity(t.id,'status_changed',t.status,body.status);await notify(t.creator_id,null,'support_ticket_status','Cập nhật yêu cầu hỗ trợ',`${t.ticket_code}: ${body.status}`);await bump();return json(await ticketResult(await must('support_tickets',t.id)));
   }
   if(parts[3]==='comments'){
    if(method==='GET')return json(await enrich(await all('SELECT * FROM support_ticket_comments WHERE ticket_id=? ORDER BY id',t.id)));
    if(method==='POST'){const id=await insert('support_ticket_comments',{ticket_id:t.id,user_id:user.id,content:required(body.content),created_at:now(),updated_at:now()});await supportActivity(t.id,'comment_added');for(const uid of new Set([t.creator_id,t.assignee_id]))await notify(uid,null,'support_ticket_comment','Trao đổi mới',`${user.full_name} đã bình luận trong ${t.ticket_code}`);await bump();return json((await enrich([await must('support_ticket_comments',id)]))[0],201);}
   }
   if(parts[3]==='activities'&&method==='GET')return json(await enrich(await all('SELECT * FROM support_ticket_activities WHERE ticket_id=? ORDER BY id',t.id)));
  }
  if(parts[0]==='support'&&parts[1]==='org'){
   const kind=parts[2],table=({departments:'departments',teams:'support_teams',rules:'support_routing_rules'} as Row)[kind];if(!table)fail(404,'Không tìm thấy.');
   if(kind==='teams'&&parts[4]==='members'){
    const team=await must('support_teams',parts[3]);if(!manager&&!(await leadTeams()).includes(team.id)&&!(await teamsOf(user.id)).some(t=>t.team_id===team.id))fail(403,'Không có quyền xem nhóm này.');if(method==='GET')return json(await Promise.all((await all('SELECT * FROM support_team_members WHERE team_id=? AND is_active=1',team.id)).map(async m=>({...m,user:pick(await must('users',m.user_id),['id','username','full_name','avatar_url'])}))));
    requireManager();if(method==='POST'){const uid=await validUser(body.user_id);if(!uid)fail(400,'Cần chọn thành viên.');await stmt('INSERT INTO support_team_members(team_id,user_id,is_active,created_at) VALUES (?,?,1,?) ON CONFLICT(team_id,user_id) DO UPDATE SET is_active=1',team.id,uid,now()).run();await bump();const m=await one('SELECT * FROM support_team_members WHERE team_id=? AND user_id=?',team.id,uid);return json({...m,user:pick(await must('users',uid),['id','username','full_name'])},201);}
    if(method==='DELETE'&&parts[5]){await stmt('UPDATE support_team_members SET is_active=0 WHERE team_id=? AND user_id=?',team.id,Number(parts[5])).run();await bump();return json({message:'Đã gỡ thành viên.'});}
   }
   if(method==='GET'){
    let rows=await all(`SELECT * FROM ${table} ORDER BY id`);if(kind==='teams'&&url.searchParams.get('department_id'))rows=rows.filter(r=>r.department_id===Number(url.searchParams.get('department_id')));if(kind==='rules'&&url.searchParams.get('team_id'))rows=rows.filter(r=>r.team_id===Number(url.searchParams.get('team_id')));
    if(!manager){const tids=await leadTeams(),mems=(await teamsOf(user.id)).map(t=>t.team_id);if(kind==='teams')rows=rows.filter(r=>tids.includes(r.id)||mems.includes(r.id));if(kind==='rules')rows=rows.filter(r=>tids.includes(r.team_id));if(kind==='departments'){const scope=await all('SELECT id,department_id FROM support_teams WHERE is_active=1');const dids=scope.filter(t=>tids.includes(t.id)||mems.includes(t.id)).map(t=>t.department_id);rows=rows.filter(d=>dids.includes(d.id)||d.manager_id===user.id);}}
    if(kind!=='rules')rows=await Promise.all(rows.map(async r=>({...r,[kind==='departments'?'manager':'lead']:r[kind==='departments'?'manager_id':'lead_id']?pick(await must('users',r[kind==='departments'?'manager_id':'lead_id']),['id','username','full_name']):null})));
    return json(rows);
   }
   const existing=parts[3]?await must(table,parts[3]):null;
   if(kind==='rules'&&role==='leader'){const tid=existing?.team_id||body.team_id;if(body.team_id&&existing&&body.team_id!==existing.team_id)fail(403,'Không thể chuyển quy tắc sang nhóm khác.');if(!(await leadTeams()).includes(tid))fail(403,'Bạn không quản lý nhóm này.');}else requireManager();
   if(method==='DELETE'){if(!existing)fail(404,'Không tìm thấy.');if(kind==='departments')requireAdmin();await update(table,existing.id,{is_active:0});await bump();return json({message:'Đã ngừng sử dụng.'});}
   const keys=kind==='departments'?['name','code','parent_id','manager_id','is_active']:kind==='teams'?['department_id','name','code','lead_id','is_active']:['team_id','keyword','weight','is_active'];const d=pick(body,keys);
   if(kind==='rules'){
    if('keyword'in d||method==='POST')d.keyword=required(d.keyword,'Từ khóa',100);if('weight'in d&&(!Number.isInteger(d.weight)||d.weight<1||d.weight>100))fail(400,'Trọng số từ 1 đến 100.');if(d.team_id)await must('support_teams',d.team_id);
   }else{if('name'in d||method==='POST')d.name=required(d.name,'Tên',100);if('code'in d||method==='POST')d.code=required(d.code,'Mã',50);if(d.manager_id)await validUser(d.manager_id);if(d.lead_id)await validUser(d.lead_id);if(d.department_id)await must('departments',d.department_id);if(d.parent_id){await must('departments',d.parent_id);let p=Number(d.parent_id),visited=new Set();while(p){if(p===existing?.id||visited.has(p))fail(400,'Cấu trúc phòng ban không được tạo vòng lặp.');visited.add(p);p=(await get('departments',p))?.parent_id;}}}
   if(method==='POST'){const defaults=kind==='departments'?{parent_id:null,manager_id:null}:kind==='teams'?{lead_id:null}:{weight:10};if(kind==='teams'&&!d.department_id)fail(400,'Chọn phòng ban.');if(kind==='rules'&&!d.team_id)fail(400,'Chọn nhóm.');const id=await insert(table,{...defaults,...d,is_active:1,created_at:now()});await bump();return json(await must(table,id),201);}
   if(method==='PUT'&&existing){const r=await update(table,existing.id,d);await bump();return json(r);}
  }
  const announcementResult=async(a:Row):Promise<Row>=>{const teams=await all('SELECT t.id,t.name FROM support_teams t JOIN announcement_teams a ON a.team_id=t.id WHERE a.announcement_id=?',a.id);if(!teams.length&&a.team_id){const t=await get('support_teams',a.team_id);if(t)teams.push(t);}return {...a,team_ids:teams.map(t=>t.id),team_names:teams.map(t=>t.name),is_read:!!await one('SELECT id FROM announcement_reads WHERE announcement_id=? AND user_id=?',a.id,user.id),creator_name:(await get('users',a.creator_id))?.full_name};};
  if(parts[0]==='announcements'){
   const memberIds=[...(await teamsOf(user.id)).map(t=>t.team_id),...(role==='leader'?await leadTeams():[])];const visible=(a:Row)=>manager||a.target_type==='company'||a.team_ids.some((id:number)=>memberIds.includes(id));
   if(method==='GET'&&parts.length===1){const items=await Promise.all((await all('SELECT * FROM announcements WHERE is_active=1 ORDER BY created_at DESC')).map(announcementResult));return json(items.filter(visible));}
   const existing=parts[1]?await announcementResult(await must('announcements',parts[1])):null;
   if(method==='PATCH'&&parts[2]==='read'&&existing){if(!visible(existing))fail(403,'Không có quyền.');await stmt('INSERT OR IGNORE INTO announcement_reads(announcement_id,user_id,read_at) VALUES (?,?,?)',existing.id,user.id,now()).run();return json(await announcementResult(existing));}
   if(['POST','PUT'].includes(method)){
    const title=required(body.title,'Tiêu đề',200),content=required(body.content),target=enumValue(body.target_type||'company',['company','team'],'Phạm vi');const tids=[...new Set((body.team_ids||[]).map(Number))] as number[];
    if(target==='company')requireManager();else{if(!manager&&role!=='leader')fail(403,'Không có quyền.');if(!tids.length)fail(400,'Vui lòng chọn nhóm nhận.');const allowed=await leadTeams();for(const id of tids){const t=await must('support_teams',id);if(!t.is_active||(!manager&&!allowed.includes(id)))fail(403,'Nhóm không hợp lệ.');}}
    if(existing&&!manager){const allowed=await leadTeams();if(existing.target_type==='company'||!existing.team_ids.length||!existing.team_ids.every((id:number)=>allowed.includes(id)))fail(403,'Không có quyền chỉnh sửa.');}
    let id=existing?.id;if(method==='PUT'&&!id)fail(404,'Không tìm thấy.');if(id)await update('announcements',id,{title,content,target_type:target,team_id:null,updated_at:now()});else id=await insert('announcements',{title,content,target_type:target,team_id:null,creator_id:user.id,is_active:1,created_at:now(),updated_at:now()});
    const qs=[stmt('DELETE FROM announcement_teams WHERE announcement_id=?',id)];if(target==='team')for(const tid of tids)qs.push(insertStmt('announcement_teams',{announcement_id:id,team_id:tid}));await db.batch(qs);
    const recipients=target==='company'?await all('SELECT id FROM users WHERE is_active=1 AND deleted_at IS NULL'):await all(`SELECT DISTINCT user_id id FROM support_team_members WHERE is_active=1 AND team_id IN (${tids.map(()=>'?').join(',')})`,...tids);
    for(const u of recipients)await notify(u.id,null,'announcement','Thông báo mới: '+title,content.slice(0,300));if(target==='company')await telegramSend(ctx.config?.TELEGRAM_GROUP_CHAT_ID,title+'\n'+content);await bump();return json(await announcementResult(await must('announcements',id)),existing?200:201);
   }
  }
  if(parts[0]==='roles'){
   if(method==='GET')return json(await all('SELECT * FROM roles ORDER BY id'));
   requireAdmin();const existing=parts[1]?await must('roles',parts[1]):null;
   if(method==='POST'){const code=required(body.code,'Mã vai trò',50).toLowerCase();if(!/^[a-z][a-z0-9_]{1,49}$/.test(code))fail(400,'Mã vai trò chỉ gồm chữ thường, số và gạch dưới.');if(await one('SELECT id FROM roles WHERE lower(code)=?',code))fail(409,'Mã vai trò đã tồn tại.');const id=await insert('roles',{name:required(body.name,'Tên vai trò',100),code,is_active:1,created_at:now()});return json(await must('roles',id),201);}
   if(existing){if(['admin','supervisor','leader','user','viewer'].includes(existing.code)&&((body.code&&body.code!==existing.code)||method==='DELETE'||body.is_active===false))fail(400,'Vai trò hệ thống cần được giữ nguyên.');if(method==='DELETE'){if(await one('SELECT id FROM users WHERE role_id=? AND deleted_at IS NULL',existing.id))fail(409,'Vai trò đang được sử dụng.');await stmt('DELETE FROM roles WHERE id=?',existing.id).run();return json({message:'Đã xóa vai trò.'});}if(method==='PUT'){const d=pick(body,['name','is_active']);if('name'in d)d.name=required(d.name,'Tên vai trò',100);if(body.code&&body.code!==existing.code)fail(400,'Không thể đổi mã vai trò đã tạo.');if('is_active'in d&&typeof d.is_active!=='boolean')fail(400,'Trạng thái không hợp lệ.');const r=await update('roles',existing.id,d);if(d.is_active===false)await stmt('DELETE FROM auth_sessions WHERE user_id IN (SELECT id FROM users WHERE role_id=?)',existing.id).run();return json(r);}}
  }
  if(parts[0]==='users'){
   if(method==='GET'&&parts.length===1){const include=admin&&url.searchParams.get('include_inactive')==='true';const [members,roles]=await Promise.all([all(`SELECT * FROM users WHERE deleted_at IS NULL ${include?'':'AND is_active=1'} ORDER BY id`),all('SELECT * FROM roles')]);const byId=new Map(roles.map(r=>[r.id,r]));return json(members.map(u=>{const out=publicUserProfile(u,byId.get(u.role_id)||null);return admin||u.id===user.id?out:pick(out,['id','username','full_name','position','avatar_url','role','role_code','is_active']);}));}
   if(path==='users/me/avatar'&&method==='PUT'){
    const match=typeof body.avatar_data==='string'&&body.avatar_data.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/);if(!match||match[2].length>2800000)fail(400,'Ảnh PNG/JPG/WEBP tối đa 2 MB.');if(!ctx.bucket)fail(503,'Kho ảnh chưa sẵn sàng.');const bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0));await ctx.bucket!.put(`avatars/${user.id}.png`,bytes,{httpMetadata:{contentType:`image/${match[1]}`}});const avatar_url=`/api/users/${user.id}/avatar?v=${Date.now()}`;await update('users',user.id,{avatar_url});return json({avatar_url});
   }
   if(parts[2]==='avatar'&&method==='GET'){await must('users',parts[1]);const f=await ctx.bucket?.get(`avatars/${Number(parts[1])}.png`);if(!f)fail(404,'Chưa có ảnh.');return new Response(f!.body,{headers:{'Content-Type':f!.httpMetadata?.contentType||'image/png','Cache-Control':'private, max-age=300','X-Content-Type-Options':'nosniff'}});}
   requireAdmin();
   if(method==='POST'&&parts.length===1){const roleId=Number(body.role_id);const targetRole=await must('roles',roleId);if(targetRole.code.toLowerCase()==='admin'||!targetRole.is_active)fail(400,'Tài khoản mới cần một vai trò đang hoạt động, thấp hơn Admin.');if(!validPassword(body.password))fail(400,'Mật khẩu cần từ 12 đến 128 ký tự.');const username=required(body.username,'Tên tài khoản',50).toLowerCase();if(!/^[a-z0-9][a-z0-9._-]{2,49}$/.test(username))fail(400,'Tên tài khoản cần 3–50 ký tự a-z, 0-9, dấu chấm, gạch dưới hoặc gạch ngang.');if(await one('SELECT id FROM users WHERE lower(username)=?',username))fail(409,'Tên tài khoản đã tồn tại.');if(body.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email))fail(400,'Email không hợp lệ.');const id=await insert('users',{username,full_name:required(body.full_name,'Họ và tên',100),role_id:roleId,position:body.position||null,email:body.email?.toLowerCase()||null,telegram_chat_id:null,is_active:1,must_change_password:body.must_change_password!==false?1:0,password_hash:await hashPassword(body.password),is_super_admin:0,created_at:now(),deleted_at:null,avatar_url:null,chatgpt_user_id:null});return json(await publicUser(await must('users',id)),201);}
   const u=await must('users',parts[1]);if(u.deleted_at)fail(404,'Tài khoản đã được lưu trữ.');
   if(parts[2]==='reset-password'&&method==='POST'){
    if(u.is_super_admin)fail(403,'Tài khoản quản trị cao nhất phải tự đổi mật khẩu trong mục Bảo mật.');
    if(!validPassword(body.new_password))fail(400,'Mật khẩu cần từ 12 đến 128 ký tự.');
    await db.batch([updateStmt('users',u.id,{password_hash:await hashPassword(body.new_password),must_change_password:body.must_change_password!==false?1:0}),stmt('DELETE FROM auth_sessions WHERE user_id=?',u.id)]);
    return json({message:'Đã đặt mật khẩu và thu hồi các phiên đăng nhập.'});
   }
   if(u.is_super_admin&&((parts[2]==='role')||['activate','deactivate'].includes(parts[2])||method==='DELETE'))fail(403,'Không thể hạ quyền, khóa hoặc xóa tài khoản quản trị cao nhất.');
   if(parts[2]==='role'&&method==='PUT'){if(u.id===user.id)fail(400,'Không thể thay đổi vai trò của chính mình.');const targetRole=await must('roles',body.role_id);if(targetRole.code.toLowerCase()==='admin'||!targetRole.is_active)fail(400,'Chọn vai trò đang hoạt động, thấp hơn Admin.');await update('users',u.id,{role_id:Number(body.role_id)});await revokeSessions(db,u.id);return json(await publicUser(await must('users',u.id)));}
   if(parts[2]==='position'&&method==='PUT'){await update('users',u.id,{position:body.position||null});return json(await publicUser(await must('users',u.id)));}
   if(parts[2]==='profile'&&method==='PUT'){const d=pick(body,['full_name','position','email']);if('full_name'in d)d.full_name=required(d.full_name,'Họ tên',100);if(d.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email))fail(400,'Email không hợp lệ.');if('email'in d)d.email=d.email?.trim().toLowerCase()||null;await update('users',u.id,d);return json(await publicUser(await must('users',u.id)));}
   if(['activate','deactivate'].includes(parts[2])&&method==='POST'){if(u.id===user.id)fail(400,'Không thể khóa chính mình.');await update('users',u.id,{is_active:parts[2]==='activate'});if(parts[2]==='deactivate')await revokeSessions(db,u.id);return json(await publicUser(await must('users',u.id)));}
   if(method==='DELETE'&&parts.length===2){if(u.id===user.id)fail(400,'Không thể xóa chính mình.');await update('users',u.id,{is_active:0,deleted_at:now()});await revokeSessions(db,u.id);await stmt('UPDATE support_team_members SET is_active=0 WHERE user_id=?',u.id).run();return json({message:'Đã lưu trữ tài khoản. Lịch sử được giữ nguyên.'});}
  }
  if(parts[0]==='telegram'){
   const configured=!!ctx.config?.TELEGRAM_BOT_TOKEN;const status=(u:Row)=>({configured,bot_configured:configured,bot_username:ctx.config?.TELEGRAM_BOT_USERNAME||null,telegram_chat_id:u.telegram_chat_id||null,linked:!!u.telegram_chat_id,has_chat_id:!!u.telegram_chat_id,group_configured:!!ctx.config?.TELEGRAM_GROUP_CHAT_ID});
   if(path==='telegram/status'&&method==='GET')return json(status(user));
   if(path==='telegram/me/chat-id'&&['PUT','DELETE'].includes(method)){const value=method==='DELETE'?null:String(body.telegram_chat_id||body.chat_id||'').trim();if(value&&!/^-?\d{3,30}$/.test(value))fail(400,'Chat ID phải là một dãy số.');await update('users',user.id,{telegram_chat_id:value});return json(status(await must('users',user.id)));}
   if(path==='telegram/admin/users'&&method==='GET'){requireAdmin();return json((await all('SELECT id,username,full_name,telegram_chat_id,is_active FROM users WHERE deleted_at IS NULL')).map(u=>({...u,...status(u)})));}
   if(parts[1]==='admin'&&parts[2]==='users'&&parts[4]==='chat-id'&&method==='DELETE'){requireAdmin();await update('users',Number(parts[3]),{telegram_chat_id:null});return json({message:'Đã hủy liên kết.'});}
   if(path.endsWith('/test')&&method==='POST'){
    if(!configured)fail(409,'Chưa cấu hình TELEGRAM_BOT_TOKEN cho website.');const group=parts[1]==='group';if(group)requireAdmin();const chatId=group?ctx.config?.TELEGRAM_GROUP_CHAT_ID:user.telegram_chat_id;if(!chatId)fail(400,'Chưa có Chat ID.');const r=await fetch(`https://api.telegram.org/bot${ctx.config!.TELEGRAM_BOT_TOKEN}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:chatId,text:'Task Manager: kết nối Telegram thành công.'})});const result=await r.json() as Row;if(!result.ok)fail(502,'Telegram từ chối gửi. Kiểm tra token và Chat ID.');return json({message:'Đã gửi tin nhắn kiểm tra.',success:true});
   }
   if(path.endsWith('/link')&&method==='POST')fail(409,'Nhập Chat ID trong cài đặt. Liên kết qua bot cần webhook Telegram được cấu hình riêng.');
  }
  fail(404,'Chức năng không tồn tại.');
 } catch(error){
  if(error instanceof HttpError)return json({detail:error.message},error.status);
  const message=error instanceof Error?error.message:String(error);
  if(/UNIQUE constraint/i.test(message))return json({detail:'Tên, mã hoặc liên kết này đã tồn tại.'},409);
  console.error('Task Manager API error',path,message.replace(/bot\d+:[^/\s]+/g,'bot[redacted]'));
  return json({detail:'Không thể xử lý yêu cầu. Dữ liệu chưa được xác nhận lưu; vui lòng thử lại.'},500);
 }
}
