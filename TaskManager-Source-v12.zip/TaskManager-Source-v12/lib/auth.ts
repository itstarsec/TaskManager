import { scrypt, randomBytes, timingSafeEqual, createHash } from 'node:crypto';
import { requestOrigin,isTrustedBrowserOrigin,compatibleSessionOrigins } from './cors';
export type AuthRow = Record<string,any>;
export const SESSION_COOKIE='__Host-taskmanager_session_v2';
export const TRUSTED_SESSION_COOKIE='__Secure-taskmanager_trusted_session';
const LEGACY_SESSION_COOKIE='__Host-taskmanager_session';
const SESSION_HOURS=12;
const SCRYPT_OPTIONS={N:16384,r:8,p:5,maxmem:64*1024*1024};
function derive(password:string,salt:string):Promise<Buffer>{return new Promise((resolve,reject)=>scrypt(password,salt,32,SCRYPT_OPTIONS,(error,key)=>error?reject(error):resolve(key)));}
export const sha256=(value:string)=>createHash('sha256').update(value).digest('hex');
export function validPassword(value:unknown):value is string{return typeof value==='string'&&value.length>=12&&value.length<=128;}
export async function hashPassword(password:string){if(!validPassword(password))throw new Error('Mật khẩu cần từ 12 đến 128 ký tự.');const salt=randomBytes(16).toString('hex');const key=await derive(password,salt);return `scrypt$16384$8$5$${salt}$${key.toString('hex')}`;}
export async function verifyPassword(password:unknown,encoded:unknown){if(typeof password!=='string'||password.length>128||typeof encoded!=='string')return false;const [algorithm,n,r,p,salt,hash]=encoded.split('$');if(algorithm!=='scrypt'||n!=='16384'||r!=='8'||p!=='5'||!salt||!/^[a-f0-9]{64}$/.test(hash||''))return false;const actual=await derive(password,salt);return timingSafeEqual(actual,Buffer.from(hash,'hex'));}
export function sessionToken(request:Request){
 const authorization=request.headers.get('authorization');
 if(authorization!==null)return /^Bearer ([a-f0-9]{64})$/i.exec(authorization)?.[1]||null;
 const cookies=request.headers.get('cookie')?.split(';').map(x=>x.trim())||[];
 let origin:string|null;try{origin=requestOrigin(request);}catch{return null;}
 const trustCookie=(!origin||isTrustedBrowserOrigin(origin))?cookies.find(x=>x.startsWith(TRUSTED_SESSION_COOKIE+'=')):undefined;
 const cookie=trustCookie??cookies.find(x=>x.startsWith(SESSION_COOKIE+'='))??cookies.find(x=>x.startsWith(LEGACY_SESSION_COOKIE+'='));
 const value=cookie?.slice(cookie.indexOf('=')+1)||'';
 return /^[a-f0-9]{64}$/.test(value)?value:null;
}
export function sessionCookie(value:string,maxAge=SESSION_HOURS*3600,origin:string|null=null){
 // Partitioned cookies cannot follow a login across top-level site changes.
 // Keep a separate non-partitioned cookie for the two approved entry points;
 // other origins retain isolated cookies and cannot use this session.
 const trusted=isTrustedBrowserOrigin(origin);
 return `${trusted?TRUSTED_SESSION_COOKIE:SESSION_COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=None;${trusted?'':' Partitioned;'} Max-Age=${maxAge}`;
}
export function clearedSessionHeaders(request:Request){
 const headers=new Headers({'Cache-Control':'no-store'});
 headers.append('Set-Cookie',sessionCookie('',0));
 const origin=requestOrigin(request);
 if(!origin||isTrustedBrowserOrigin(origin)){
  headers.append('Set-Cookie',`${TRUSTED_SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=0`);
  headers.append('Set-Cookie',`${LEGACY_SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`);
 }
 return headers;
}
export async function getSessionUser(request:Request,db:D1Database):Promise<AuthRow|null>{
 const token=sessionToken(request);if(!token)return null;
 const user=await db.prepare('SELECT u.*,s.token_hash session_hash,s.login_origin session_origin,s.session_mode FROM auth_sessions s JOIN users u ON u.id=s.user_id JOIN roles r ON r.id=u.role_id WHERE s.token_hash=? AND s.expires_at>? AND u.is_active=1 AND u.deleted_at IS NULL AND r.is_active=1').bind(sha256(token),new Date().toISOString()).first<AuthRow>();
 if(!user)return null;
 const bearer=request.headers.has('authorization');
 if((user.session_mode==='token')!==bearer)return null;
 let origin:string|null;try{origin=requestOrigin(request);}catch{return null;}
 // Only the owner's explicit pair of trusted entry points may share a session.
 // Every other origin remains bound to its own login.
 if(origin&&!compatibleSessionOrigins(user.session_origin||new URL(request.url).origin,origin))return null;
 if(!origin&&!bearer&&request.headers.get('sec-fetch-site')==='cross-site')return null;
 return user;
}
export async function revokeSessions(db:D1Database,userId:number){await db.prepare('DELETE FROM auth_sessions WHERE user_id=?').bind(userId).run();}
export async function bootstrapAuth(db:D1Database,config:Record<string,string>){
 const done=await db.prepare("SELECT value FROM site_state WHERE key='local_auth_v1'").first();if(done)return;
 const hash=config.BOOTSTRAP_ADMIN_HASH;
 if(!hash||!/^scrypt\$16384\$8\$5\$[a-f0-9]{32}\$[a-f0-9]{64}$/.test(hash))throw new Error('Tài khoản quản trị chưa được cấu hình.');
 const admin=await db.prepare("SELECT id FROM roles WHERE lower(code)='admin'").first<AuthRow>();
 if(!admin)throw new Error('Không tìm thấy vai trò quản trị.');
 const account=await db.prepare("SELECT id FROM users WHERE lower(username)='admin'").first();
 if(!account)throw new Error('Không tìm thấy tài khoản quản trị.');
 const stamp=new Date().toISOString();
 await db.batch([
  db.prepare("UPDATE users SET password_hash=?,role_id=?,is_super_admin=1,is_active=1,must_change_password=0,deleted_at=NULL WHERE lower(username)='admin' AND password_hash IS NULL").bind(hash,admin.id),
  db.prepare("INSERT OR IGNORE INTO roles(name,code,is_active,created_at) VALUES ('Viewer','viewer',1,?)").bind(stamp),
  db.prepare("INSERT OR IGNORE INTO site_state(key,value) VALUES ('local_auth_v1',?)").bind(stamp)
 ]);
}
export async function serviceAuthorized(request:Request,config:Record<string,string>){const value=request.headers.get('x-maintenance-token')||'';const expected=config.MAINTENANCE_TOKEN_SHA256||'';if(!value||!expected||value.length>4096)return false;const hash=sha256(value);return hash.length===expected.length&&timingSafeEqual(Buffer.from(hash),Buffer.from(expected));}
export async function handleLogin(request:Request,db:D1Database,config:Record<string,string>):Promise<Response>{
 const json=(data:any,status=200,cookie?:string)=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
 if(!request.headers.get('content-type')?.toLowerCase().startsWith('application/json'))return json({detail:'Dữ liệu đăng nhập cần ở định dạng JSON.'},415);
 let body:AuthRow;try{const text=await request.text();if(text.length>2048)return json({detail:'Yêu cầu quá lớn.'},413);body=JSON.parse(text);}catch{return json({detail:'Dữ liệu đăng nhập không hợp lệ.'},400);}
 if(!body||typeof body.username!=='string'||body.username.length>50||typeof body.password!=='string'||body.password.length>128)return json({detail:'Tên đăng nhập hoặc mật khẩu không đúng.'},401);
 if(body.session_mode!==undefined&&!['cookie','token'].includes(body.session_mode))return json({detail:'Kiểu phiên đăng nhập không hợp lệ.'},400);
 const mode=body.session_mode==='token'?'token':'cookie';
 const origin=requestOrigin(request)||new URL(request.url).origin;
 const username=body.username.trim().toLowerCase(),ip=request.headers.get('cf-connecting-ip')||'unknown';const stamp=new Date().toISOString(),reset=new Date(Date.now()+15*60*1000).toISOString();
 const keys=[{key:'account:'+sha256(username),limit:8},{key:'ip:'+sha256(ip),limit:60}];
 // Atomic increments enforce the limit even when login attempts race.
 for(const entry of keys){await db.prepare('INSERT INTO auth_attempts(key,attempts,reset_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN reset_at<=? THEN 1 ELSE attempts+1 END, reset_at=CASE WHEN reset_at<=? THEN excluded.reset_at ELSE reset_at END').bind(entry.key,reset,stamp,stamp).run();const count=await db.prepare('SELECT attempts FROM auth_attempts WHERE key=?').bind(entry.key).first<AuthRow>();if(Number(count?.attempts)>entry.limit)return json({detail:'Đã thử đăng nhập quá nhiều lần. Vui lòng thử lại sau 15 phút.'},429);}
 await bootstrapAuth(db,config);
 const user=await db.prepare('SELECT u.*,r.is_active role_active FROM users u LEFT JOIN roles r ON r.id=u.role_id WHERE lower(u.username)=? AND u.deleted_at IS NULL').bind(username).first<AuthRow>();
 const encoded=user?.password_hash||config.BOOTSTRAP_ADMIN_HASH;
 const valid=await verifyPassword(body.password,encoded);
 if(!valid||!user?.password_hash||!user.is_active||!user.role_active)return json({detail:'Tên đăng nhập hoặc mật khẩu không đúng.'},401);
 const token=randomBytes(32).toString('hex'),expires=new Date(Date.now()+SESSION_HOURS*3600000).toISOString();
 const results=await db.batch([
  db.prepare('INSERT INTO auth_sessions(token_hash,user_id,created_at,expires_at,login_origin,session_mode) SELECT ?,id,?,?,?,? FROM users WHERE id=? AND password_hash=? AND role_id=? AND is_active=1 AND deleted_at IS NULL AND EXISTS (SELECT 1 FROM roles WHERE roles.id=users.role_id AND roles.is_active=1)').bind(sha256(token),stamp,expires,origin,mode,user.id,user.password_hash,user.role_id),
  db.prepare('DELETE FROM auth_sessions WHERE expires_at<=?').bind(stamp),
  db.prepare('DELETE FROM auth_attempts WHERE key=? OR reset_at<=?').bind(keys[0].key,stamp)
 ]);
 if(!results[0].meta.changes)return json({detail:'Tài khoản vừa thay đổi. Vui lòng đăng nhập lại.'},401);
 return json({success:true,must_change_password:!!user.must_change_password,session_mode:mode,expires_in:SESSION_HOURS*3600,...(mode==='token'?{access_token:token,token_type:'Bearer'}:{})},200,mode==='cookie'?sessionCookie(token,SESSION_HOURS*3600,origin):undefined);
}
