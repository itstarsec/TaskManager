import assert from 'node:assert/strict';
import {createCourtController} from '../app/legacy/components/basketball/court-controller.js';
// Unit harness for the actual DOM controller. This is not a physical-device test.
class Node {
 constructor(){this.events=new Map();this.style={};this.attributes={};this.captures=new Set();this.textContent='';this.clientWidth=600;this.clientHeight=540;}
 addEventListener(name,fn){if(!this.events.has(name))this.events.set(name,new Set());this.events.get(name).add(fn);}
 removeEventListener(name,fn){this.events.get(name)?.delete(fn);if(!this.events.get(name)?.size)this.events.delete(name);}
 emit(name,data={}){const e={button:0,buttons:1,pointerId:1,pointerType:'mouse',clientX:1000,clientY:1000,preventDefault(){this.prevented=true},stopPropagation(){this.stopped=true},...data};for(const fn of [...this.events.get(name)||[]])fn(e);return e;}
 setAttribute(k,v){this.attributes[k]=String(v)}
 setPointerCapture(id){this.captures.add(id)}hasPointerCapture(id){return this.captures.has(id)}releasePointerCapture(id){this.captures.delete(id)}
}
const window=new Node(),document=new Node();document.hidden=false;globalThis.window=window;globalThis.document=document;
const frames=new Map();let next=0,clock=0,reduced=false;globalThis.requestAnimationFrame=f=>{frames.set(++next,f);return next};globalThis.cancelAnimationFrame=id=>frames.delete(id);globalThis.matchMedia=()=>({matches:reduced});
let observer;globalThis.ResizeObserver=class{constructor(fn){this.fn=fn;observer=this;}observe(){}disconnect(){this.done=true}};
function flush(n=1000){let k=0;while(frames.size&&k++<n){const batch=[...frames.values()];frames.clear();clock+=1000/60;batch.forEach(fn=>fn(clock));}return k;}
const nodes=Object.fromEntries(['host','card','trajectory','radar','radarDot','powerText','powerBar','angleText','aimText','hit'].map(k=>[k,new Node()]));
const phases=[],outcomes=[];let starts=0,geometry;const current={payload:{title:'Actual draft'},locked:false,onStart:()=>{starts++;return true},onOutcome:(id,result)=>outcomes.push(result)};
const controller=createCourtController({nodes,getCurrent:()=>current,setGeometry:g=>geometry=g,onPhase:p=>phases.push(p)});
for(const target of ['icon','title','badge','corner']){controller.reset();nodes.card.emit('pointerdown',{target});assert.equal(nodes.card.captures.size,1);window.emit('pointermove',{clientX:1010,clientY:1015});flush(1);assert.equal(nodes.powerText.textContent,'14%');window.emit('pointercancel');assert.equal(nodes.card.captures.size,0);assert.equal(phases.at(-1),'ready');}
controller.reset();nodes.card.emit('pointerdown');window.emit('pointermove',{clientX:1000,clientY:1160});flush(1);const pos=nodes.card.style.transform;assert.equal(nodes.powerText.textContent,'100%');window.emit('pointermove',{clientX:1000,clientY:1230});flush(1);assert.equal(nodes.powerText.textContent,'100%');assert.notEqual(nodes.card.style.transform,pos);window.emit('pointerup',{clientX:1000,clientY:1230});assert.equal(starts,0,'outside release never starts a flight');assert.equal(nodes.card.captures.size,0);
controller.reset();nodes.card.emit('pointerdown');window.emit('pointerup');assert.equal(starts,0,'click is not a throw');assert.equal(nodes.card.emit('click').stopped,true,'click after release is swallowed');
for(const type of ['lostpointercapture','blur','resize','visibility']){controller.reset();nodes.card.emit('pointerdown');window.emit('pointermove',{clientY:1020});if(type==='lostpointercapture')nodes.card.emit(type);if(type==='blur')window.emit('blur');if(type==='resize'){nodes.host.clientWidth+=5;observer.fn();}if(type==='visibility'){document.hidden=true;document.emit('visibilitychange');document.hidden=false;}assert.equal(nodes.card.captures.size,0,type+' releases capture');assert.equal(phases.at(-1),'ready');}
controller.reset();controller.shoot();assert.equal(starts,1);assert.equal(phases.at(-1),'flying');controller.shoot();assert.equal(starts,1,'synchronous flight guard');nodes.card.emit('keydown',{key:'Escape'});flush();assert.equal(outcomes.length,0,'Escape cancels flight before score');
controller.reset();nodes.card.emit('pointerdown',{pointerType:'touch'});window.emit('pointermove',{pointerType:'touch',clientX:1000,clientY:900});window.emit('pointerup',{pointerType:'touch',clientX:1000,clientY:900});flush();assert.equal(outcomes.at(-1).outcome,'missed');
controller.reset();reduced=true;nodes.card.emit('keydown',{key:'Enter'});flush();assert.equal(outcomes.at(-1).outcome,'scored','assisted keyboard uses same physics in reduced motion');assert.equal(outcomes.at(-1).rimPassed,true);
controller.reset();current.locked=true;const blockedStarts=starts;controller.shoot();nodes.card.emit('pointerdown');assert.equal(starts,blockedStarts);assert.equal(nodes.card.captures.size,0);current.locked=false;
controller.reset();nodes.card.emit('pointerdown');window.emit('pointermove',{clientY:1020});controller.dispose();assert.equal(nodes.card.captures.size,0);assert.equal(frames.size,0);assert.ok(observer.done);assert.equal(window.events.size,0);assert.equal(document.events.size,0);assert.equal(nodes.card.events.size,0);flush();
console.log('PASS: actual pointer controller unit harness: all card targets, continuous drag above 100%, outside/click/capture loss/cancel/blur/resize/hidden/Escape, touch events, assisted keyboard, duplicate guard and resource cleanup.');
