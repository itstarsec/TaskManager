import assert from 'node:assert/strict';
import {filterTasks,taskMatchesQueue} from '../app/legacy/services/task-views.js';
const now=new Date('2026-10-21T00:15:00+07:00');
const tasks=[
 {id:1,title:'Kiểm tra mạng',description:'Báo cáo',status:'in_progress',priority:'urgent',assignee_id:2,deadline:'2026-10-20T18:00:00Z',supporters:[]},
 {id:2,title:'Đã xong',status:'completed',priority:'high',assignee_id:1,deadline:'2026-10-19T00:00:00Z'},
 {id:3,title:'Phối hợp',status:'todo',priority:'medium',assignee_id:2,deadline:'2026-10-20T17:00:00Z',supporters:[{user_id:1}]},
 {id:4,title:'Chưa giao',status:'todo',priority:'low',assignee_id:null,deadline:null},
 {id:5,title:'Tôi phụ trách',status:'todo',priority:'medium',assignee_id:1,supporters:[{user_id:1}]}
];
const ids=options=>filterTasks(tasks,{now,userId:1,...options}).map(t=>t.id);
assert.deepEqual(ids({queue:'today'}),[3,1]);
assert.deepEqual(ids({queue:'overdue'}),[3]);
assert.deepEqual(ids({queue:'unassigned'}),[4]);
assert.deepEqual(ids({queue:'assigned'}),[5,2]);
assert.deepEqual(ids({queue:'supporting'}),[3]);
assert.deepEqual(ids({queue:'completed'}),[2]);
assert.deepEqual(ids({search:'KIỂM TRA',priority:'urgent'}),[1]);
assert.deepEqual(ids({search:'BÁO CÁO'}),[1]);
assert.deepEqual(ids({assignee:'2',status:'todo'}),[3]);
assert.equal(taskMatchesQueue(tasks[1],'overdue',1,now),false);
assert.equal(taskMatchesQueue(tasks[3],'today',1,now),false);
assert.equal(ids({}).at(-1),2);
console.log('PASS: 12 workspace checks; Vietnamese date boundary, personal assignment/support, filters and sorting.');
