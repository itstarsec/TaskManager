import assert from 'node:assert/strict';
import {courtGeometry,PHYSICS,shotState,pullShot,predict,step,assistedVelocity,releaseInside,advanceFrame,bounds} from '../app/legacy/components/basketball/physics.js';
import {CreationFlow} from '../app/legacy/components/basketball/creation-flow.js';
import {emptyTaskDraft,prepareTask} from '../app/legacy/services/task-creation.js';
import {newAttemptId} from '../app/legacy/components/basketball/attempt-id.js';
assert.equal(newAttemptId({getRandomValues:bytes=>bytes.fill(7)}),'07'.repeat(16),'HTTP preview uses secure random bytes without randomUUID');
assert.throws(()=>newAttemptId({}),/HTTPS/);
const g=courtGeometry(600,540),base=assistedVelocity(g),initial=shotState(g.home,base);
assert.equal(predict(initial,g).state.outcome,'scored');assert.equal(initial.time,0,'prediction does not mutate flight');
for(const w of [240,250,264,280,305,330,360,390,420,450,480,550,650,800]){const court=courtGeometry(w,540),v=assistedVelocity(court);assert.ok(v,`assistance calibrated for ${w}px`);assert.equal(predict(shotState(court.home,v),court).state.outcome,'scored');}
// Fixed collision fixtures stay independent of assistance choosing an easier shot.
const bankBase={vx:198.62068965517267,vy:-742.4482758620686,omega:0};
const weak=shotState(g.home,{vx:30,vy:-220}),strong=shotState(g.home,{vx:700,vy:-1450}),bankIn=pullShot(g,-14,10,bankBase),bankOut=pullShot(g,-40,-62,bankBase),manual=pullShot(g,2,18,bankBase);
for(const s of [bankIn,bankOut,manual])assert.ok(releaseInside(s,g));
assert.equal(predict(weak,g).state.outcome,'missed');assert.equal(predict(strong,g).state.outcome,'missed');
const bank=predict(bankIn,g).state;assert.equal(bank.outcome,'scored');assert.ok(bank.hits>0);assert.equal(bank.bounces,0);
const out=predict(bankOut,g).state;assert.equal(out.outcome,'missed');assert.ok(out.hits>0);
assert.equal(predict(manual,g).state.outcome,'scored');
const graze=shotState({x:g.rimX-g.gap/2,y:g.rimY-g.cardH/2-1},{vx:0,vy:250});step(graze,g);assert.equal(graze.rimPassed,false,'rim contact never instantly scores');
const below=shotState({x:g.rimX-40,y:g.rimY+g.cardH},{vx:160,vy:0});assert.equal(predict(below,g).state.outcome,'missed','below-rim crossing is not a basket');
const edgeOnly=shotState({x:g.rimX,y:g.rimY-g.cardH/2-1},{vx:0,vy:300});step(edgeOnly,g,.01);assert.equal(edgeOnly.rimPassed,false,'a leading corner alone does not score');
const throughRim=shotState({x:g.rimX,y:g.rimY-1},{vx:0,vy:300});step(throughRim,g,.01);assert.equal(throughRim.outcome,'scored');assert.equal(throughRim.rimPassed,true);assert.ok(throughRim.y-bounds(throughRim,g).hy<g.rimY+g.netDepth,'score immediately at the mouth, before the full card clears the net');
const tilted=shotState({x:g.rimX+40,y:g.rimY-1},{vx:0,vy:300},Math.PI/4);step(tilted,g,.01);assert.equal(tilted.outcome,'scored','corners do not all need to fit inside the rim');assert.ok(tilted.x+bounds(tilted,g).hx>g.rimX+g.gap/2-g.radius);
const relaxed=shotState({x:g.rimX-60,y:g.rimY-80},{vx:180,vy:150});assert.equal(predict(relaxed,g).state.outcome,'scored','passing the mouth scores even if the later trajectory would leave the tapered net');
const upward=shotState({x:g.rimX,y:g.rimY+1},{vx:0,vy:-250});step(upward,g,.02);assert.equal(upward.rimPassed,false,'upward crossing never scores');
const wide=courtGeometry(800,540),outsideShots=[-1,1].map(side=>shotState({x:wide.rimX+side*(wide.gap/2+wide.cardW),y:wide.rimY-1},{vx:0,vy:300}));
for(const shot of outsideShots){step(shot,wide,.02);assert.equal(shot.rimPassed,false,'downward crossing outside either edge never scores');assert.equal(predict(shot,wide).state.outcome,'missed');}
assert.equal(releaseInside(pullShot(g,0,160,base),g),false);assert.notEqual(pullShot(g,0,160,base).y,pullShot(g,0,230,base).y,'card keeps following beyond 100% power');
for(const input of [initial,weak,strong,bankIn,bankOut,relaxed]){
 const reference=predict(input,g).state;
 for(const fps of [30,60,120]){const runtime={state:structuredClone(input),accumulator:0};let frames=0;while(runtime.state.outcome==='flying'&&frames++<1500)advanceFrame(runtime,1/fps,g);assert.equal(runtime.state.outcome,reference.outcome);assert.ok(Math.abs(runtime.state.x-reference.x)<1e-8);assert.ok(Math.abs(runtime.state.y-reference.y)<1e-8);}
 assert.deepEqual(predict(input,g).state,reference,'deterministic repeat');
}
const stalled={state:structuredClone(initial),accumulator:0};advanceFrame(stalled,5,g);assert.ok(stalled.state.time<=.051,'delta is bounded');
// The compact desktop scene scales all physical lengths and gravity together.
// Protect the previously narrow viewport bands where assistance had no valid shot.
for(let width=240;width<=688;width+=16){const compact=courtGeometry(width,460),v=assistedVelocity(compact);assert.ok(v,`compact scene calibrated at ${width}px`);const shot=shotState(compact.home,v),expected=predict(shot,compact).state;assert.equal(expected.outcome,'scored');for(const fps of [30,60,120]){const runtime={state:structuredClone(shot),accumulator:0};let frames=0;while(runtime.state.outcome==='flying'&&frames++<1500)advanceFrame(runtime,1/fps,compact);assert.equal(runtime.state.outcome,'scored');assert.ok(Math.abs(runtime.state.x-expected.x)<1e-8);}}
let posts=0,notices=0,resolveCreate;const phases=[],payload={title:'Thẻ đúng nghiệp vụ',subtasks:[{title:'Bước 1'}]};
const flow=new CreationFlow({payload,key:'fixture-intent-00001',create:()=>{posts++;return new Promise(r=>resolveCreate=r)},verify:async()=>({state:'absent'}),onState:s=>phases.push(s.phase),onCreated:()=>notices++});
assert.equal(posts,0);assert.equal(flow.settleShot('fake',{outcome:'scored',rimPassed:true}),null);assert.equal(posts,0);
assert.ok(flow.startShot('shot-1'));flow.settleShot('shot-1',{outcome:'missed',rimPassed:false});assert.equal(posts,0);assert.equal(flow.phase,'missed');
for(const [index,result] of [predict(weak,g).state,predict(strong,g).state,out,predict(below,g).state,...outsideShots.map(s=>predict(s,wide).state),{outcome:'scored',rimPassed:false},{outcome:'missed',rimPassed:true}].entries()){
 const id='miss-'+index;assert.ok(flow.startShot(id));flow.settleShot(id,result);assert.equal(posts,0,'misses and unconfirmed crossings never create tasks');assert.equal(flow.phase,'missed');assert.deepEqual(flow.payload,payload,'miss keeps the entire draft for a new throw');
}
assert.ok(flow.startShot('shot-2'));const saved=flow.settleShot('shot-2',predict(relaxed,g).state);flow.settleShot('shot-2',predict(relaxed,g).state);assert.equal(flow.phase,'creating');assert.equal(flow.startShot('duplicate'),false);await Promise.resolve();assert.equal(posts,1);assert.notEqual(flow.phase,'created');resolveCreate({id:55,title:payload.title});await saved;assert.equal(flow.phase,'created');assert.equal(notices,1);flow.settleShot('shot-2',predict(initial,g).state);await flow.retry();assert.equal(posts,1);
let attempts=0,verifies=0;const keys=[];const retry=new CreationFlow({payload,key:'same-intent-key-00002',create:async(p,{key})=>{keys.push(key);if(++attempts===1)throw new Error('Lost response');return {id:99};},verify:async()=>{verifies++;return {state:'absent'}}});retry.startShot('s');await retry.settleShot('s',bank);assert.equal(retry.phase,'error');await Promise.all([retry.retry(),retry.retry()]);assert.equal(attempts,2);assert.equal(verifies,1);assert.equal(retry.phase,'created');assert.deepEqual(keys,['same-intent-key-00002','same-intent-key-00002']);assert.deepEqual(retry.payload,payload);
let replayPosts=0;const uncertain=new CreationFlow({payload,key:'committed-intent-0003',create:async()=>{replayPosts++;throw new Error('response lost after commit')},verify:async()=>({state:'created',task:{id:80}})});uncertain.startShot('s');await uncertain.settleShot('s',bank);await uncertain.retry();assert.equal(uncertain.phase,'created');assert.equal(replayPosts,1,'verification avoids a second POST after commit');
let recoveredPosts=0;const recovery=new CreationFlow({payload,key:'recover-intent-00004',create:async()=>{recoveredPosts++;return {id:12}},verify:async()=>({state:'absent'})});await recovery.recover();assert.equal(recoveredPosts,0,'opening a pending intent only verifies');assert.equal(recovery.phase,'error');await recovery.retry();assert.equal(recoveredPosts,1);
const cancelled=new CreationFlow({payload,key:'cancel-intent-00005',create:async()=>{throw new Error('must not run')},verify:async()=>({state:'absent'})});cancelled.startShot('s');cancelled.cancelShot();assert.equal(cancelled.settleShot('s',bank),null);assert.equal(cancelled.phase,'ready');
let late;const disposed=new CreationFlow({payload,key:'dispose-intent-0006',create:()=>new Promise(r=>late=r),verify:async()=>({}),onState:s=>{if(s.phase==='created')throw new Error('must not update unmounted UI')}});disposed.startShot('s');const pending=disposed.settleShot('s',bank);await Promise.resolve();disposed.dispose();late({id:14});await pending;assert.equal(disposed.notified,false);
const draft=emptyTaskDraft();assert.throws(()=>prepareTask(draft),/200/);draft.title='  Công việc thật  ';draft.deadline='2026-12-31';draft.assigneeId='2';draft.supporterIds=[2,3,3];draft.subtasks=[{title:' Bước 1 '},{title:'  '}];const prepared=prepareTask(draft);assert.equal(prepared.title,'Công việc thật');assert.equal(prepared.deadline,'2026-12-31T23:59:59+07:00');assert.deepEqual(prepared.supporter_ids,[3]);assert.deepEqual(prepared.subtasks,[{title:'Bước 1'}]);
console.log('PASS: friendly downward rim crossing (no full-net/corner-fit requirement), outside/upward/below-rim misses, weak/strong/bank-in/bank-out, prediction parity and 30/60/120 FPS; zero creates on misses with retained payload, backend-confirmed success, duplicate guard, retry/recovery, cancellation/unmount and validation.');
