import assert from 'node:assert/strict';
import * as THREE from 'three';
import {dispatchState,laneTasks} from '../app/legacy/components/dispatch/dispatch-state.js';
import {createDeskScene} from '../app/legacy/components/dispatch/scene-engine.js';
const tasks=[{id:1,status:'todo',deadline:'2026-10-20T16:00:00'},{id:2,status:'completed',deadline:'2026-01-01T00:00:00Z'},{id:3,status:'in_progress'},{id:4,status:'todo',deadline:'2026-10-20T15:00:00Z'}];
assert.deepEqual(dispatchState(tasks,new Date('2026-10-20T15:30:00Z')),{counts:[2,1,1],overdue:1});
assert.deepEqual(laneTasks(tasks,'todo').map(t=>t.id),[4,1]);assert.deepEqual(tasks.map(t=>t.id),[1,2,3,4]);assert.deepEqual(dispatchState([]).counts,[0,0,0]);
// CPU scene checks use the real Three geometry, matrices and raycaster. No GPU is claimed.
const frames=new Map();let seq=0,clock=0;globalThis.requestAnimationFrame=f=>{frames.set(++seq,f);return seq};globalThis.cancelAnimationFrame=id=>frames.delete(id);globalThis.devicePixelRatio=3;
let mobile=false;globalThis.matchMedia=()=>({matches:mobile});
const documentEvents=new Map();globalThis.document={hidden:false,addEventListener:(n,f)=>documentEvents.set(n,f),removeEventListener:n=>documentEvents.delete(n)};
const observers=[];class Observer{constructor(f){this.f=f;this.disconnected=false;observers.push(this)}observe(){}disconnect(){this.disconnected=true}}
globalThis.ResizeObserver=Observer;globalThis.IntersectionObserver=Observer;
const events=new Map(),canvasEvents=new Map();let capture=false,removed=false,destroyed=false,renderCount=0,pixelRatio;
const host={clientWidth:640,clientHeight:330,style:{},appendChild(){},getBoundingClientRect:()=>({left:0,top:0,width:640,height:330}),addEventListener:(n,f)=>events.set(n,f),removeEventListener:n=>events.delete(n),setPointerCapture:()=>capture=true,hasPointerCapture:()=>capture,releasePointerCapture:()=>capture=false};
let scene,camera;const renderer={domElement:{addEventListener:(n,f)=>canvasEvents.set(n,f),removeEventListener:n=>canvasEvents.delete(n),remove:()=>removed=true},shadowMap:{},setPixelRatio:n=>pixelRatio=n,setClearColor(){},setSize(){},render(s,c){scene=s;camera=c;s.updateMatrixWorld(true);renderCount++},dispose(){destroyed=true},forceContextLoss(){}};
const selected=[];let creates=0,lost=0;let state={counts:[0,6,1],selected:'in_progress',hover:null,interactive:false,auto:false,reset:0,reduced:false,busy:false,canCreate:true,overdue:1};
const engine=createDeskScene(host,state,{onSelect:id=>selected.push(id),onCreate:()=>creates++,onUnavailable:()=>lost++},()=>renderer);
function flush(limit=200){let n=0;while(frames.size&&n++<limit){const batch=[...frames.values()];frames.clear();clock+=16;batch.forEach(f=>f(clock));}return n;}
flush();assert.equal(frames.size,0,'idle rendering stops');assert.equal(pixelRatio,1.5,'DPR is capped');
const desk=scene.children.find(x=>x.isGroup),trays=desk.children.filter(x=>x.isGroup);assert.equal(trays.length,3);
assert.deepEqual(trays.map(t=>t.children.filter(c=>c.isMesh&&Math.abs(c.position.x-1.4)<1e-6&&c.scale.z===2.5&&c.visible).length),[0,5,1],'visual cards capped without changing counts');
const box=o=>new THREE.Box3().setFromObject(o);
for(const tray of trays){const [floor,back,left,right]=tray.children;assert.ok(Math.abs(box(floor).max.y-box(back).min.y)<1e-6);assert.ok(Math.abs(box(back).max.z-box(left).min.z)<1e-6);assert.ok(Math.abs(box(back).max.z-box(right).min.z)<1e-6);}
function eventAt(mesh){scene.updateMatrixWorld(true);const p=mesh.getWorldPosition(new THREE.Vector3()).project(camera);return {button:0,pointerId:1,clientX:(p.x+1)*320,clientY:(1-p.y)*165,preventDefault(){}};}
const trayEvent=eventAt(trays[2].children[4]);events.get('pointerdown')(trayEvent);events.get('pointerup')(trayEvent);flush();assert.equal(selected.at(-1),'completed','raycast invokes same selection action');
const button=desk.children.find(x=>x.userData.action==='create'),buttonEvent=eventAt(button);events.get('pointerdown')(buttonEvent);events.get('pointerup')(buttonEvent);flush();assert.equal(creates,1);
engine.update({...state,busy:true});events.get('pointerdown')(trayEvent);events.get('pointerup')(trayEvent);assert.equal(selected.length,1,'busy actions disabled');engine.update(state);
events.get('pointerdown')(trayEvent);events.get('pointermove')({...trayEvent,clientX:trayEvent.clientX+80});events.get('pointerup')({...trayEvent,clientX:trayEvent.clientX+80});flush();assert.equal(selected.length,1,'drag does not click');const rotated=camera.position.clone();assert.ok(Math.abs(rotated.x-rotated.z)>.5);
engine.update({...state,reset:1});flush();assert.ok(Math.abs(camera.position.x-camera.position.z)<1e-6,'reset restores isometric angle');
mobile=true;engine.update({...state,reset:2});flush();const before=camera.position.clone();events.get('pointerdown')(trayEvent);events.get('pointermove')({...trayEvent,clientX:trayEvent.clientX+80});events.get('pointerup')({...trayEvent,clientX:trayEvent.clientX+80});flush();assert.ok(camera.position.distanceTo(before)<1e-6,'mobile orbit locked until opt in');assert.equal(host.style.touchAction,'pan-y');
engine.update({...state,interactive:true,reset:3});flush();assert.equal(host.style.touchAction,'none');
engine.update({...state,auto:true,reduced:true});flush();assert.equal(frames.size,0,'reduced motion prevents continuous rotation');
document.hidden=true;documentEvents.get('visibilitychange')();engine.update({...state,hover:'todo'});assert.equal(frames.size,0,'hidden tab does not render');document.hidden=false;documentEvents.get('visibilitychange')();flush();
observers[1].f([{isIntersecting:false}]);engine.update({...state,auto:true});assert.equal(frames.size,0,'offscreen scene does not render');observers[1].f([{isIntersecting:true}]);assert.equal(frames.size,1);engine.update(state);flush();
canvasEvents.get('webglcontextlost')({preventDefault(){}});assert.equal(lost,1,'context loss switches to fallback');
let disposedGeometry=0;const unique=new Set();scene.traverse(o=>{if(o.geometry&&!unique.has(o.geometry)){unique.add(o.geometry);o.geometry.addEventListener('dispose',()=>disposedGeometry++);}});
engine.dispose();assert.equal(disposedGeometry,unique.size);assert.ok(observers.every(o=>o.disconnected));assert.equal(documentEvents.size,0);assert.equal(events.size,0);assert.equal(canvasEvents.size,0);assert.equal(frames.size,0);assert.ok(removed&&destroyed);
console.log('PASS: dispatch state, actual Three geometry contacts, raycast actions, drag/click, mobile opt-in, reset, idle/hidden/offscreen/reduced motion and cleanup (CPU; GPU not tested).');
