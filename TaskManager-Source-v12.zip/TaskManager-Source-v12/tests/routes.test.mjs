// Exercise the packaged Worker using only an isolated synthetic D1 database.
// No production credentials, user records or network requests are used.
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createHash,randomBytes,scryptSync} from 'node:crypto';
import {resolve} from 'node:path';
const require=createRequire(realpathSync('node_modules/wrangler/package.json'));
const {Miniflare}=require('miniflare');
const modulePaths=['index.js',...readdirSync('dist/server',{recursive:true}).filter(p=>p!=='index.js'&&/\.(?:js|mjs)$/.test(p))];
const mf=new Miniflare({
 modules:modulePaths.map(path=>({type:'ESModule',path:resolve('dist/server',path)})),modulesRoot:resolve('dist/server'),
 compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],
 d1Databases:['DB'],r2Buckets:['BUCKET'],
 assets:{directory:resolve('dist/client'),binding:'ASSETS',routerConfig:{invoke_user_worker_ahead_of_assets:true,has_user_worker:true}},
 outboundService:()=>new Response('External access disabled for route tests',{status:503})
});
try{
 const db=await mf.getD1Database('DB');
 for(const file of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort()){
  const sql=readFileSync('drizzle/'+file,'utf8').replaceAll('--> statement-breakpoint','');
  await db.batch(sql.split(';').map(s=>s.trim()).filter(Boolean).map(s=>db.prepare(s)));
 }
 const stamp=new Date().toISOString();
 const password='Fixture-route-password-2026!',salt=randomBytes(16).toString('hex');
 const passwordHash='scrypt$16384$8$5$'+salt+'$'+scryptSync(password,salt,32,{N:16384,r:8,p:5,maxmem:64*1024*1024}).toString('hex');
 await db.prepare('INSERT INTO roles(id,name,code,is_active,created_at) VALUES (1,?,?,1,?)').bind('Admin','admin',stamp).run();
 await db.prepare('INSERT INTO users(id,username,full_name,role_id,is_active,is_super_admin,must_change_password,created_at,password_hash) VALUES (1,?,?,1,1,1,0,?,?)').bind('fixture-admin','Quản trị kiểm thử',stamp,passwordHash).run();
 await db.prepare("INSERT INTO site_state(key,value) VALUES ('local_auth_v1',?)").bind(stamp).run();
 const token=randomBytes(32).toString('hex');
 await db.prepare('INSERT INTO auth_sessions(token_hash,user_id,created_at,expires_at) VALUES (?,1,?,?)').bind(createHash('sha256').update(token).digest('hex'),stamp,new Date(Date.now()+3600000).toISOString()).run();
 const cookie='__Host-taskmanager_session='+token;
 const routes=[['/dashboard','Tổng quan'],['/tasks','Tất cả công việc'],['/my-tasks','Việc của tôi'],['/support','Yêu cầu hỗ trợ'],['/notifications','Bảng thông báo'],['/reports','Báo cáo'],['/support/settings','Phòng ban &amp; nhóm'],['/settings','Cài đặt']];
 let checks=0;
 for(const [path,title] of routes){
  const denied=await mf.dispatchFetch('https://test.local'+path,{redirect:'manual'});
  assert.equal(denied.status,307,path+' unauthenticated: '+(denied.status===307?'':(await denied.text()).slice(0,4000)));assert.equal(denied.headers.get('location'),'/login');checks++;
  const response=await mf.dispatchFetch('https://test.local'+path,{headers:{cookie},redirect:'manual'});const html=await response.text();
  assert.equal(response.status,200,path+' HTML');
  assert.match(html,new RegExp('class="page-title">'+title+'</div>'),path+' shows its own page title');
  assert.equal(html.includes(passwordHash),false,path+' excludes password hashes');
  assert.equal(html.includes(token),false,path+' excludes session tokens');checks++;
  const rsc=await mf.dispatchFetch('https://test.local'+path+'.rsc',{headers:{cookie,RSC:'1'},redirect:'manual'});const body=await rsc.text();
  assert.equal(rsc.status,200,path+' navigation');assert.match(rsc.headers.get('content-type'),/text\/x-component/);assert.doesNotMatch(body,/:E\{/);checks++;
 }
 const profile=await mf.dispatchFetch('https://test.local/api/auth/me',{headers:{cookie}});const user=await profile.json();assert.equal(user.role_code,'admin');assert.equal('password_hash'in user,false);checks++;
 const expired=await mf.dispatchFetch('https://test.local/tasks',{headers:{cookie:'__Host-taskmanager_session='+randomBytes(32).toString('hex')},redirect:'manual'});assert.equal(expired.status,307);checks++;
 const origin='https://external-client.example';
 const preflight=await mf.dispatchFetch('https://test.local/api/auth/login',{method:'OPTIONS',headers:{origin,'access-control-request-method':'POST','access-control-request-headers':'content-type'}});
 assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),origin);assert.equal(preflight.headers.get('access-control-allow-credentials'),'true');checks++;
 const login=await mf.dispatchFetch('https://test.local/api/auth/login',{method:'POST',headers:{origin,'sec-fetch-site':'cross-site','content-type':'application/json'},body:JSON.stringify({username:'fixture-admin',password})});
 assert.equal(login.status,200);assert.equal(login.headers.get('access-control-allow-origin'),origin);assert.match(login.headers.get('set-cookie'),/SameSite=None; Partitioned/);assert.equal('access_token'in await login.json(),false);checks++;
 const externalCookie=login.headers.get('set-cookie').split(';')[0];
 const externalHeaders={origin,cookie:externalCookie,'sec-fetch-site':'cross-site','content-type':'application/json'};
 const externalProfile=await mf.dispatchFetch('https://test.local/api/auth/me',{headers:externalHeaders});assert.equal(externalProfile.status,200);assert.equal((await externalProfile.json()).role_code,'admin');checks++;
 const newTask=await mf.dispatchFetch('https://test.local/api/tasks',{method:'POST',headers:externalHeaders,body:JSON.stringify({title:'Isolated cross-origin task'})});assert.equal(newTask.status,201);checks++;
 const tasks=await mf.dispatchFetch('https://test.local/api/tasks',{headers:externalHeaders});assert.equal(tasks.status,200);assert.equal((await tasks.json()).length,1);checks++;
 const otherOrigin=await mf.dispatchFetch('https://test.local/api/auth/me',{headers:{...externalHeaders,origin:'https://different.example'}});assert.equal(otherOrigin.status,401);assert.equal(otherOrigin.headers.get('access-control-allow-origin'),'https://different.example');checks++;
 const logout=await mf.dispatchFetch('https://test.local/api/auth/logout',{method:'POST',headers:externalHeaders});assert.equal(logout.status,200);assert.match(logout.headers.get('set-cookie'),/Max-Age=0/);checks++;
 const ended=await mf.dispatchFetch('https://test.local/api/auth/me',{headers:externalHeaders});assert.equal(ended.status,401);checks++;
 const trustedOrigin='https://hoptacxa.pages.dev',canonicalOrigin='https://taskmanager-1610.exactlamp6.chatgpt.site';
 const trustedLogin=await mf.dispatchFetch('https://test.local/api/auth/login',{method:'POST',headers:{origin:trustedOrigin,'sec-fetch-site':'cross-site','content-type':'application/json'},body:JSON.stringify({username:'fixture-admin',password})});
 assert.equal(trustedLogin.status,200);assert.equal(trustedLogin.headers.get('access-control-allow-origin'),trustedOrigin);assert.doesNotMatch(trustedLogin.headers.get('set-cookie'),/Partitioned|Domain=/i);checks++;
 const trustedCookie=trustedLogin.headers.get('set-cookie').split(';')[0];assert.ok(trustedCookie.startsWith('__Secure-taskmanager_trusted_session='));
 const dashboard=await mf.dispatchFetch('https://test.local/dashboard',{headers:{cookie:trustedCookie},redirect:'manual'});assert.equal(dashboard.status,200);assert.match(await dashboard.text(),/class="page-title">Tổng quan/);checks++;
 for(const origin of [trustedOrigin,canonicalOrigin]){
  const preflight=await mf.dispatchFetch('https://test.local/api/tasks',{method:'OPTIONS',headers:{origin,'access-control-request-method':'POST','access-control-request-headers':'content-type, authorization'}});assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),origin);checks++;
  const auth=await mf.dispatchFetch('https://test.local/api/auth/me',{headers:{origin,cookie:trustedCookie,'sec-fetch-site':'cross-site'}});assert.equal(auth.status,200);assert.equal((await auth.json()).role_code,'admin');checks++;
 }
 // Real D1 batch serialization: five concurrent requests share one intent.
 const payload={title:'Basketball D1 concurrency',subtasks:[{title:'Persist once'}],supporter_ids:[]};
 const key='basketball-route-concurrent-0001';
 const parallel=await Promise.all(Array.from({length:5},()=>mf.dispatchFetch('https://test.local/api/tasks',{method:'POST',headers:{cookie,'Content-Type':'application/json','Idempotency-Key':key},body:JSON.stringify(payload)})));
 const bodies=await Promise.all(parallel.map(r=>r.json()));
 assert.ok(parallel.every(r=>[200,201].includes(r.status)),JSON.stringify(bodies));
 assert.equal(parallel.filter(r=>r.status===201).length,1);assert.equal(new Set(bodies.map(b=>b.id)).size,1);checks++;
 const createdId=bodies[0].id;assert.equal((await db.prepare('SELECT count(*) n FROM subtasks WHERE task_id=?').bind(createdId).first()).n,1);checks++;
 const receipt=await mf.dispatchFetch('https://test.local/api/tasks/creation-status?key='+key,{headers:{cookie}});assert.equal((await receipt.json()).task.id,createdId);checks++;
 console.log('PASS: '+checks+' packaged route checks; eight tabs, legacy sessions, cross-origin login/access/logout, hoptacxa login to dashboard and trusted-origin CORS.');
}finally{await mf.dispose();}
