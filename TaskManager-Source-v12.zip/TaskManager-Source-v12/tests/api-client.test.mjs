import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import ts from 'typescript';
import api from '../app/legacy/services/api.js';

const originalFetch=globalThis.fetch,originalWindow=globalThis.window;
const events=[],redirects=[];
globalThis.window={dispatchEvent:event=>events.push(event),location:{replace:url=>redirects.push(url)}};
try {
  let calls=0,resolveRequest;
  globalThis.fetch=async()=>{calls++;return new Promise(resolve=>resolveRequest=resolve);};
  const first=api.get('/shared',undefined,{timeoutMs:1000}),second=api.get('/shared',undefined,{timeoutMs:1000});
  assert.equal(calls,1);resolveRequest(Response.json([{id:1}]));
  assert.deepEqual((await first).data,(await second).data);

  // No AbortSignal.timeout/any dependency; a stalled fetch cannot pin a GET forever.
  globalThis.fetch=()=>new Promise(()=>{});
  await assert.rejects(api.get('/members-hang',undefined,{timeoutMs:10}),/phản hồi quá lâu/);
  globalThis.fetch=async()=>Response.json([{id:2}]);
  assert.deepEqual((await api.get('/members-hang')).data,[{id:2}],'failed shared GET is removed before retry');

  let aborted=false;
  globalThis.fetch=async(_url,options)=>{options.signal.addEventListener('abort',()=>aborted=true);return {ok:true,status:200,json:()=>new Promise(()=>{})};};
  await assert.rejects(api.get('/body-hang',undefined,{timeoutMs:10}),/phản hồi quá lâu/);
  assert.equal(aborted,true,'response body timeout aborts transport');

  globalThis.fetch=()=>new Promise(()=>{});
  const old=api.get('/members-retry',undefined,{timeoutMs:25});
  globalThis.fetch=async()=>Response.json([{id:3}]);
  assert.deepEqual((await api.get('/members-retry',undefined,{dedupe:false,timeoutMs:1000})).data,[{id:3}],'explicit retry does not join stale GET');
  await assert.rejects(old);

  globalThis.fetch=()=>new Promise(()=>{});
  const external=new AbortController(),pending=api.get('/cancel-members',undefined,{signal:external.signal,timeoutMs:1000});
  external.abort();await assert.rejects(pending);
  let requested=false;globalThis.fetch=async()=>{requested=true;return Response.json([]);};
  await assert.rejects(api.get('/already-cancelled',undefined,{signal:external.signal}));assert.equal(requested,false);

  globalThis.fetch=async()=>Response.json({detail:'Không có quyền'},{status:403});
  await assert.rejects(api.get('/forbidden'),error=>error.response.status===403&&error.message==='Không có quyền');
  globalThis.fetch=async()=>Response.json({detail:'Đã hết phiên'},{status:401});
  await assert.rejects(api.get('/auth/me'));assert.deepEqual(redirects,['/login']);
  globalThis.fetch=async()=>Response.json({id:9},{status:201});
  await api.post('/tasks',{title:'Fixture'},{headers:{'Idempotency-Key':'same-intent'}});
  assert.equal(events.length,1);assert.equal(events[0].detail.entity,'task');
  globalThis.fetch=async()=>{throw new TypeError('Network error');};
  await assert.rejects(api.get('/network'),error=>error.response.status===0);

  // Render the actual form in loading/error states: optional membership never locks preparation.
  let source=readFileSync('app/legacy/components/basketball/TaskSetupForm.jsx','utf8');
  source=source.replace("from 'lucide-react'",`from '${import.meta.resolve('lucide-react')}'`);
  const compiled=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replaceAll('"react/jsx-runtime"',JSON.stringify(import.meta.resolve('react/jsx-runtime')));
  const {default:Form}=await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'));
  const props={draft:{title:'Giữ nội dung',description:'',priority:'medium',deadline:'',assigneeId:'',supporterIds:[],subtasks:[]},users:[],disabled:false,onChange(){},onPrepare(){},onReloadUsers(){}};
  for(const state of [{loadingUsers:true},{loadingUsers:false,error:'Mất kết nối'}]){
    const html=renderToStaticMarkup(React.createElement(Form,{...props,...state}));
    assert.match(html,/<button type="submit" class="btc-primary">/);
    assert.match(html,/<option value="" selected="">Chưa phân công<\/option>/);
    assert.doesNotMatch(html,/<select[^>]*disabled/);
    assert.match(html,/value="Giữ nội dung"/);
  }
  const failed=renderToStaticMarkup(React.createElement(Form,{...props,loadingUsers:false,error:'Mất kết nối'}));
  assert.match(failed,/Tải lại thành viên/);assert.match(failed,/phân công sau/);
  const locked=renderToStaticMarkup(React.createElement(Form,{...props,disabled:true}));
  assert.match(locked,/<button type="submit" class="btc-primary" disabled="">/,'business lock still applies');
  console.log('PASS: API client deduplication, stalled fetch/body deadlines, fresh retry, cancellation, HTTP/network errors and confirmed mutation events; actual task form remains usable during membership loading/failure.');
} finally {globalThis.fetch=originalFetch;globalThis.window=originalWindow;}
