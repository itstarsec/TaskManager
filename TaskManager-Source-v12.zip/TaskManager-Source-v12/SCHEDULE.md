# Deadline reminders after local authentication

The original hourly automation used the owner-private Sites access boundary. The Site now serves a username/password login on a public origin. The old schedule must remain paused until an unattended caller has a supported credential for the application.

Do not call the updater based on `OAI-Sites-Authorization` alone. Do not place credentials in the automation prompt, source, files or output, and do not change the audience to run the updater.

The application endpoint `/api/system/reminders` accepts a fully authenticated super-admin session or a dedicated `x-maintenance-token` whose SHA-256 digest matches secret `MAINTENANCE_TOKEN_SHA256`. That optional maintenance secret is not configured by this change. Once a supported unattended credential path is configured and verified, POST then GET this endpoint and compare `checked_at`; retry at most once on a transient failure. It only creates in-app deadline notifications.

While the schedule is paused, authenticated notification reads continue to check task deadlines in the application. Do not claim that closed-page hourly checks are active.
