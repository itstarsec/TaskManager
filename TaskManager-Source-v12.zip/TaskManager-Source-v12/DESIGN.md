# Task Manager — Isometric Workspace

## Phạm vi

Thiết kế lại giao diện của Task Manager hiện có. Tám phân hệ tiếp tục dùng API, dữ liệu và kiểm tra quyền hiện có. Không sửa phiên đăng nhập, CORS, dữ liệu nghiệp vụ, cấu hình nhắc hạn hoặc chính sách truy cập.

Tham khảo ngôn ngữ hình ảnh: https://isoglow.dev/demo/3d#tt. Đã đọc frontend công khai của demo: camera trực giao, Three.js, chất liệu matte, ánh sáng và emissive cục bộ. Chưa quan sát trực tiếp chuyển động WebGL của mẫu vì trình duyệt kiểm thử không tạo được WebGL context. Mô hình khay công việc là mã mới viết cho nghiệp vụ Task Manager.

## Cấu trúc

- `app/design-tokens.css`: màu sắc, bề mặt, viền, typography và bán kính.
- `app/isometric.css`: theme dùng chung, các điều khiển, biểu mẫu và responsive.
- `app/legacy/components/dispatch/DispatchDesk.jsx`: adapter dữ liệu công việc, khay được chọn, HTML controls và chuyển chế độ.
- `dispatch-state.js`: đếm trạng thái, tính quá hạn theo parser UTC hiện có, sắp xếp công việc.
- `DeskScene.jsx`: tải engine bất đồng bộ sau dữ liệu và khi gần viewport.
- `scene-engine.js`: Three.js, hình học, camera trực giao, raycasting, damping, click/drag, render theo nhu cầu và cleanup.
- `DeskFallback.jsx`: SVG isometric, cùng vị trí và cấu trúc ba khay.
- `app/legacy/components/useDialog.js`: focus, Tab, Escape và trả focus cho biểu mẫu tạo/chi tiết công việc.

Ba khay dùng trạng thái thật `todo`, `in_progress`, `completed`. Chọn khay bằng mô hình và nút HTML đi qua cùng handler. Nút dấu cộng trên mô hình mở đúng TaskModal hiện có. Dữ liệu chỉ được ghi khi biểu mẫu/API nghiệp vụ thực sự thành công. Số lượng ở HTML là số thực; mô hình hiển thị tối đa năm tấm để giữ hình khối rõ. Đèn cảnh báo chỉ sáng khi có việc quá hạn. Không tạo dữ liệu mẫu trên website đã triển khai.

## Tương tác và chế độ nhẹ

Kéo camera có giới hạn góc; dịch chuyển trên 6px được xem là kéo, không mở khay. Góc nhìn mặc định đặt lại camera. Tự xoay mặc định tắt; reduced motion tắt tự xoay và nội suy. Màn hình <=760px chỉ xoay sau khi bật “Tương tác 3D”; các vùng còn lại cuộn bình thường. Mọi chức năng có nút HTML tương ứng.

Chế độ nhẹ được lưu như tùy chọn giao diện trong localStorage, không lưu phiên hoặc dữ liệu nghiệp vụ. SVG được hiển thị trước. Không có WebGL, lỗi tải module hoặc mất context sẽ dùng SVG. Chọn khay nằm ở adapter nên giữ nguyên khi đổi chế độ. Renderer ngừng khi cảnh ngoài viewport hoặc tab ẩn; frame chỉ tiếp tục khi đang chuyển động. Một canvas, DPR tối đa 1.5 (1 ở mobile), geometry/material được tái sử dụng và dispose khi unmount.

## Chạy và kiểm tra

Dùng Node >=22.13 và pnpm theo package.json:

```sh
pnpm install --frozen-lockfile
pnpm dev
pnpm build
node tests/dispatch.test.mjs
node tests/workspaces.test.mjs
node tests/routes.test.mjs
pnpm exec tsc --noEmit --incremental false
```

Các binding D1/R2 và runtime thuộc Sites; không đưa credential dịch vụ vào frontend, repository hoặc tệp tải xuống. Giữ manifest `.openai/hosting.json` đúng dự án khi tiếp tục triển khai.

## Kết quả nghiệm thu — 21/10/2026

- Build production và TypeScript pass.
- 12 kiểm tra bộ lọc/công việc cá nhân và ranh giới ngày Việt Nam pass.
- 40 kiểm tra các route đóng gói, gồm tám tab và điều kiện phiên/CORS hiện có, pass trên môi trường kiểm thử.
- Kiểm tra CPU với hình học và Raycaster thật của Three.js pass: khớp các vách khay, số tấm giới hạn, nút tạo/chọn khay, phân biệt click/drag, khóa xoay mobile, reset camera, reduced motion, ngừng render khi idle/ẩn/ngoài viewport, mất context và cleanup.
- Trình duyệt: tám tab mở được trên desktop và khung viewport 320px; trong các trạng thái được kiểm tra không tràn ngang toàn trang. Menu mobile có tên tab đầy đủ. Bảng tiến độ, chi tiết công việc, tìm kiếm toàn cục, Enter chọn khay, giữ lựa chọn khi đổi chế độ, mở biểu mẫu và Escape đóng hoạt động trên dữ liệu QA riêng.
- Ảnh bàn giao dùng dữ liệu giả trong môi trường QA tách biệt; không phải ảnh dữ liệu người dùng. Ảnh mobile là ba viewport iframe 320/390/430px, không phải thiết bị vật lý.

## Giới hạn

Trình duyệt cloud đang tắt WebGL. Đã xác nhận fallback tự động hoạt động, nhưng chưa kiểm tra hình ảnh, bóng và quán tính của renderer trên GPU thật; cũng chưa nghiệm thu cảm ứng, Safari/iOS hoặc Android vật lý. Kiểm tra scene bằng CPU không thay thế kiểm tra GPU. Chưa đo FPS, Core Web Vitals hoặc benchmark thiết bị. Build có cảnh báo chunk lớn cho phần Three.js tải bất đồng bộ; không suy diễn kết quả hiệu năng từ cảnh báo này.

Không thực hiện thao tác ghi dữ liệu thật trong kiểm thử giao diện. Kiểm tra backend/route dùng môi trường giả lập, không xác nhận lại lỗi cookie ở proxy `hoptacxa.pages.dev`; proxy đó cần kiểm tra riêng.
