// Export the same vector component used in the interactive court.
import {readFileSync,writeFileSync} from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import ts from 'typescript';
import {courtGeometry} from '../app/legacy/components/basketball/physics.js';

async function component(name){
  const source=readFileSync(new URL('../app/legacy/components/basketball/'+name+'.jsx',import.meta.url),'utf8')
    .replace("from 'react'",`from '${import.meta.resolve('react')}'`)
    .replace(/from ['"]\.\/stage-geometry(?:\.js)?['"]/,`from '${new URL('../app/legacy/components/basketball/stage-geometry.js',import.meta.url).href}'`);
  const compiled=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText
    .replaceAll('"react/jsx-runtime"',JSON.stringify(import.meta.resolve('react/jsx-runtime')));
  return (await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'))).default;
}
const BasketballHoop=await component('BasketballHoop'),CourtStage=await component('CourtStage'),g=courtGeometry(600,540);
const svg=renderToStaticMarkup(React.createElement('svg',{xmlns:'http://www.w3.org/2000/svg',width:840,height:778,viewBox:'0 0 600 556',role:'img','aria-labelledby':'hoop-title'},
  React.createElement('title',{id:'hoop-title'},'Sân ném công việc Task Manager'),React.createElement('rect',{width:600,height:556,fill:'#121314'}),
  React.createElement(CourtStage,{geometry:g}),React.createElement(BasketballHoop,{geometry:g,phase:'ready'})))
  .replace(/var\(--btc-(?:accent|success|error),([^)]+)\)/g,'$1').replaceAll('var(--hoop-light)','#FFB45B')+'\n';
writeFileSync(new URL('../public/basketball-hoop.svg',import.meta.url),svg);
console.log('Exported public/basketball-hoop.svg from the production component.');
