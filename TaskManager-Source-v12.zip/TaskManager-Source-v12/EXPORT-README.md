# Task Manager — Source export v12

Đây là toàn bộ mã nguồn của phiên bản 12 đang triển khai, gồm frontend, backend Cloudflare Worker, schema/migrations D1, tài nguyên giao diện, cấu hình, lockfile, tài liệu và bộ kiểm thử. Có giao diện Basketball mới và điều kiện ném thân thiện: tâm thẻ qua miệng rổ từ trên xuống được tính trúng; ném trượt không tạo công việc và giữ nội dung để ném lại. Backend xác nhận lưu rồi mới hoàn tất.

## Phiên bản

- Source commit: 95d59e8b80b596506c78281f698e2d7d78115e25
- Site version: 12
- SOURCE-MANIFEST.json ghi SHA-256 của từng file mã nguồn để đối chiếu.
- Mã nguồn được giữ nguyên theo commit, không chỉnh sửa website trong quá trình xuất.

## Chuẩn bị và chạy

Cần Node.js >=22.13.0 và pnpm 11.25.0 theo package.json. Giải nén rồi mở terminal trong thư mục chứa package.json:

```sh
pnpm install --frozen-lockfile
pnpm build
pnpm dev
```

Lệnh dev dùng cấu hình portable của dự án và cổng 5173. Các lệnh trên là hướng dẫn từ cấu hình hiện có; bản ZIP này chưa được cài dependency/chạy lại trên máy của người nhận.

Ứng dụng cần môi trường Cloudflare Worker, D1 binding DB và R2 binding BUCKET để dùng nghiệp vụ đầy đủ. drizzle/ chứa ba migration cần áp dụng theo thứ tự cho cơ sở dữ liệu mới. Cấu hình D1 trong vite.config.ts sử dụng placeholder cho phát triển cục bộ; khi triển khai độc lập phải gắn database/bucket thực trong tài khoản của bạn. File .openai/hosting.json giữ thông tin định danh Sites hiện có.

Cơ sở dữ liệu, tài khoản và cấu hình runtime không nằm trong source ZIP. Đọc phần Account access của README.md để thiết lập hash quản trị BOOTSTRAP_ADMIN_HASH và luồng khởi tạo tài khoản. Bản source không tự mang theo dữ liệu hoặc mật khẩu của website đang chạy. Xem lib/auth.ts cho yêu cầu bootstrap và định dạng hash; không đặt credential thật vào source.

## Kiểm thử

Sau khi cài dependencies:

```sh
node node_modules/typescript/bin/tsc --noEmit --incremental false
node tests/basketball.test.mjs
node tests/basketball-pointer.test.mjs
node tests/api-client.test.mjs
node tests/api.test.mjs
node tests/workspaces.test.mjs
node tests/dispatch.test.mjs
pnpm build
node tests/routes.test.mjs
```

Các test API/route sử dụng cơ sở dữ liệu thử nghiệm tách biệt. Test route cần production build. Không chạy test trên cơ sở dữ liệu production.

## Tài liệu chính

- README.md: nghiệp vụ, xác thực, phân quyền và CORS.
- BASKETBALL.md: component, tích hợp API, vật lý, điều kiện ghi điểm và kiểm thử.
- DESIGN.md: cấu trúc và định hướng giao diện.
- SCHEDULE.md: nhắc hạn và giới hạn gọi tự động.

## Phạm vi bản xuất

Gói giữ toàn bộ source được quản lý trong Git, trừ tsconfig.tsbuildinfo là cache biên dịch. Không kèm lịch sử .git, node_modules, dist/build output, cache, dữ liệu D1/R2, dữ liệu QA, file .env hoặc credential dịch vụ. Thư mục build/ vẫn được giữ vì chứa mã nguồn plugin/Worker cần cho quá trình build; khác với thư mục dist/ sinh ra khi biên dịch.
