import { sqliteTable, integer, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const roles = sqliteTable("roles", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  code: text("code").notNull(),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull()
}, (table) => [uniqueIndex("uq_roles_code").on(table.code),uniqueIndex("uq_roles_name").on(table.name)]);

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull(),
  full_name: text("full_name").notNull(),
  role_id: integer("role_id"),
  telegram_chat_id: text("telegram_chat_id"),
  is_active: integer("is_active").notNull(),
  must_change_password: integer("must_change_password").notNull(),
  created_at: text("created_at").notNull(),
  position: text("position"),
  deleted_at: text("deleted_at"),
  avatar_url: text("avatar_url"),
  chatgpt_user_id: text("chatgpt_user_id").unique(),
  email: text("email"),
  password_hash: text("password_hash"),
  is_super_admin: integer("is_super_admin").notNull().default(0)
}, (table) => [uniqueIndex("uq_users_username").on(table.username)]);

export const tasks = sqliteTable("tasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  description: text("description"),
  creator_id: integer("creator_id").notNull(),
  assignee_id: integer("assignee_id"),
  status: text("status").notNull(),
  priority: text("priority").notNull(),
  progress: integer("progress").notNull(),
  deadline: text("deadline"),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull()
});

export const support_tickets = sqliteTable("support_tickets", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ticket_code: text("ticket_code").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  creator_id: integer("creator_id").notNull(),
  assignee_id: integer("assignee_id"),
  category: text("category").notNull(),
  priority: text("priority").notNull(),
  status: text("status").notNull(),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull(),
  resolved_at: text("resolved_at"),
  closed_at: text("closed_at"),
  department_id: integer("department_id"),
  team_id: integer("team_id"),
  routing_score: integer("routing_score").notNull().default(0),
  routing_method: text("routing_method")
}, (table) => [uniqueIndex("uq_support_tickets_ticket_code").on(table.ticket_code)]);

export const task_supporters = sqliteTable("task_supporters", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  task_id: integer("task_id").notNull(),
  user_id: integer("user_id").notNull()
}, (table) => [uniqueIndex("uq_task_supporters_task_id_user_id").on(table.task_id,table.user_id)]);

export const subtasks = sqliteTable("subtasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  task_id: integer("task_id").notNull(),
  title: text("title").notNull(),
  completed: integer("completed").notNull(),
  created_at: text("created_at").notNull(),
  completed_at: text("completed_at")
});

export const notifications = sqliteTable("notifications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  task_id: integer("task_id"),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  is_read: integer("is_read").notNull(),
  created_at: text("created_at").notNull()
});

export const support_ticket_comments = sqliteTable("support_ticket_comments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ticket_id: integer("ticket_id").notNull(),
  user_id: integer("user_id").notNull(),
  content: text("content").notNull(),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull()
});

export const support_ticket_activities = sqliteTable("support_ticket_activities", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ticket_id: integer("ticket_id").notNull(),
  user_id: integer("user_id").notNull(),
  action: text("action").notNull(),
  old_value: text("old_value"),
  new_value: text("new_value"),
  created_at: text("created_at").notNull()
});

export const task_activities = sqliteTable("task_activities", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  task_id: integer("task_id").notNull(),
  user_id: integer("user_id").notNull(),
  subtask_id: integer("subtask_id"),
  action: text("action").notNull(),
  created_at: text("created_at").notNull()
});

export const departments = sqliteTable("departments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  code: text("code").notNull(),
  parent_id: integer("parent_id"),
  manager_id: integer("manager_id"),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull()
}, (table) => [uniqueIndex("uq_departments_code").on(table.code)]);

export const department_members = sqliteTable("department_members", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  department_id: integer("department_id").notNull(),
  user_id: integer("user_id").notNull(),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull()
}, (table) => [uniqueIndex("uq_department_members_department_id_user_id").on(table.department_id,table.user_id)]);

export const support_teams = sqliteTable("support_teams", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  department_id: integer("department_id").notNull(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  lead_id: integer("lead_id"),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull()
}, (table) => [uniqueIndex("uq_support_teams_department_id_code").on(table.department_id,table.code)]);

export const support_team_members = sqliteTable("support_team_members", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  team_id: integer("team_id").notNull(),
  user_id: integer("user_id").notNull(),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull()
}, (table) => [uniqueIndex("uq_support_team_members_team_id_user_id").on(table.team_id,table.user_id)]);

export const support_routing_rules = sqliteTable("support_routing_rules", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  team_id: integer("team_id").notNull(),
  keyword: text("keyword").notNull(),
  weight: integer("weight").notNull(),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull()
});

export const announcements = sqliteTable("announcements", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  content: text("content").notNull(),
  target_type: text("target_type").notNull(),
  team_id: integer("team_id"),
  creator_id: integer("creator_id").notNull(),
  is_active: integer("is_active").notNull(),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at")
});

export const announcement_reads = sqliteTable("announcement_reads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  announcement_id: integer("announcement_id").notNull(),
  user_id: integer("user_id").notNull(),
  read_at: text("read_at").notNull()
}, (table) => [uniqueIndex("uq_announcement_reads_announcement_id_user_id").on(table.announcement_id,table.user_id)]);

export const announcement_teams = sqliteTable("announcement_teams", {
  announcement_id: integer("announcement_id").notNull(),
  team_id: integer("team_id").notNull()
}, (table) => [uniqueIndex("uq_announcement_teams_announcement_id_team_id").on(table.announcement_id,table.team_id)]);

export const task_comments = sqliteTable("task_comments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  task_id: integer("task_id").notNull(),
  user_id: integer("user_id").notNull(),
  content: text("content").notNull(),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull()
});

export const site_state = sqliteTable("site_state", {key:text("key").primaryKey(),value:text("value").notNull()});

export const auth_sessions = sqliteTable("auth_sessions", {
 token_hash: text("token_hash").primaryKey(),
 user_id: integer("user_id").notNull(),
 created_at: text("created_at").notNull(),
 expires_at: text("expires_at").notNull(),
 login_origin: text("login_origin"),
 session_mode: text("session_mode").notNull().default('cookie')
});
export const auth_attempts = sqliteTable("auth_attempts", {
 key: text("key").primaryKey(),
 attempts: integer("attempts").notNull().default(0),
 reset_at: text("reset_at").notNull()
});
