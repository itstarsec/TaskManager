# Basketball Task Creator — bàn giao

## Sử dụng

Cập nhật xử lý tải thành viên: modal dùng danh sách mà trang đã tải, chỉ gọi riêng khi chưa có. Yêu cầu này có hạn 8 giây, hủy khi đóng và không nối lại một request cũ đang treo. Người dùng vẫn có thể nhập, đóng gói và tạo việc chưa phân công khi danh sách lỗi; retry giữ nguyên draft. Danh tính hiện tại đã xác thực vẫn có trong lựa chọn. Backend đọc vai trò theo lô thay vì một truy vấn cho mỗi người. Kiểm tra hồi quy riêng: `node tests/api-client.test.mjs`.

Mở **Tất cả công việc**, **Việc của tôi** hoặc **Tổng quan** bằng tài khoản có quyền tạo công việc, chọn **Tạo công việc**. Nhập thông tin → **Đóng gói Task Card** → kéo thẻ hoặc chọn **Ném vào rổ**. Đóng gói không ghi dữ liệu. Ném trượt giữ nguyên nội dung. Sau khi tâm thẻ đi qua miệng rổ từ trên xuống, giao diện mới gửi yêu cầu; chỉ phản hồi backend có mã task hợp lệ mới hoàn tất.

Enter/Space trên thẻ dùng cú ném hỗ trợ qua cùng mô phỏng. Escape hủy ngắm/cú ném còn đang bay. **Hủy cú ném** không xuất hiện sau khi bắt đầu ghi dữ liệu. Lỗi lưu có nút thử lại bằng cùng mã lượt, không cần ném lại. Lượt đã vào rổ nhưng chưa rõ kết quả được giữ trong sessionStorage theo người dùng và xác minh khi mở lại trong cùng tab.

## Thành phần và file

| File | Vai trò |
| --- | --- |
| `app/legacy/components/basketball/BasketballTaskCreator.jsx` | Điều phối form, thẻ, trạng thái nghiệp vụ, khôi phục lượt chưa rõ kết quả, aria-live |
| `app/legacy/components/basketball/TaskSetupForm.jsx` | Form dùng schema hiện có: tên, mô tả, ưu tiên, hạn, phụ trách, hỗ trợ, checklist |
| `app/legacy/components/basketball/BasketballCourt.jsx` | SVG sân/rổ/lưới, thẻ HTML, điều khiển có thể truy cập bằng bàn phím |
| `app/legacy/components/basketball/court-controller.js` | Pointer Events, pointer capture, chuyển tọa độ theo độ dịch chuyển, RAF, dự đoán, hủy, cleanup |
| `app/legacy/components/basketball/physics.js` | Mô phỏng thuần, hình học, va chạm, dự đoán và hiệu chỉnh cú ném hỗ trợ |
| `app/legacy/components/basketball/creation-flow.js` | State machine ghi task, khóa đồng bộ, xác minh và thử lại |
| `app/legacy/components/basketball/attempt-id.js` | Mã lượt ngẫu nhiên an toàn; tương thích HTTP preview qua getRandomValues |
| `app/legacy/services/task-creation.js` | Validation/chuẩn hóa draft và adapter API thật |
| `app/basketball.css` | Token, bố cục charcoal, responsive, focus và reduced motion; giới hạn trong `.btc-*` |
| `app/legacy/components/TaskModal.jsx` | Entry point hiện có, nay bọc component tái sử dụng |
| `app/legacy/components/TaskWorkspace.jsx`, `app/legacy/pages/Dashboard.jsx` | Tải lại dữ liệu sau xác nhận; giữ modal để xem thành công |
| `app/legacy/services/api.js` | Bổ sung options headers/signal vào client hiện có; giữ cơ chế phiên và realtime |
| `app/layout.tsx` | Nạp CSS tính năng |
| `lib/api-engine.ts` | Tạo task nguyên tử, receipt idempotency và endpoint xác minh |
| `tests/basketball.test.mjs`, `tests/basketball-pointer.test.mjs` | Kiểm tra vật lý, nghiệp vụ và controller thực |
| `tests/api.test.mjs`, `tests/routes.test.mjs` | Bổ sung idempotency, rollback và truy cập đồng thời D1 |

Không thêm dependency hoặc migration. Không thay đổi cấu hình truy cập, CORS, đăng nhập hay dữ liệu hiện có khi triển khai.

## Hợp đồng tích hợp

Giữ entry point `<TaskModal onClose={...} onCreated={task => loadTasks()} />`. Nếu dùng nơi khác, có thể nhập trực tiếp `BasketballTaskCreator` với hai callback tương tự. `onCreated` chạy một lần sau backend xác nhận; `onClose` đóng modal. Parent không nên tự đóng từ `onCreated` nếu muốn giữ màn hình xác nhận.

Adapter thực trong `task-creation.js`:

```js
createTask(payload, { key, signal })
verifyTaskCreation(key, signal)
```

Adapter gửi `POST /api/tasks` qua API client đang có với `Idempotency-Key`. Payload giữ các trường hiện có; `supporter_ids` dùng quan hệ hỗ trợ đang có và được ghi chung giao dịch. Hạn ngày chuyển thành cuối ngày theo UTC+7. Trạng thái ban đầu do backend đặt `todo`; không thêm trường bắt buộc mới.

`GET /api/tasks/creation-status?key=...` chỉ người có quyền tạo được gọi, receipt giới hạn theo tài khoản hiện tại. Backend lưu receipt/hash nội dung/task_id trong bảng `site_state` hiện có. Receipt, task, checklist, người hỗ trợ, hoạt động và thông báo trong ứng dụng được ghi trong một D1 batch nguyên tử. Khóa duy nhất receipt bảo vệ cả truy cập đồng thời. Cùng mã/cùng nội dung trả lại bản ghi cũ; khác nội dung trả 409; task đã xóa trả 410 và không tự tạo lại. Receipt được giữ để tránh tạo trùng, không tự hết hạn.

Sau lỗi hoặc mất phản hồi, **Thử lại** đọc trạng thái trước. Nếu đã lưu, dùng bản ghi đó; nếu chưa có, gửi lại cùng mã và cùng nội dung. Việc vô hiệu hóa nút chỉ là lớp UI; lớp nghiệp vụ có khóa đồng bộ/shot ID và backend có idempotency bền vững. Giữ hành vi thông báo nghiệp vụ hiện có của service; thử nghiệm cục bộ không cấu hình kênh ngoài và không gửi thông báo ra ngoài.

## Vật lý và giao diện

Mọi tọa độ vật lý dùng CSS pixel trong sân. Thẻ hiển thị đúng hình chữ nhật xoay đang dùng để va chạm; không thu nhỏ khi bay. Hai đầu vành là hình tròn có bán kính cơ sở 5px ở chiều cao sân 540px, nhân tỷ lệ khi sân thu nhỏ. Đường mờ nối chúng biểu diễn mặt phẳng mở của rổ. Lưới SVG giữ phối cảnh và phản hồi thị giác; việc xuyên qua lưới không còn là điều kiện ghi điểm.

| Tham số trong `physics.js` | Giá trị hiện tại |
| --- | --- |
| Bước cố định | 1/240 giây |
| Trọng lực cơ sở ở sân cao 540px | 760px/s²; nhân tỷ lệ khi sân thu nhỏ |
| Hệ số bật vành | 0.6 |
| Thời gian tối đa | 6 giây mô phỏng |
| Số lần nảy sàn tối đa | 2 |
| Ngưỡng click/drag | 5px |
| Mốc lực 100% | 130px; thẻ vẫn theo con trỏ sau mốc này |
| Hệ số kéo | 3; lệch ngang đổi vx, kéo xuống tăng vận tốc hướng lên |
| Delta mỗi frame | Giới hạn 0.05 giây với accumulator |

Va chạm tính theo hình chữ nhật xoay và hình tròn, có xung tuyến tính/góc và substep thích nghi chống xuyên vành. Ghi nhận ngay khi tâm thẻ đi qua mặt phẳng vành từ trên xuống và điểm cắt nằm giữa hai mép trong của vành. Nội suy vị trí cắt giữa các substep để không bỏ qua miệng rổ khi thẻ bay nhanh. Không yêu cầu mọi góc của thẻ lọt trong khe hoặc chờ xuyên hết lưới. Chỉ chạm vành, tâm đi ngoài miệng rổ, đi lên hoặc bay ngang dưới rổ chưa được tính; bật vành rồi đi qua miệng rổ vẫn được tính. Trạng thái radar không có quyền ghi task.

`predict` sao chép trạng thái và chạy cùng `step` với cú ném thật. Cú ném hỗ trợ dò một tập vận tốc xác định bằng bộ mô phỏng đó; kết quả không dùng random. Mã lượt ngẫu nhiên chỉ dùng chống trùng, không ảnh hưởng kết quả vật lý. RAF cập nhật transform trực tiếp; React chỉ cập nhật theo trạng thái, không theo từng frame.

Các token ở `.btc-overlay`: `--btc-canvas`, `--btc-paper`, `--btc-ink`, `--btc-muted`, `--btc-line`, `--btc-accent`, `--btc-success`, `--btc-error`. Đổi thương hiệu bằng `--task-creator-accent`. Breakpoint một cột 760px. Sân 540px trên màn hình nhỏ, 460px trên desktop; chiều ngang giới hạn 680px. Mọi chiều dài vật lý và trọng lực cùng nhân tỷ lệ min(1, chiều cao/540), nên dự đoán và chuyển động thật dùng cùng hệ tọa độ CSS pixel ở mọi kích thước. Font monospace kế thừa `--mono`. Chỉ thẻ có `touch-action:none`. Giảm chuyển động tắt hiệu ứng trang trí và tăng tốc phát lại mô phỏng, vẫn giữ từng bước vật lý. Ẩn tab, mất focus, resize, mất capture hay unmount đều hủy cú ném chưa vào rổ và dọn tài nguyên.

## Chạy và kiểm thử

Dùng Node >=22.13 và pnpm theo `package.json`; cài dependency bằng quy trình hiện có. `pnpm dev` chạy môi trường phát triển theo README; cần binding D1/R2 của dự án cho nghiệp vụ backend. Build dùng `pnpm build`. Trong môi trường Sites được quản lý, dùng helper build/preview của Sites.

```sh
node node_modules/typescript/bin/tsc --noEmit --incremental false
node tests/basketball.test.mjs
node tests/basketball-pointer.test.mjs
node tests/api.test.mjs
node tests/workspaces.test.mjs
node tests/dispatch.test.mjs
pnpm build
node tests/routes.test.mjs
```

`routes.test.mjs` yêu cầu build đã có và chạy Worker đóng gói trên Miniflare/D1 tách biệt, chặn truy cập mạng ngoài. Các dữ liệu kiểm thử là dữ liệu tổng hợp, không phải dữ liệu demo được gắn vào ứng dụng.

## Đã kiểm tra và giới hạn

- TypeScript và production build đạt. 254 kiểm tra API, 43 kiểm tra route đóng gói và 12 kiểm tra workspace đạt; regression dispatch cũng đạt.
- Physics: vào trực tiếp, thiếu/quá lực, sai hướng, kéo tay vào, bật vành vào/ra, chỉ chạm vành chưa ghi điểm, đi dưới rổ, đi lên, tâm đi ngoài hai mép rổ, hình học xoay và qua miệng rổ được tính ngay, prediction không sửa trạng thái thật. Các lịch frame 30/60/120 cho cùng kết quả/cuối tọa độ trong sai số 1e-8. Đây là kiểm tra lịch mô phỏng, không phải số đo FPS của thiết bị.
- Nghiệp vụ: không ghi khi chuẩn bị/trượt; callback lặp chỉ ghi một lần; retry đồng thời được khóa; xác minh kết quả mất phản hồi; khôi phục lượt trước không tự POST; hủy/unmount không cập nhật UI muộn. API kiểm tra replay, khác payload, phân quyền, receipt theo người dùng, task đã xóa, rollback toàn bộ khi checklist lỗi. Miniflare/D1 kiểm tra 5 POST cùng khóa đồng thời chỉ tạo một task/checklist.
- Controller production được chạy trong harness DOM/Pointer Events: mọi vùng thẻ, theo con trỏ quá 100%, ngoài sân, click sau drag, mất capture, pointercancel, blur, resize, hidden, Escape, sự kiện touch, Enter/Space, reduced motion, cleanup listener/observer/RAF/capture. Đây không phải thử nghiệm trên màn hình cảm ứng thật.
- Chrome xem thử: nhập và đóng gói giữ danh sách 0 task; Enter chạy cú ném thật, API thật lưu D1 cục bộ, danh sách tăng lên 1 với đúng người phụ trách/checklist; chỉ lúc đó hiển thị thành công. 320px: không tràn ngang, input 16px, nút >=44px; sửa nội dung cập nhật thẻ. Xác thực thử nghiệm được cô lập bên ngoài checkout phát hành; không tạo task thử trên production.
- Chưa kiểm thử trên thiết bị iOS/Android thật, Safari hoặc bút cảm ứng; chưa đo hiệu năng thiết bị/FPS thực. Mô hình là vật lý 2D phù hợp hình SVG, không mô phỏng độ mềm/vải lưới 3D. Browser tab nền có thể giảm nhịp RAF; giới hạn delta bảo toàn tính ổn định thay vì tua xuyên vật thể.
- Nếu người dùng xóa dữ liệu phiên trình duyệt khi kết quả request còn chưa rõ, UI không còn mã lượt để khôi phục tự động; nên kiểm tra danh sách task trước khi bắt đầu một nội dung mới. Receipt backend vẫn tồn tại theo mã đã dùng.

## Cập nhật giao diện theo ISO-GLOW

Bảng điều khiển charcoal, khung rổ matte có mặt trên/cạnh, gá đỡ nối vào bệ sân isometric, viền hổ phách và đèn báo lấy trạng thái thực. `CourtStage.jsx` và `stage-geometry.js` chia sẻ chân đế với `BasketballHoop.jsx`. Cụm lực/góc/ngắm và nút ném gom ngay dưới sân. Form desktop cuộn phần trường, giữ nút chuẩn bị thẻ luôn hiển thị. Mobile dùng một cột và header đóng luôn tiếp cận được. Mô hình là phối cảnh SVG, không tải WebGL. Chỉ đèn báo, nút và lưới phản hồi theo trạng thái; không có loop trang trí liên tục.

Đã mở rộng kiểm tra các sân desktop cao 460px, rộng 240–688px theo bước 16px: cú ném hỗ trợ tìm được đường qua miệng rổ thật và kết quả giữ nguyên ở lịch mô phỏng 30/60/120 FPS. Reset/hủy trả lực, góc, dấu va chạm và cursor về trạng thái nghỉ. `scripts/export-basketball-hoop.mjs` xuất lại toàn bộ bệ/khung/rổ từ chính các component đang dùng.

Chrome QA của giao diện mới: nhập, đóng gói, Enter/Escape hủy và giữ nội dung; cú ném hỗ trợ chạy vật lý, backend D1 cục bộ xác nhận thành công và danh sách tăng từ 2 lên 3. Kiểm tra các khung 320/390/430px: không tràn ngang, input 16px, nút ném 44px. Đây là khung trình duyệt responsive, chưa phải thiết bị di động thật. Chỉ tham khảo trực tiếp trang chủ, CSS công khai và ảnh mẫu của ISO-GLOW; chưa kiểm chứng trực tiếp cảnh WebGL tham khảo.

## Điều kiện ném thân thiện

Tâm thẻ đi qua miệng rổ từ trên xuống là đủ; không kiểm tra tiếp lưới thu hẹp hoặc yêu cầu toàn bộ thẻ lọt khe. `rimPassed` là kết quả vật lý được adapter nghiệp vụ kiểm tra cùng `outcome: scored` và mã cú ném đang hoạt động. Ném trượt không gọi API, giữ nguyên payload và chuyển sang **Ném lại**. Đường dự đoán và nút hỗ trợ cùng dùng điều kiện mới. Thành công nghiệp vụ vẫn chỉ xuất hiện sau khi backend xác nhận; khóa đồng bộ và idempotency bảo vệ yêu cầu lặp.
